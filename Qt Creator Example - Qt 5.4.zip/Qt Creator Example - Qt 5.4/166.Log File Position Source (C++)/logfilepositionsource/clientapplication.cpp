#include <QtCore>
#include <QTextEdit>
#include "logfilepositionsource.h"
#include "clientapplication.h"

ClientApplication::ClientApplication(QWidget *parent)
    : QMainWindow(parent)
{
    textEdit = new QTextEdit;
    setCentralWidget(textEdit);

    LogFilePositionSource *source = new LogFilePositionSource(this);
    connect(source, SIGNAL(positionUpdated(QGeoPositionInfo)),
            this, SLOT(positionUpdated(QGeoPositionInfo)));

    source->startUpdates();
}

void ClientApplication::positionUpdated(const QGeoPositionInfo &info)
{
    //此QGeoPositionInfo对象包含位置信息和时间戳 读取之并显示在窗口
    textEdit->append(QString("位置更新：日期 / 时间 = %1, 坐标系 = %2").arg(info.timestamp().toString()).arg(info.coordinate().toString()));
}
