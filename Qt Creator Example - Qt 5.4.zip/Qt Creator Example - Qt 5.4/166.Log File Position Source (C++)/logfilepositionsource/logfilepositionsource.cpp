#include <QtCore>
#include "logfilepositionsource.h"
#include <QDebug>

LogFilePositionSource::LogFilePositionSource(QObject *parent)
    : QGeoPositionInfoSource(parent),
      logFile(new QFile(this)),
      timer(new QTimer(this))
{
    //每隔500秒读取一行
    connect(timer, SIGNAL(timeout()), this, SLOT(readNextPosition()));

    logFile->setFileName(":/simplelog.txt");
    if (!logFile->open(QIODevice::ReadOnly))
    {
        qWarning() << "无法打开文件：" << logFile->fileName();
    }
}

QGeoPositionInfo LogFilePositionSource::lastKnownPosition(bool /*fromSatellitePositioningMethodsOnly*/) const
{
    return lastPosition;
}

LogFilePositionSource::PositioningMethods LogFilePositionSource::supportedPositioningMethods() const
{
    return AllPositioningMethods;
}

int LogFilePositionSource::minimumUpdateInterval() const
{
    return 500;
}

//开始更新
void LogFilePositionSource::startUpdates()
{
    int interval = updateInterval();
    if (interval < minimumUpdateInterval())
    {
        interval = minimumUpdateInterval();
    }

    qDebug()<<interval;//500
    timer->start(interval);
}

void LogFilePositionSource::stopUpdates()
{
    timer->stop();
}

void LogFilePositionSource::requestUpdate(int /*timeout*/)
{
    if (logFile->canReadLine())
    {
        readNextPosition();
    }
    else
    {
        emit updateTimeout();
    }
}

//读取一行并转换成地理位置信息然后发送出去
void LogFilePositionSource::readNextPosition()
{
    QByteArray line = logFile->readLine().trimmed();//从txt文件读取一行
    if (!line.isEmpty())
    {
        QList<QByteArray> data = line.split(' ');

        double latitude;
        double longitude;
        bool hasLatitude = false;
        bool hasLongitude = false;

        QDateTime timestamp = QDateTime::fromString(QString(data.value(0)), Qt::ISODate);
        latitude = data.value(1).toDouble(&hasLatitude);
        longitude = data.value(2).toDouble(&hasLongitude);

        if (hasLatitude && hasLongitude && timestamp.isValid())
        {
            //QGeoCoordinate定义了地球表面的地理位置
            QGeoCoordinate coordinate(latitude, longitude);
            qDebug()<<coordinate.toString();//经纬度信息："27° 34' 20.4" S, 153° 5' 26.6" E"

            //QGeoPositionInfo包含关于在特定时间点的全局位置、方向和速度收集等信息
            //QGeoPositionInfo至少包含地理坐标和时间戳。它还可以具有航向和速度测量以及所提供数据的精度估计。
            QGeoPositionInfo info(coordinate, timestamp);//这里只含有位置信息和时间戳

            if (info.isValid())
            {
                lastPosition = info;
                emit positionUpdated(info);
            }
        }
    }
}

QGeoPositionInfoSource::Error LogFilePositionSource::error() const
{
    return QGeoPositionInfoSource::NoError;
}
