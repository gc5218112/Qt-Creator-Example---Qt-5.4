#include <QApplication>
#include "clientapplication.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    ClientApplication client;
    client.resize(800,300);
    client.show();

    return app.exec();
}
