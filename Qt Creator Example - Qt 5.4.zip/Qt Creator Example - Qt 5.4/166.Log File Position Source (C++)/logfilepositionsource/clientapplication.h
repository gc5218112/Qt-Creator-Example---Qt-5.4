#ifndef CLIENTAPPLICATION_H
#define CLIENTAPPLICATION_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
class QGeoPositionInfo;
class QTextEdit;
QT_END_NAMESPACE

class ClientApplication : public QMainWindow
{
    Q_OBJECT
public:
    ClientApplication(QWidget *parent = 0);

private slots:
    void positionUpdated(const QGeoPositionInfo &info);

private:
    QTextEdit *textEdit;
};


#endif
