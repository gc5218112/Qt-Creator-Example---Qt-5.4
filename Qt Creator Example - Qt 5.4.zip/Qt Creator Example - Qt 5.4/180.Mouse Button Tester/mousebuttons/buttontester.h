#ifndef BUTTONTESTER_H
#define BUTTONTESTER_H

#include <QTextEdit>
#include <QString>
#include <QMouseEvent>
#include <QWheelEvent>

class ButtonTester : public QTextEdit
{
    Q_OBJECT

protected:
    void    mousePressEvent(QMouseEvent *event) Q_DECL_OVERRIDE;
    void    mouseReleaseEvent(QMouseEvent *event) Q_DECL_OVERRIDE;
    void    mouseDoubleClickEvent(QMouseEvent *event) Q_DECL_OVERRIDE;
#ifndef QT_NO_WHEELEVENT
    void    wheelEvent(QWheelEvent * event) Q_DECL_OVERRIDE;
#endif
    int     buttonByNumber(const Qt::MouseButton button);
    QString enumNameFromValue(const Qt::MouseButton button);
    QString enumNamesFromMouseButtons(const Qt::MouseButtons buttons);
};

#endif // BUTTONTESTER_H
