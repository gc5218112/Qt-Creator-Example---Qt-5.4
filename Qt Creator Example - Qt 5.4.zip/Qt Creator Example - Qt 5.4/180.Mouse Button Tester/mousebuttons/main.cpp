#include "buttontester.h"
#include <QApplication>
#include <QPushButton>
#include <QVBoxLayout>

int main(int argv, char **args)
{
    QApplication app(argv, args);

    ButtonTester *testArea = new ButtonTester;
    testArea->setMinimumSize(500, 350);

    testArea->setContextMenuPolicy(Qt::NoContextMenu);
    testArea->setTextInteractionFlags(Qt::TextSelectableByMouse);
    testArea->setText("开始测试");
    QPushButton *quitButton = new QPushButton("退出");

    QObject::connect(quitButton, SIGNAL(clicked()), qApp, SLOT(quit()));

    QVBoxLayout *layout = new QVBoxLayout;
    layout->addWidget(testArea);
    layout->addWidget(quitButton);

    QWidget window;
    window.setLayout(layout);
    window.setWindowTitle("鼠标事件测试");
    window.show();

    return app.exec();
}
