#include <QtWidgets>
#include "window.h"
#include <QDebug>

Window::Window(QWidget *parent)
    : QWidget(parent)
{
    //创建按钮时指定点击按钮的槽函数
    browseButton = createButton(tr("浏览目录"), SLOT(browse()));
    findButton = createButton(tr("查找"), SLOT(find()));

    fileComboBox = createComboBox(tr("*"));//文件名
    fileLabel = new QLabel(tr("文件名（完整文件名或通配符）："));

    textComboBox = createComboBox();
    textLabel = new QLabel(tr("文件内容搜索："));

    directoryComboBox = createComboBox(QDir::currentPath());
    directoryLabel = new QLabel(tr("所选目录："));

    filesFoundLabel = new QLabel;

    createFilesTable();

    QGridLayout *mainLayout = new QGridLayout;
    mainLayout->addWidget(fileLabel, 0, 0);
    mainLayout->addWidget(fileComboBox, 0, 1, 1, 2);
    mainLayout->addWidget(textLabel, 1, 0);
    mainLayout->addWidget(textComboBox, 1, 1, 1, 2);
    mainLayout->addWidget(directoryLabel, 2, 0);
    mainLayout->addWidget(directoryComboBox, 2, 1);
    mainLayout->addWidget(browseButton, 2, 2);
    mainLayout->addWidget(filesTable, 3, 0, 1, 3);
    mainLayout->addWidget(filesFoundLabel, 4, 0, 1, 2);
    mainLayout->addWidget(findButton, 4, 2);
    setLayout(mainLayout);

    setWindowTitle(tr("文件查找"));
    resize(700, 300);
}

//选择目录
void Window::browse()
{
    QString directory = QFileDialog::getExistingDirectory(this,
                               tr("选择目录"), QDir::currentPath());

    if (!directory.isEmpty())
    {
        if (directoryComboBox->findText(directory) == -1)
        {
            directoryComboBox->addItem(directory);//添加到下拉框
        }
        directoryComboBox->setCurrentIndex(directoryComboBox->findText(directory));
    }
}

static void updateComboBox(QComboBox *comboBox)
{
    if (comboBox->findText(comboBox->currentText()) == -1)
    {
        comboBox->addItem(comboBox->currentText());
    }
}

//查找
void Window::find()
{
    filesTable->setRowCount(0);

    QString fileName = fileComboBox->currentText();//文件名（或通配符）
    QString text = textComboBox->currentText();//按文件内容搜索
    QString path = directoryComboBox->currentText();//所选目录

    updateComboBox(fileComboBox);
    updateComboBox(textComboBox);
    updateComboBox(directoryComboBox);

    currentDir = QDir(path);
    QStringList files;
    if (fileName.isEmpty())
    {
        fileName = "*";
    }

    //返回文件夹中所有文件名
    files = currentDir.entryList(QStringList(fileName), QDir::Files | QDir::NoSymLinks);
    qDebug()<<files;

    if (!text.isEmpty())
    {
        files = findFiles(files, text);//在这些文件中查找该内容
    }
    showFiles(files);
}

//在文件内容中查找含有某些内容的文件 返回含有该内容的文件名列表
QStringList Window::findFiles(const QStringList &files, const QString &text)
{
    //进度对话框
    QProgressDialog progressDialog(this);
    progressDialog.setCancelButtonText(tr("取消"));
    progressDialog.setRange(0, files.size());
    progressDialog.setWindowTitle(tr("查找文件"));

    QStringList foundFiles;

    for (int i = 0; i < files.size(); ++i)
    {
        progressDialog.setValue(i);
        progressDialog.setLabelText(tr("查找文件：%1 / %2...").arg(i).arg(files.size()));
        qApp->processEvents();//强制进度框刷新状态 否则看不到效果

        if (progressDialog.wasCanceled())//如果按下了进度框的取消按钮
        {
            break;
        }

        QFile file(currentDir.absoluteFilePath(files[i]));

        if (file.open(QIODevice::ReadOnly))//只读方式打开文件
        {
            //按行查找 看每一行是否包含要找的内容
            QString line;
            QTextStream in(&file);
            while (!in.atEnd())
            {
                if (progressDialog.wasCanceled())
                {
                    break;
                }
                line = in.readLine();
                if (line.contains(text))
                {
                    foundFiles << files[i];
                    break;
                }
            }
        }
    }
    return foundFiles;
}

//显示查找的结果信息
void Window::showFiles(const QStringList &files)
{
    for (int i = 0; i < files.size(); ++i)
    {
        QFile file(currentDir.absoluteFilePath(files[i]));
        qint64 size = QFileInfo(file).size();

        QTableWidgetItem *fileNameItem = new QTableWidgetItem(files[i]);
        fileNameItem->setFlags(fileNameItem->flags() ^ Qt::ItemIsEditable);
        QTableWidgetItem *sizeItem = new QTableWidgetItem(tr("%1 KB").arg(int((size + 1023) / 1024)));
        sizeItem->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
        sizeItem->setFlags(sizeItem->flags() ^ Qt::ItemIsEditable);

        int row = filesTable->rowCount();
        filesTable->insertRow(row);
        filesTable->setItem(row, 0, fileNameItem);
        filesTable->setItem(row, 1, sizeItem);
    }
    filesFoundLabel->setText(tr("查找到%1个文件").arg(files.size()) + (" (双击打开)"));
    filesFoundLabel->setWordWrap(true);//根据内容自动换行
}

//创建按钮时为按钮指定槽函数
QPushButton *Window::createButton(const QString &text, const char *member)
{
    QPushButton *button = new QPushButton(text);
    connect(button, SIGNAL(clicked()), this, member);
    return button;
}

QComboBox *Window::createComboBox(const QString &text)
{
    QComboBox *comboBox = new QComboBox;
    comboBox->setEditable(true);
    comboBox->addItem(text);
    comboBox->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);
    return comboBox;
}

void Window::createFilesTable()
{
    filesTable = new QTableWidget(0, 2);//带表格的部件
    filesTable->setSelectionBehavior(QAbstractItemView::SelectRows);//设置只能选择单行

    QStringList labels;
    labels << tr("文件名") << tr("文件大小");
    filesTable->setHorizontalHeaderLabels(labels);//设置表头
    //水平表头：第一列拉直表头
    filesTable->horizontalHeader()->setSectionResizeMode(0, QHeaderView::Stretch);
    filesTable->verticalHeader()->hide();//垂直表头隐藏
    filesTable->setShowGrid(false);//不显示表头网格

    //双击表格信号槽
    connect(filesTable, SIGNAL(cellActivated(int,int)), this, SLOT(openFileOfItem(int,int)));
}

//打开文件
void Window::openFileOfItem(int row, int /* column */)
{
    QTableWidgetItem *item = filesTable->item(row, 0);
    QDesktopServices::openUrl(QUrl::fromLocalFile(currentDir.absoluteFilePath(item->text())));
}
