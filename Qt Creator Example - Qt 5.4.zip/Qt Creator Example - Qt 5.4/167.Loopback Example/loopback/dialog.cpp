#include <QtWidgets>
#include <QtNetwork>
#include "dialog.h"
#include <QDebug>

static const int TotalBytes = 50 * 1024 * 1024;
static const int PayloadSize = 64 * 1024; // 64 KB

Dialog::Dialog(QWidget *parent)
    : QDialog(parent)
{
    clientProgressBar = new QProgressBar;
    clientStatusLabel = new QLabel(tr("客户端准备好了"));
    serverProgressBar = new QProgressBar;
    serverStatusLabel = new QLabel(tr("服务端准备好了"));

    startButton = new QPushButton(tr("开始"));
    quitButton = new QPushButton(tr("退出"));

    buttonBox = new QDialogButtonBox;
    buttonBox->addButton(startButton, QDialogButtonBox::ActionRole);
    buttonBox->addButton(quitButton, QDialogButtonBox::RejectRole);

    connect(startButton, SIGNAL(clicked()), this, SLOT(start()));
    connect(quitButton, SIGNAL(clicked()), this, SLOT(close()));

    //当服务端监听到有新客户端连接时
    connect(&tcpServer, SIGNAL(newConnection()), this, SLOT(acceptConnection()));

    //客户端成功与服务端建立连接时，发送此信号，向服务端发送消息
    connect(&tcpClient, SIGNAL(connected()), this, SLOT(startTransfer()));
    //当客户端成功将要发送的内容写入socket时，发送此信号，更新进度条
    connect(&tcpClient, SIGNAL(bytesWritten(qint64)), this, SLOT(updateClientProgress(qint64)));
    //出错时显示错误信息
    connect(&tcpClient, SIGNAL(error(QAbstractSocket::SocketError)), this, SLOT(displayError(QAbstractSocket::SocketError)));

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout->addWidget(clientProgressBar);
    mainLayout->addWidget(clientStatusLabel);
    mainLayout->addWidget(serverProgressBar);
    mainLayout->addWidget(serverStatusLabel);
    mainLayout->addStretch(1);
    mainLayout->addSpacing(10);
    mainLayout->addWidget(buttonBox);
    setLayout(mainLayout);

    setWindowTitle(tr("Loopback"));
}

void Dialog::start()
{
    startButton->setEnabled(false);

#ifndef QT_NO_CURSOR
    QApplication::setOverrideCursor(Qt::WaitCursor);
#endif

    bytesWritten = 0;
    bytesReceived = 0;

    //bool QTcpServer::​listen(const QHostAddress & address = QHostAddress::Any, quint16 port = 0)
    //QTcpServer->listen()设置服务端侦听地址地址和端。如果端口为0（默认），则自动选择端口
    //如果地址是QHostAddress::Any，服务器将监听所有网络接口
    while (!tcpServer.isListening() && !tcpServer.listen())//如果服务端没有在监听且未设置监听的地址和端口
    {
        QMessageBox::StandardButton ret = QMessageBox::critical(this, tr("进度条示例"), tr("无法开始测试: %1.").arg(tcpServer.errorString()), QMessageBox::Retry | QMessageBox::Cancel);
        if (ret == QMessageBox::Cancel)
        {
            return;
        }
    }

    serverStatusLabel->setText(tr("监听中"));
    clientStatusLabel->setText(tr("连接中"));
    //客户端套接字连接服务端（本地主机）
    //设置连接的地址：本机地址，端口是服务端自动设置的监听端口
    tcpClient.connectToHost(QHostAddress::LocalHost, tcpServer.serverPort());
}

//当服务端监听到有新客户端要连接时，服务端和客户端建立连接
void Dialog::acceptConnection()
{
    //服务端用于和客户端通信的套接字
    //nextPendingConnection()服务器和监听到的客户端建立连接，服务器使用tcpServerConnection套接字与该客户端通信
    tcpServerConnection = tcpServer.nextPendingConnection();

    //服务端读取客户端发过来的信息
    connect(tcpServerConnection, SIGNAL(readyRead()), this, SLOT(updateServerProgress()));
    connect(tcpServerConnection, SIGNAL(error(QAbstractSocket::SocketError)),
            this, SLOT(displayError(QAbstractSocket::SocketError)));

    serverStatusLabel->setText(tr("服务端接受连接"));
    tcpServer.close();//已经
}

//服务端向客户端发送消息（传一个数字给服务端）
void Dialog::startTransfer()
{
    bytesToWrite = TotalBytes - (int)tcpClient.write(QByteArray(PayloadSize, '@'));
    clientStatusLabel->setText(tr("保持连接"));
}

//更新服务端进度条
void Dialog::updateServerProgress()
{
    bytesReceived += (int)tcpServerConnection->bytesAvailable();
    qDebug()<<"服务端接收到的内容（一个数字）："<<bytesReceived;

    tcpServerConnection->readAll();

    serverProgressBar->setMaximum(TotalBytes);//设置该进度条最大值
    serverProgressBar->setValue(bytesReceived);//设置进图条当前值
    serverStatusLabel->setText(tr("已接收%1MB").arg(bytesReceived / (1024 * 1024)));

    if (bytesReceived == TotalBytes)
    {
        tcpServerConnection->close();//服务端主动关闭与客户端的连接
        startButton->setEnabled(true);

#ifndef QT_NO_CURSOR
        QApplication::restoreOverrideCursor();//光标样式
#endif
    }
}

//更新客户端进度条
void Dialog::updateClientProgress(qint64 numBytes)
{
    bytesWritten += (int)numBytes;
    qDebug()<<"客户端接发送的内容（一个数字）："<<bytesWritten;

    if (bytesToWrite > 0 && tcpClient.bytesToWrite() <= 4*PayloadSize)
    {
        bytesToWrite -= (int)tcpClient.write(QByteArray(qMin(bytesToWrite, PayloadSize), '@'));
    }

    clientProgressBar->setMaximum(TotalBytes);
    clientProgressBar->setValue(bytesWritten);
    clientStatusLabel->setText(tr("已接受%1MB").arg(bytesWritten / (1024 * 1024)));
}

//显示错误信息
void Dialog::displayError(QAbstractSocket::SocketError socketError)
{
    if (socketError == QTcpSocket::RemoteHostClosedError)
    {
        return;
    }

    QMessageBox::information(this, tr("网络错误"),
                             tr("当前出现以下错误：%1").arg(tcpClient.errorString()));

    tcpClient.close();
    tcpServer.close();
    clientProgressBar->reset();
    serverProgressBar->reset();
    clientStatusLabel->setText(tr("客户端准备好了"));
    serverStatusLabel->setText(tr("服务端准备好了"));
    startButton->setEnabled(true);

#ifndef QT_NO_CURSOR
    QApplication::restoreOverrideCursor();
#endif
}
