#include <QApplication>
#include "fademessage.h"

int main(int argc, char **argv)
{
    QApplication app(argc, argv);

    FadeMessage widget;
    widget.setWindowTitle(QT_TRANSLATE_NOOP(QGraphicsView, "图形项着色"));
    widget.setFixedSize(400, 600);
    widget.show();

    return app.exec();
}
