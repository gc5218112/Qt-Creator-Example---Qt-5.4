#ifndef URIRECORDEDITOR_H
#define URIRECORDEDITOR_H

#include <QWidget>
#include <qndefnfcurirecord.h>

QT_BEGIN_NAMESPACE
namespace Ui {
    class UriRecordEditor;
}
QT_END_NAMESPACE

QT_USE_NAMESPACE

class UriRecordEditor : public QWidget
{
    Q_OBJECT

public:
    explicit UriRecordEditor(QWidget *parent = 0);
    ~UriRecordEditor();

    void setRecord(const QNdefNfcUriRecord &uriRecord);
    QNdefNfcUriRecord record() const;

private:
    Ui::UriRecordEditor *ui;
};

#endif // URIRECORDEDITOR_H
