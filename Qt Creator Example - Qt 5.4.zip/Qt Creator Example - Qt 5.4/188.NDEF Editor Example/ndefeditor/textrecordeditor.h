#ifndef TEXTRECORDEDITOR_H
#define TEXTRECORDEDITOR_H

#include <QWidget>
#include <qndefnfctextrecord.h>

QT_BEGIN_NAMESPACE
namespace Ui {
    class TextRecordEditor;
}
QT_END_NAMESPACE

QT_USE_NAMESPACE

class TextRecordEditor : public QWidget
{
    Q_OBJECT

public:
    explicit TextRecordEditor(QWidget *parent = 0);
    ~TextRecordEditor();

    void setRecord(const QNdefNfcTextRecord &textRecord);
    QNdefNfcTextRecord record() const;

private:
    Ui::TextRecordEditor *ui;
};

#endif // TEXTRECORDEDITOR_H
