#ifndef MIMEIMAGERECORDEDITOR_H
#define MIMEIMAGERECORDEDITOR_H

#include <qnfcglobal.h>
#include <QWidget>
#include <qndefrecord.h>

QT_USE_NAMESPACE

QT_BEGIN_NAMESPACE
namespace Ui {
    class MimeImageRecordEditor;
}
QT_END_NAMESPACE


class MimeImageRecordEditor : public QWidget
{
    Q_OBJECT

public:
    explicit MimeImageRecordEditor(QWidget *parent = 0);
    ~MimeImageRecordEditor();

    void setRecord(const QNdefRecord &record);
    QNdefRecord record() const;

private:
    Ui::MimeImageRecordEditor *ui;
    QNdefRecord m_record;

private slots:
    void on_mimeImageOpen_clicked();
};

#endif // MIMEIMAGERECORDEDITOR_H
