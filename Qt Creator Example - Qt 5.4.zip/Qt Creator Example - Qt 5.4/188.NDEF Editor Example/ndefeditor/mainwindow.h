#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <qnfcglobal.h>
#include <qnearfieldtarget.h>

QT_BEGIN_NAMESPACE
class QNearFieldManager;
class QNdefMessage;
QT_END_NAMESPACE

QT_USE_NAMESPACE

QT_BEGIN_NAMESPACE
namespace Ui {
    class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void addNfcTextRecord();
    void addNfcUriRecord();
    void addMimeImageRecord();
    void addEmptyRecord();

    void clearMessage();

    void loadMessage();
    void saveMessage();

    void touchReceive();
    void touchStore();

    void targetDetected(QNearFieldTarget *target);
    void targetLost(QNearFieldTarget *target);

    void ndefMessageRead(const QNdefMessage &message);
    void ndefMessageWritten();
    void targetError(QNearFieldTarget::Error error, const QNearFieldTarget::RequestId &id);

private:
    enum TouchAction {
        NoAction,
        ReadNdef,
        WriteNdef
    };

    QNdefMessage ndefMessage() const;

private:
    Ui::MainWindow *ui;

    QNearFieldManager *m_manager;
    TouchAction m_touchAction;
    QNearFieldTarget::RequestId m_request;
};

#endif // MAINWINDOW_H
