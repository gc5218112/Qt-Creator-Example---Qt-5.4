#include "volumebutton.h"
#include <QtWidgets>
#include <QtWinExtras>

//调节音量按钮
VolumeButton::VolumeButton(QWidget *parent) :
    QToolButton(parent), menu(0), label(0), slider(0)
{
    setIcon(style()->standardIcon(QStyle::SP_MediaVolume));//使用qt自带的图标
    setPopupMode(QToolButton::InstantPopup);//点击按钮立即弹出菜单

    QWidget *popup = new QWidget(this);

    slider = new QSlider(Qt::Horizontal, popup);
    slider->setRange(0, 100);
    //当改变滑动条时发出要求改变音量的信号
    connect(slider, SIGNAL(valueChanged(int)), this, SIGNAL(volumeChanged(int)));

    //显示音量数字值
    label = new QLabel(popup);
    label->setAlignment(Qt::AlignCenter);
    label->setNum(100);
    label->setMinimumWidth(label->sizeHint().width());
    connect(slider, SIGNAL(valueChanged(int)), label, SLOT(setNum(int)));

    QBoxLayout *popupLayout = new QHBoxLayout(popup);//水平布局
    popupLayout->setMargin(2);
    popupLayout->addWidget(slider);
    popupLayout->addWidget(label);

    //QWidgetAction常用于非常小的部件的动作
    QWidgetAction *action = new QWidgetAction(this);
    action->setDefaultWidget(popup);

    menu = new QMenu(this);
    menu->addAction(action);

    setMenu(menu);//为当前工具按钮增加菜单

    stylize();
}

//增大音量
void VolumeButton::increaseVolume()
{
    slider->triggerAction(QSlider::SliderPageStepAdd);
}

//减小音量
void VolumeButton::descreaseVolume()
{
    slider->triggerAction(QSlider::SliderPageStepSub);
}

int VolumeButton::volume() const
{
    return slider->value();
}

void VolumeButton::setVolume(int volume)
{
    slider->setValue(volume);
}

//使用Windows界面的玻璃效果
void VolumeButton::stylize()
{
    if (QtWin::isCompositionEnabled())
    {
        QtWin::enableBlurBehindWindow(menu);
        QString css("QMenu { border: 1px solid %1; border-radius: 2px; background: transparent; }");
        menu->setStyleSheet(css.arg(QtWin::realColorizationColor().name()));
    }
    else
    {
        QtWin::disableBlurBehindWindow(menu);
        QString css("QMenu { border: 1px solid black; background: %1; }");
        menu->setStyleSheet(css.arg(QtWin::realColorizationColor().name()));
    }
}
