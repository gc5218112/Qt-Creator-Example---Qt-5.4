#include "musicplayer.h"
#include "volumebutton.h"
#include <QtWidgets>
#include <QtWinExtras>

MusicPlayer::MusicPlayer(QWidget *parent) : QWidget(parent),
    taskbarButton(0), taskbarProgress(0), thumbnailToolBar(0),
    playToolButton(0), forwardToolButton(0), backwardToolButton(0),
    mediaPlayer(0), playButton(0), volumeButton(0),
    positionSlider(0), positionLabel(0), infoLabel(0)
{
    createWidgets();
    createShortcuts();
    createJumpList();
    createTaskbar();
    createThumbnailToolBar();

    connect(&mediaPlayer, SIGNAL(positionChanged(qint64)), this, SLOT(updatePosition(qint64)));
    connect(&mediaPlayer, SIGNAL(durationChanged(qint64)), this, SLOT(updateDuration(qint64)));
    connect(&mediaPlayer, SIGNAL(metaDataAvailableChanged(bool)), this, SLOT(updateInfo()));
    connect(&mediaPlayer, SIGNAL(error(QMediaPlayer::Error)), this, SLOT(handleError()));
    connect(&mediaPlayer, SIGNAL(stateChanged(QMediaPlayer::State)), this, SLOT(updateState(QMediaPlayer::State)));

    stylize();
}

void MusicPlayer::openFile()
{
    const QStringList musicPaths = QStandardPaths::standardLocations(QStandardPaths::MusicLocation);
    const QString filePath = QFileDialog::getOpenFileName(this, tr("打开文件"),
                                                          "../musicplayer",
                                                          tr("MP3文件(*.mp3);;所有文件(*.*)"));
    if (!filePath.isEmpty())
    {
        playFile(filePath);
    }
}

//此文件设为播放器播放的文件
void MusicPlayer::playFile(const QString &filePath)
{
    playButton->setEnabled(true);
    infoLabel->setText(QFileInfo(filePath).fileName());

    mediaPlayer.setMedia(QUrl::fromLocalFile(filePath));
    mediaPlayer.play();
}

//播放按钮/快捷键：空格键
void MusicPlayer::togglePlayback()
{
    if (mediaPlayer.mediaStatus() == QMediaPlayer::NoMedia)//未添加要播放的文件
    {
        openFile();
    }
    else if (mediaPlayer.state() == QMediaPlayer::PlayingState)
    {
        mediaPlayer.pause();
    }
    else
    {
        mediaPlayer.play();
    }
}

//->键 快进
void MusicPlayer::seekForward()
{
    positionSlider->triggerAction(QSlider::SliderPageStepAdd);
}

//<-快退
void MusicPlayer::seekBackward()
{
    positionSlider->triggerAction(QSlider::SliderPageStepSub);
}

bool MusicPlayer::event(QEvent *event)
{
    if (event->type() == QWinEvent::CompositionChange || event->type() == QWinEvent::ColorizationChange)
    {
        stylize();
    }
    return QWidget::event(event);
}

//鼠标按下
void MusicPlayer::mousePressEvent(QMouseEvent *event)
{
    //event->globalPos()获取的鼠标位置是鼠标偏离电脑屏幕左上角(x=0,y=0)的位置
    //pos()获取的位置是主窗口（widget窗口）左上角（边框的左上角，外左上角）相对于电脑屏幕的左上角的（x=0,y=0）偏移位置
    offset = event->globalPos() - pos();
    event->accept();
}

//鼠标移动 （拖动窗口）
void MusicPlayer::mouseMoveEvent(QMouseEvent *event)
{
    move(event->globalPos() - offset);
    event->accept();
}

//鼠标松开
void MusicPlayer::mouseReleaseEvent(QMouseEvent *event)
{
    offset = QPoint();
    event->accept();
}


void MusicPlayer::stylize()
{
    if (QtWin::isCompositionEnabled())//返回DWM组合状态（windows Vista及windows 7的组件 可设置窗口效果）
    {
        QtWin::extendFrameIntoClientArea(this, -1, -1, -1, -1);//玻璃效果
        setAttribute(Qt::WA_TranslucentBackground, true);//半透明背景
        setAttribute(Qt::WA_NoSystemBackground, false);//禁用无背景
        setStyleSheet("MusicPlayer { background: transparent; }");
    }
    else
    {
        QtWin::resetExtendedFrame(this);
        setAttribute(Qt::WA_TranslucentBackground, false);
        setStyleSheet(QString("MusicPlayer { background: %1; }").arg(QtWin::realColorizationColor().name()));
    }
    volumeButton->stylize();
}

void MusicPlayer::updateState(QMediaPlayer::State state)
{
    if (state == QMediaPlayer::PlayingState)
    {
        playButton->setToolTip(tr("暂停"));
        playButton->setIcon(style()->standardIcon(QStyle::SP_MediaPause));
    }
    else
    {
        playButton->setToolTip(tr("播放"));
        playButton->setIcon(style()->standardIcon(QStyle::SP_MediaPlay));
    }
}

//播放位置改变时，更新进度条和时间
void MusicPlayer::updatePosition(qint64 position)
{
    positionSlider->setValue(position);

    QTime duration(0, position / 60000, qRound((position % 60000) / 1000.0));
    positionLabel->setText(duration.toString(tr("mm:ss")));
}

void MusicPlayer::updateDuration(qint64 duration)
{
    positionSlider->setRange(0, duration);
    positionSlider->setEnabled(duration > 0);
    positionSlider->setPageStep(duration / 10);
}

//播放进度
void MusicPlayer::setPosition(int position)
{
    if (qAbs(mediaPlayer.position() - position) > 99)    
    {
        mediaPlayer.setPosition(position);
    }
}

//元数据更新 不同的mp3文件的元数据不同
void MusicPlayer::updateInfo()
{
    QStringList info;
    QString author = mediaPlayer.metaData("Author").toString();
    if (!author.isEmpty())
    {
        info += author;
    }
    QString title = mediaPlayer.metaData("Title").toString();
    if (!title.isEmpty())
    {
        info += title;
    }
    if (!info.isEmpty())
    {
        infoLabel->setText(info.join(tr(" - ")));
    }
}

void MusicPlayer::handleError()
{
    playButton->setEnabled(false);
    infoLabel->setText(tr("错误：%1").arg(mediaPlayer.errorString()));
}

//更新任务栏进度条
void MusicPlayer::updateTaskbar()
{
    switch (mediaPlayer.state())
    {
        case QMediaPlayer::PlayingState://播放状态
            taskbarButton->setOverlayIcon(style()->standardIcon(QStyle::SP_MediaPlay));
            taskbarProgress->show();
            taskbarProgress->resume();
            break;
        case QMediaPlayer::PausedState://暂停状态
            taskbarButton->setOverlayIcon(style()->standardIcon(QStyle::SP_MediaPause));
            taskbarProgress->show();
            taskbarProgress->pause();
            break;
        case QMediaPlayer::StoppedState://停止状态
            taskbarButton->setOverlayIcon(style()->standardIcon(QStyle::SP_MediaStop));
            taskbarProgress->hide();
            break;
    }
}

void MusicPlayer::updateThumbnailToolBar()
{
    playToolButton->setEnabled(mediaPlayer.duration() > 0);
    backwardToolButton->setEnabled(mediaPlayer.position() > 0);
    forwardToolButton->setEnabled(mediaPlayer.position() < mediaPlayer.duration());

    if (mediaPlayer.state() == QMediaPlayer::PlayingState)
    {
        playToolButton->setToolTip(tr("暂停"));
        playToolButton->setIcon(style()->standardIcon(QStyle::SP_MediaPause));
    }
    else
    {
        playToolButton->setToolTip(tr("播放"));
        playToolButton->setIcon(style()->standardIcon(QStyle::SP_MediaPlay));
    }
}

void MusicPlayer::createWidgets()
{
    playButton = new QToolButton(this);
    playButton->setEnabled(false);
    playButton->setToolTip(tr("播放"));
    playButton->setIcon(style()->standardIcon(QStyle::SP_MediaPlay));//使用qt自带的图标
    connect(playButton, SIGNAL(clicked()), this, SLOT(togglePlayback()));

    QAbstractButton *openButton = new QToolButton(this);
    openButton->setText(tr("..."));
    openButton->setToolTip(tr("打开mp3格式音乐文件"));
    openButton->setFixedSize(playButton->sizeHint());
    connect(openButton, SIGNAL(clicked()), this, SLOT(openFile()));

    volumeButton = new VolumeButton(this);
    volumeButton->setToolTip(tr("调节音量"));
    volumeButton->setVolume(mediaPlayer.volume());
    connect(volumeButton, SIGNAL(volumeChanged(int)), &mediaPlayer, SLOT(setVolume(int)));

    positionSlider = new QSlider(Qt::Horizontal, this);
    positionSlider->setEnabled(false);
    positionSlider->setToolTip(tr("播放进度"));
    connect(positionSlider, SIGNAL(valueChanged(int)), this, SLOT(setPosition(int)));

    infoLabel = new QLabel(this);
    positionLabel = new QLabel(tr("00:00"), this);
    positionLabel->setMinimumWidth(positionLabel->sizeHint().width());

    QBoxLayout *controlLayout = new QHBoxLayout;
    controlLayout->setMargin(0);
    controlLayout->addWidget(openButton);
    controlLayout->addWidget(playButton);
    controlLayout->addWidget(positionSlider);
    controlLayout->addWidget(positionLabel);
    controlLayout->addWidget(volumeButton);

    QBoxLayout *mainLayout = new QVBoxLayout(this);
    mainLayout->addWidget(infoLabel);
    mainLayout->addLayout(controlLayout);
}

//设置快捷键 按   Ctrl+快捷键即可执行槽函数
void MusicPlayer::createShortcuts()
{
    QShortcut *quitShortcut = new QShortcut(QKeySequence::Quit, this);
    connect(quitShortcut, SIGNAL(activated()), qApp, SLOT(quit()));

    QShortcut *openShortcut = new QShortcut(QKeySequence::Open, this);
    connect(openShortcut, SIGNAL(activated()), this, SLOT(openFile()));

    QShortcut *toggleShortcut = new QShortcut(Qt::Key_Space, this);
    connect(toggleShortcut, SIGNAL(activated()), this, SLOT(togglePlayback()));

    QShortcut *forwardShortcut = new QShortcut(Qt::Key_Right, this);
    connect(forwardShortcut, SIGNAL(activated()), this, SLOT(seekForward()));

    QShortcut *backwardShortcut = new QShortcut(Qt::Key_Left, this);
    connect(backwardShortcut, SIGNAL(activated()), this, SLOT(seekBackward()));

    QShortcut *increaseShortcut = new QShortcut(Qt::Key_Up, this);
    connect(increaseShortcut, SIGNAL(activated()), volumeButton, SLOT(increaseVolume()));

    QShortcut *decreaseShortcut = new QShortcut(Qt::Key_Down, this);
    connect(decreaseShortcut, SIGNAL(activated()), volumeButton, SLOT(descreaseVolume()));
}

void MusicPlayer::createJumpList()
{
    QWinJumpList jumplist;
    jumplist.recent()->setVisible(true);
}

//创建任务栏
void MusicPlayer::createTaskbar()
{
    //任务栏按钮
    taskbarButton = new QWinTaskbarButton(this);
    taskbarButton->setWindow(windowHandle());

    taskbarProgress = taskbarButton->progress();//任务栏按钮的进度条 显示播放进度
    //播放进度进度条的内容和任务栏进度条同步
    connect(positionSlider, SIGNAL(valueChanged(int)), taskbarProgress, SLOT(setValue(int)));
    connect(positionSlider, SIGNAL(rangeChanged(int,int)), taskbarProgress, SLOT(setRange(int,int)));

    //当播放器状态变化时
    connect(&mediaPlayer, SIGNAL(stateChanged(QMediaPlayer::State)), this, SLOT(updateTaskbar()));
}

//任务栏的缩略视图按钮工具栏 鼠标放在任务栏程序上显示的
void MusicPlayer::createThumbnailToolBar()
{
    thumbnailToolBar = new QWinThumbnailToolBar(this);
    thumbnailToolBar->setWindow(windowHandle());

    playToolButton = new QWinThumbnailToolButton(thumbnailToolBar);
    playToolButton->setEnabled(false);
    playToolButton->setToolTip(tr("播放"));
    playToolButton->setIcon(style()->standardIcon(QStyle::SP_MediaPlay));
    connect(playToolButton, SIGNAL(clicked()), this, SLOT(togglePlayback()));

    forwardToolButton = new QWinThumbnailToolButton(thumbnailToolBar);
    forwardToolButton->setEnabled(false);
    forwardToolButton->setToolTip(tr("快进"));
    forwardToolButton->setIcon(style()->standardIcon(QStyle::SP_MediaSeekForward));
    connect(forwardToolButton, SIGNAL(clicked()), this, SLOT(seekForward()));

    backwardToolButton = new QWinThumbnailToolButton(thumbnailToolBar);
    backwardToolButton->setEnabled(false);
    backwardToolButton->setToolTip(tr("快退"));
    backwardToolButton->setIcon(style()->standardIcon(QStyle::SP_MediaSeekBackward));
    connect(backwardToolButton, SIGNAL(clicked()), this, SLOT(seekBackward()));

    thumbnailToolBar->addButton(backwardToolButton);
    thumbnailToolBar->addButton(playToolButton);
    thumbnailToolBar->addButton(forwardToolButton);

    connect(&mediaPlayer, SIGNAL(positionChanged(qint64)), this, SLOT(updateThumbnailToolBar()));
    connect(&mediaPlayer, SIGNAL(durationChanged(qint64)), this, SLOT(updateThumbnailToolBar()));
    connect(&mediaPlayer, SIGNAL(stateChanged(QMediaPlayer::State)), this, SLOT(updateThumbnailToolBar()));
}
