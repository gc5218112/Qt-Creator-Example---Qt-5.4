#include <QtWidgets>
#include "window.h"

Window::Window(QWidget *parent)
    : QWidget(parent)
{
    QGridLayout *grid = new QGridLayout;
    grid->addWidget(createFirstExclusiveGroup(), 0, 0);
    grid->addWidget(createSecondExclusiveGroup(), 1, 0);
    grid->addWidget(createNonExclusiveGroup(), 0, 1);
    grid->addWidget(createPushButtonGroup(), 1, 1);
    setLayout(grid);

    setWindowTitle(tr("Group容器"));
    resize(480, 320);
}

QGroupBox *Window::createFirstExclusiveGroup()
{
    QGroupBox *groupBox = new QGroupBox(tr("单选按钮1"));

    QRadioButton *radio1 = new QRadioButton(tr("按钮1"));
    QRadioButton *radio2 = new QRadioButton(tr("按钮2"));
    QRadioButton *radio3 = new QRadioButton(tr("按钮3"));

    radio1->setChecked(true);//选中

    QVBoxLayout *vbox = new QVBoxLayout;
    vbox->addWidget(radio1);
    vbox->addWidget(radio2);
    vbox->addWidget(radio3);
    vbox->addStretch(1);
    groupBox->setLayout(vbox);

    return groupBox;
}

QGroupBox *Window::createSecondExclusiveGroup()
{
    QGroupBox *groupBox = new QGroupBox(tr("单选按钮2"));
    groupBox->setCheckable(true);//给QGroupBox增加一个可选中状态（增加一个复选框）
    groupBox->setChecked(false);//不选中复选框

    QRadioButton *radio1 = new QRadioButton(tr("单选按钮1"));
    QRadioButton *radio2 = new QRadioButton(tr("单选按钮2"));
    QRadioButton *radio3 = new QRadioButton(tr("单选按钮3"));
    radio1->setChecked(true);//选中

    QCheckBox *checkBox = new QCheckBox(tr("复选框1"));
    checkBox->setChecked(true);

    QVBoxLayout *vbox = new QVBoxLayout;
    vbox->addWidget(radio1);
    vbox->addWidget(radio2);
    vbox->addWidget(radio3);
    vbox->addWidget(checkBox);
    vbox->addStretch(1);
    groupBox->setLayout(vbox);

    return groupBox;
}

QGroupBox *Window::createNonExclusiveGroup()
{
    QGroupBox *groupBox = new QGroupBox(tr("复选框"));
    groupBox->setFlat(true);//去掉边框

    QCheckBox *checkBox1 = new QCheckBox(tr("复选框1"));
    QCheckBox *checkBox2 = new QCheckBox(tr("复选框2"));
    checkBox2->setChecked(true);//选中

    QCheckBox *tristateBox = new QCheckBox(tr("复选框3"));
    tristateBox->setTristate(true);//设置复选框三态
    tristateBox->setCheckState(Qt::PartiallyChecked);

    QVBoxLayout *vbox = new QVBoxLayout;
    vbox->addWidget(checkBox1);
    vbox->addWidget(checkBox2);
    vbox->addWidget(tristateBox);
    vbox->addStretch(1);
    groupBox->setLayout(vbox);

    return groupBox;
}

QGroupBox *Window::createPushButtonGroup()
{
    QGroupBox *groupBox = new QGroupBox(tr("按钮"));
    groupBox->setCheckable(true);//此QGroupBox增加一个可选中状态（增加一个复选框）
    groupBox->setChecked(true);

    QPushButton *pushButton = new QPushButton(tr("正常按钮"));
    QPushButton *toggleButton = new QPushButton(tr("状态开关按钮"));
    toggleButton->setCheckable(true);//增加一个可选中状态
    toggleButton->setChecked(true);

    QPushButton *flatButton = new QPushButton(tr("无边框按钮"));
    flatButton->setFlat(true);

    QPushButton *popupButton = new QPushButton(tr("含菜单按钮"));
    QMenu *menu = new QMenu(this);
    menu->addAction(tr("菜单项1"));
    menu->addAction(tr("菜单项2"));
    menu->addAction(tr("菜单项3"));
    menu->addAction(tr("菜单项4"));
    popupButton->setMenu(menu);

    QAction *newAction = menu->addAction(tr("弹出子菜单动作"));
    QMenu *subMenu = new QMenu(tr("子菜单"));
    subMenu->addAction(tr("子菜单1"));
    subMenu->addAction(tr("子菜单2"));
    subMenu->addAction(tr("子菜单3"));
    newAction->setMenu(subMenu);

    QVBoxLayout *vbox = new QVBoxLayout;
    vbox->addWidget(pushButton);
    vbox->addWidget(toggleButton);
    vbox->addWidget(flatButton);
    vbox->addWidget(popupButton);
    vbox->addStretch(1);
    groupBox->setLayout(vbox);

    return groupBox;
}
