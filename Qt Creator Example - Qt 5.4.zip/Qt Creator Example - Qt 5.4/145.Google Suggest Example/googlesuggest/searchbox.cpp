#include <QDesktopServices>
#include <QUrl>
#include "searchbox.h"

//#define GSEARCH_URL "http://www.google.com/search?q=%1"
#define GSEARCH_URL "https://www.baidu.com/s?wd=%1"

SearchBox::SearchBox(QWidget *parent): QLineEdit(parent)
{
    //按下回车键发出的信号
    connect(this, SIGNAL(returnPressed()),this, SLOT(doSearch()));

    setWindowTitle("百度搜索");
    adjustSize();
    resize(400, height());
    setFocus();
}

void SearchBox::doSearch()
{
    QString url = QString(GSEARCH_URL).arg(text());
    QDesktopServices::openUrl(QUrl(url));
    //QDesktopServices可以打开浏览器、可以打开本地文件（夹）等
}
