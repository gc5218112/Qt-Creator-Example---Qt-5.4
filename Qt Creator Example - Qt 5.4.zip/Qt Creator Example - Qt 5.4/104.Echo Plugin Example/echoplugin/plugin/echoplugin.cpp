#include <QtWidgets>
#include "echoplugin.h"

QString EchoPlugin::echo(const QString &message)
{
    return tr("回音：") + message;
}
