#include <QtWidgets>
#include "echowindow.h"
#include <QDebug>

EchoWindow::EchoWindow()
{
    createGUI();
    setLayout(layout);
    setWindowTitle("回音插件");

    if (!loadPlugin())
    {
        QMessageBox::information(this, "错误", "无法载入插件");
        lineEdit->setEnabled(false);
        button->setEnabled(false);
    }
}

void EchoWindow::sendEcho()
{
    QString text = echoInterface->echo(lineEdit->text());
    label->setText(text);
}

void EchoWindow::createGUI()
{
    lineEdit = new QLineEdit;
    label = new QLabel;
    label->setFrameStyle(QFrame::Box | QFrame::Plain);
    button = new QPushButton(tr("发消息"));

    connect(button, SIGNAL(clicked()), this, SLOT(sendEcho()));

    layout = new QGridLayout;
    layout->addWidget(new QLabel(tr("消息：")), 0, 0);
    layout->addWidget(lineEdit, 0, 1);
    layout->addWidget(new QLabel(tr("回答：")), 1, 0);
    layout->addWidget(label, 1, 1);
    layout->addWidget(button, 2, 1, Qt::AlignRight);
    layout->setSizeConstraint(QLayout::SetFixedSize);
}

bool EchoWindow::loadPlugin()
{
    QDir pluginsDir(qApp->applicationDirPath());//获取当前应用程序所在路径
    if (pluginsDir.dirName().toLower() == "debug" || pluginsDir.dirName().toLower() == "release")
    {
        pluginsDir.cdUp();
    }
    qDebug()<<pluginsDir.path();

    pluginsDir.cd("plugins");//切换到插件目录

    foreach (QString fileName, pluginsDir.entryList(QDir::Files))//遍历plugins目录下所有文件
    {
        qDebug()<<fileName;//echoplugind.dll

        //类编译成dll文件，QPluginLoader载入dll文件
        QPluginLoader pluginLoader(pluginsDir.absoluteFilePath(fileName));
        QObject *plugin = pluginLoader.instance();//使用该dll文件创建一个对象（类创建对象）
        if (plugin)
        {
            echoInterface = qobject_cast<EchoInterface *>(plugin);//强制类型转换
            if (echoInterface)//成功加载了插件
            {
                return true;
            }
        }
    }

    return false;
}
