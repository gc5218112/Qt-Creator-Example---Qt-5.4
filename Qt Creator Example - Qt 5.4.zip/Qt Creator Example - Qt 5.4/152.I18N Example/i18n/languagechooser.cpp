#include <QtWidgets>
#include "languagechooser.h"
#include "mainwindow.h"
#include <QDebug>

#ifdef Q_WS_MAC
QT_BEGIN_NAMESPACE
extern void qt_mac_set_menubar_merge(bool merge);
QT_END_NAMESPACE
#endif

LanguageChooser::LanguageChooser(const QString& defaultLang, QWidget *parent)
    : QDialog(parent, Qt::WindowStaysOnTopHint)//窗口始终置顶
{
    groupBox = new QGroupBox("Languages");

    QGridLayout *groupBoxLayout = new QGridLayout;

    QStringList qmFiles = findQmFiles();
    for (int i = 0; i < qmFiles.size(); ++i)
    {
        QCheckBox *checkBox = new QCheckBox(languageName(qmFiles[i]));
        qmFileForCheckBoxMap.insert(checkBox, qmFiles[i]);//复选框和语言名对应
        //每个复选框选中都会执行该函数
        connect(checkBox, SIGNAL(toggled(bool)), this, SLOT(checkBoxToggled()));

        if (languageMatch(defaultLang, qmFiles[i]))//选中当前语言
        {
            checkBox->setCheckState(Qt::Checked);
        }
        groupBoxLayout->addWidget(checkBox, i / 2, i % 2);
    }
    groupBox->setLayout(groupBoxLayout);

    buttonBox = new QDialogButtonBox;

    showAllButton = buttonBox->addButton("显示所有", QDialogButtonBox::ActionRole);
    hideAllButton = buttonBox->addButton("隐藏所有", QDialogButtonBox::ActionRole);

    connect(showAllButton, SIGNAL(clicked()), this, SLOT(showAll()));
    connect(hideAllButton, SIGNAL(clicked()), this, SLOT(hideAll()));

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout->addWidget(groupBox);
    mainLayout->addWidget(buttonBox);
    setLayout(mainLayout);

#ifdef Q_WS_MAC
    qt_mac_set_menubar_merge(false);
#endif

    setWindowTitle("I18N语言包翻译程序示例");
}

bool LanguageChooser::languageMatch(const QString& lang, const QString& qmFile)
{
    const QString prefix = "i18n_";
    const int langTokenLength = 2;
    return qmFile.midRef(qmFile.indexOf(prefix) + prefix.length(), langTokenLength) == lang.leftRef(langTokenLength);
}

//事件过滤器
bool LanguageChooser::eventFilter(QObject *object, QEvent *event)
{
    if (event->type() == QEvent::Close)//关闭事件
    {
        //关闭的是MainWindow类型的窗口
        MainWindow *window = qobject_cast<MainWindow *>(object);
        if (window)
        {
            QCheckBox *checkBox = mainWindowForCheckBoxMap.key(window);
            if (checkBox)
            {
                checkBox->setChecked(false);//关闭窗口也将该窗口对应的复选框取消选中
            }
        }
    }
    return QWidget::eventFilter(object, event);
}

void LanguageChooser::closeEvent(QCloseEvent * /* event */)
{
    qApp->quit();
}

void LanguageChooser::checkBoxToggled()
{
    //发射信号的复选框
    QCheckBox *checkBox = qobject_cast<QCheckBox *>(sender());
    //该复选框对应的MainWindow类型窗口
    MainWindow *window = mainWindowForCheckBoxMap[checkBox];
    if (!window)
    {
        QTranslator translator;
        translator.load(qmFileForCheckBoxMap[checkBox]);//载入对应的语言包
        qApp->installTranslator(&translator);//qApp指向QApplication app

        window = new MainWindow;
        //设置调色板 不同语言包显示窗口颜色不一样
        window->setPalette(colorForLanguage(checkBox->text()));

        window->installEventFilter(this);//为该窗口安装事件过滤器
        mainWindowForCheckBoxMap.insert(checkBox, window);
    }
    window->setVisible(checkBox->isChecked());//该窗口根据复选框是否选中设置是否可见
}

void LanguageChooser::showAll()
{
    foreach (QCheckBox *checkBox, qmFileForCheckBoxMap.keys())
    {
        checkBox->setChecked(true);
    }
}

void LanguageChooser::hideAll()
{
    foreach (QCheckBox *checkBox, qmFileForCheckBoxMap.keys())
    {
        checkBox->setChecked(false);
    }
}

//读取语言包文件 返回语言包文件的相对路径
QStringList LanguageChooser::findQmFiles()
{
    QDir dir(":/translations");
    QStringList fileNames = dir.entryList(QStringList("*.qm"), QDir::Files, QDir::Name);
    QMutableStringListIterator i(fileNames);
    while (i.hasNext())
    {
        i.next();
        i.setValue(dir.filePath(i.value()));
    }
    qDebug()<<fileNames;
    return fileNames;
}

QString LanguageChooser::languageName(const QString &qmFile)
{
    QTranslator translator;
    translator.load(qmFile);//载入语言包

    //返回关键字的翻译（语言名）
    //要翻译的内容：*.ts文件中的 "MainWindow"标签的内容、"English"标签的内容
    return translator.translate("MainWindow", "English");
}

QColor LanguageChooser::colorForLanguage(const QString &language)
{
    uint hashValue = qHash(language);//字符串的哈希值
    qDebug()<<hashValue;
    int red = 156 + (hashValue & 0x3F);
    int green = 156 + ((hashValue >> 6) & 0x3F);
    int blue = 156 + ((hashValue >> 12) & 0x3F);
    return QColor(red, green, blue);
}
