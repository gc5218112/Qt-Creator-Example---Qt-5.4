<!DOCTYPE TS><TS>
<context>
    <name>MainWindow</name>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Dosiero</translation>
    </message>
    <message>
        <source>First</source>
        <translation>Unue</translation>
    </message>
    <message>
        <source>Internationalization Example</source>
        <translation>Ekzemplo pri internaciigo</translation>
    </message>
    <message>
        <source>Isometric</source>
        <translation>Isometria</translation>
    </message>
    <message>
        <source>Language: %1</source>
        <translation>Lingvo: %1</translation>
    </message>
    <message>
        <source>English</source>
        <translation>Esperanto</translation>
    </message>
    <message>
        <source>Oblique</source>
        <translation>Oblikva</translation>
    </message>
    <message>
        <source>Perspective</source>
        <translation>Perspektiva</translation>
    </message>
    <message>
        <source>Second</source>
        <translation>Due</translation>
    </message>
    <message>
        <source>Third</source>
        <translation>Trie</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Aspekto</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>&amp;Fini</translation>
    </message>
    <message>
        <source>LTR</source>
        <translation>LTR</translation>
    </message>
</context>
</TS>
