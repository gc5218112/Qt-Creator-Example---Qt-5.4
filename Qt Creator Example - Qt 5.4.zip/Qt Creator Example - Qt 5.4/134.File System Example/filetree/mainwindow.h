#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QFile>
#include <QMainWindow>
#include <QXmlNamePool>
#include "filetree.h"
#include "ui_mainwindow.h"

class MainWindow : public QMainWindow, private Ui_MainWindow
{
    Q_OBJECT

public:
    MainWindow();

private slots:
    void on_actionOpenDirectory_triggered();

private:
    void loadDirectory(const QString &directory);

    const QXmlNamePool  m_namePool;
    const FileTree      m_fileTree;
    QXmlNodeModelIndex  m_fileNode;
};
#endif
