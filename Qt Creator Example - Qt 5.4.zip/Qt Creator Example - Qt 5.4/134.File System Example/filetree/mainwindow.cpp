#include <QFileDialog>
#include <QMessageBox>
#include <QLibraryInfo>
#include <QtXmlPatterns>
#include "mainwindow.h"
#include "xmlsyntaxhighlighter.h"
#include <QDebug>

MainWindow::MainWindow() : m_fileTree(m_namePool)
{
    setupUi(this);

    new XmlSyntaxHighlighter(fileTree->document());//左编辑框中的内容作为高亮器的待高亮的内容

    const QString dir("../filetree");
    qDebug() << dir;

    if (QDir(dir).exists())
    {
        loadDirectory(dir);
    }
    else
    {
        fileTree->setPlainText(tr("使用打开菜单项打开一个目录"));
    }
}

void MainWindow::on_actionOpenDirectory_triggered()
{
    const QString directoryName = QFileDialog::getExistingDirectory(this);
    if (!directoryName.isEmpty())
    {
        loadDirectory(directoryName);
    }
}

//将目录下所有的文件（含子目录中的文件）路径转换成xml格式
void MainWindow::loadDirectory(const QString &directory)
{
    Q_ASSERT(QDir(directory).exists());

    m_fileNode = m_fileTree.nodeFor(directory);//QXmlNodeModelIndex是XML结点模型的索引

    QXmlQuery query(m_namePool);//QXmlQuery读取XML文件
    query.bindVariable("fileTree", m_fileNode);
    query.setQuery(QUrl("qrc:/queries/wholeTree.xq"));

    QByteArray output;
    QBuffer buffer(&output);
    buffer.open(QIODevice::WriteOnly);

    QXmlFormatter formatter(query, &buffer);
    query.evaluateTo(&formatter);

    treeInfo->setText(tr("文件夹：%1中的所有文件以XML形式输出如下：").arg(QDir(directory).absolutePath()));
    fileTree->setText(tr(output.constData()));
}
