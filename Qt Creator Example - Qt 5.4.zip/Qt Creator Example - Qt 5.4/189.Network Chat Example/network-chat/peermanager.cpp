#include <QtNetwork>
#include "client.h"
#include "connection.h"
#include "peermanager.h"
#include <QDebug>

static const qint32 BroadcastInterval = 2000;//广播间隔
static const unsigned broadcastPort = 45000;//广播端口

//对等管理--发送和接收广播消息
PeerManager::PeerManager(Client *client)
    : QObject(client)
{
    this->client = client;

    QStringList envVariables;
    envVariables << "USERNAME.*" << "USER.*" << "USERDOMAIN.*" << "HOSTNAME.*" << "DOMAINNAME.*";

    QStringList environment = QProcess::systemEnvironment();//环境变量键值对的列表
    //qDebug()<<environment;

    //获取当前的用户名
    foreach (QString string, envVariables)
    {
        int index = environment.indexOf(QRegExp(string));
        if (index != -1)
        {
            QStringList stringList = environment.at(index).split('=');
            if (stringList.size() == 2)
            {
                username = stringList.at(1).toUtf8();
                break;
            }
        }
    }
    qDebug()<<username;

    if (username.isEmpty())
    {
        username = "unknown";
    }

    updateAddresses();//获取本机的广播地址和IP地址
    serverPort = 0;

    //udp通信设置
    broadcastSocket.bind(QHostAddress::Any, broadcastPort, QUdpSocket::ShareAddress | QUdpSocket::ReuseAddressHint);
    //读取广播数据报
    connect(&broadcastSocket, SIGNAL(readyRead()), this, SLOT(readBroadcastDatagram()));

    broadcastTimer.setInterval(BroadcastInterval);
    connect(&broadcastTimer, SIGNAL(timeout()), this, SLOT(sendBroadcastDatagram()));
}

//设置客户端要连接的服务端的IP
void PeerManager::setServerPort(int port)
{
    serverPort = port;
}

QByteArray PeerManager::userName() const
{
    return username;
}

void PeerManager::startBroadcasting()
{
    broadcastTimer.start();
}

bool PeerManager::isLocalHostAddress(const QHostAddress &address)
{
    foreach (QHostAddress localAddress, ipAddresses)
    {
        if (address == localAddress)
        {
            return true;
        }
    }
    return false;
}

//发送广播数据报
void PeerManager::sendBroadcastDatagram()
{
    QByteArray datagram(username);
    datagram.append('@');
    datagram.append(QByteArray::number(serverPort));

    bool validBroadcastAddresses = true;//是否有效的广播地址
    foreach (QHostAddress address, broadcastAddresses)
    {
        if (broadcastSocket.writeDatagram(datagram, address, broadcastPort) == -1)
        {
            validBroadcastAddresses = false;
        }
    }

    if (!validBroadcastAddresses)
    {
        updateAddresses();
    }
}

//读取广播数据报
void PeerManager::readBroadcastDatagram()
{
    while (broadcastSocket.hasPendingDatagrams())//hasPendingDatagrams()如果至少有一个数据报等待读取，则为true
    {
        QHostAddress senderIp;
        quint16 senderPort;
        QByteArray datagram;
        datagram.resize(broadcastSocket.pendingDatagramSize());
        if (broadcastSocket.readDatagram(datagram.data(), datagram.size(), &senderIp, &senderPort) == -1)
        {
            continue;
        }

        QList<QByteArray> list = datagram.split('@');
        if (list.size() != 2)
        {
            continue;
        }

        int senderServerPort = list.at(1).toInt();
        if (isLocalHostAddress(senderIp) && senderServerPort == serverPort)
        {
            continue;
        }

        if (!client->hasConnection(senderIp))
        {
            Connection *connection = new Connection(this);
            emit newConnection(connection);
            connection->connectToHost(senderIp, senderServerPort);
        }
    }
}

void PeerManager::updateAddresses()
{
    broadcastAddresses.clear();
    ipAddresses.clear();
    foreach (QNetworkInterface interface, QNetworkInterface::allInterfaces())
    {
        foreach (QNetworkAddressEntry entry, interface.addressEntries())
        {
            QHostAddress broadcastAddress = entry.broadcast();
            //qDebug()<<broadcastAddress.toString();
            if (broadcastAddress != QHostAddress::Null && entry.ip() != QHostAddress::LocalHost)
            {
                broadcastAddresses << broadcastAddress;
                ipAddresses << entry.ip();

                qDebug()<<broadcastAddress.toString();//广播地址:192.168.0.255
                qDebug()<<entry.ip().toString();//本机的IP地址
            }
        }
    }
}
