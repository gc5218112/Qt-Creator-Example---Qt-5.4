#include <QtNetwork>
#include "client.h"
#include "connection.h"
#include "peermanager.h"

Client::Client()
{
    peerManager = new PeerManager(this);
    peerManager->setServerPort(server.serverPort());//设置要连接的服务端的IP
    peerManager->startBroadcasting();//开始发布广播消息

    //当连接上服务端时，创建新连接
    QObject::connect(peerManager, SIGNAL(newConnection(Connection*)), this, SLOT(newConnection(Connection*)));
    QObject::connect(&server, SIGNAL(newConnection(Connection*)), this, SLOT(newConnection(Connection*)));
}

//将信息发给聊天室里的其他人
void Client::sendMessage(const QString &message)
{
    if (message.isEmpty())
    {
        return;
    }

    QList<Connection *> connections = peers.values();

    foreach (Connection *connection, connections)
    {
        connection->sendMessage(message);
    }
}

//昵称
QString Client::nickName() const
{
    return QString(peerManager->userName()) + '@' + QHostInfo::localHostName()
                   + ':' + QString::number(server.serverPort());
}

//判断本客户端是否和某一IP建立了连接
bool Client::hasConnection(const QHostAddress &senderIp, int senderPort) const
{
    if (senderPort == -1)
    {
        return peers.contains(senderIp);
    }

    if (!peers.contains(senderIp))
    {
        return false;
    }

    //判断连接列表中是否含有这个端口
    QList<Connection *> connections = peers.values(senderIp);
    foreach (Connection *connection, connections)
    {
        if (connection->peerPort() == senderPort)
        {
            return true;
        }
    }

    return false;
}

//创建了新的连接
void Client::newConnection(Connection *connection)
{
    connection->setGreetingMessage(peerManager->userName());

    connect(connection, SIGNAL(error(QAbstractSocket::SocketError)),
            this, SLOT(connectionError(QAbstractSocket::SocketError)));
    connect(connection, SIGNAL(disconnected()), this, SLOT(disconnected()));
    connect(connection, SIGNAL(readyForUse()), this, SLOT(readyForUse()));
}

//准备使用接收到的数据，将之加入到消息查看框
void Client::readyForUse()
{
    Connection *connection = qobject_cast<Connection *>(sender());
    //该连接不存在  ||   本客户端未和此连接的IP建立连接
    if (!connection || hasConnection(connection->peerAddress(), connection->peerPort()))
    {
        return;
    }

    connect(connection, SIGNAL(newMessage(QString,QString)), this, SIGNAL(newMessage(QString,QString)));

    peers.insert(connection->peerAddress(), connection);//此连接加入集合
    QString nick = connection->name();
    if (!nick.isEmpty())
    {
        emit newParticipant(nick);//新参与者
    }
}

//断开连接
void Client::disconnected()
{
    if (Connection *connection = qobject_cast<Connection *>(sender()))
    {
        removeConnection(connection);
    }
}

//连接出错则移除连接
void Client::connectionError(QAbstractSocket::SocketError /* socketError */)
{
    if (Connection *connection = qobject_cast<Connection *>(sender()))
    {
        removeConnection(connection);
    }
}

//从集合中移除连接
void Client::removeConnection(Connection *connection)
{
    if (peers.contains(connection->peerAddress()))
    {
        peers.remove(connection->peerAddress());
        QString nick = connection->name();
        if (!nick.isEmpty())
        {
            emit participantLeft(nick);
        }
    }
    connection->deleteLater();
}
