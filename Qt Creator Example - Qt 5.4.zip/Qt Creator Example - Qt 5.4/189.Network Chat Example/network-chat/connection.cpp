#include "connection.h"
#include <QtNetwork>

static const int TransferTimeout = 30 * 1000;
static const int PongTimeout = 60 * 1000;
static const int PingInterval = 5 * 1000;
static const char SeparatorToken = ' ';

//客户端用来和服务端连接、传输数据
//连接时先发送问候消息，对方接受到之后也发送一条问候消息、一条ping消息，本客户端收到ping消息后发一条pong消息
Connection::Connection(QObject *parent)
    : QTcpSocket(parent)
{
    greetingMessage = tr("undefined");
    username = tr("unknown");
    state = WaitingForGreeting;
    currentDataType = Undefined;
    numBytesForCurrentDataType = -1;
    transferTimerId = 0;
    isGreetingMessageSent = false;
    pingTimer.setInterval(PingInterval);

    QObject::connect(this, SIGNAL(readyRead()), this, SLOT(processReadyRead()));
    QObject::connect(this, SIGNAL(disconnected()), &pingTimer, SLOT(stop()));
    QObject::connect(&pingTimer, SIGNAL(timeout()), this, SLOT(sendPing()));
    QObject::connect(this, SIGNAL(connected()), this, SLOT(sendGreetingMessage()));
}

QString Connection::name() const
{
    return username;
}

void Connection::setGreetingMessage(const QString &message)
{
    greetingMessage = message;
}

//将信息发给连接的另一方
bool Connection::sendMessage(const QString &message)
{
    if (message.isEmpty())
    {
        return false;
    }

    QByteArray msg = message.toUtf8();
    //消息头是“MESSAGE ”
    QByteArray data = "MESSAGE " + QByteArray::number(msg.size()) + ' ' + msg;
    return write(data) == data.size();
}

void Connection::timerEvent(QTimerEvent *timerEvent)
{
    if (timerEvent->timerId() == transferTimerId)
    {
        abort();
        killTimer(transferTimerId);
        transferTimerId = 0;
    }
}

//处理读取到的消息，连接的另一端发过来的
void Connection::processReadyRead()
{
    if (state == WaitingForGreeting)//连接状态：等待问候
    {
        if (!readProtocolHeader())//读协议头失败
        {
            return;
        }
        if (currentDataType != Greeting)//数据类型不是问候消息
        {
            abort();//终止当前的连接并重设socket
            return;
        }
        state = ReadingGreeting;//正在读取问候消息
    }

    if (state == ReadingGreeting)
    {
        if (!hasEnoughData())//没有足够数据
        {
            return;
        }

        buffer = read(numBytesForCurrentDataType);
        if (buffer.size() != numBytesForCurrentDataType)
        {
            abort();
            return;
        }

        username = QString(buffer) + '@' + peerAddress().toString() + ':' + QString::number(peerPort());
        currentDataType = Undefined;
        numBytesForCurrentDataType = 0;
        buffer.clear();

        if (!isValid())
        {
            abort();
            return;
        }

        if (!isGreetingMessageSent)//读取到问候消息了也给对方发一条问候消息
        {
            sendGreetingMessage();
        }

        pingTimer.start();//开启ping定时器，发送ping消息
        pongTime.start();
        state = ReadyForUse;
        emit readyForUse();
    }

    //ReadyForUse 准备使用
    do {
        if (currentDataType == Undefined)
        {
            if (!readProtocolHeader())
            {
                return;
            }
        }
        if (!hasEnoughData())
        {
            return;
        }
        processData();//处理数据
    } while (bytesAvailable() > 0);
}

//发送ping消息
void Connection::sendPing()
{
    if (pongTime.elapsed() > PongTimeout)//返回自上次调用Start()或Restart()以来经过的毫秒数
    {
        abort();
        return;
    }

    write("PING 1 p");
}

//发送问候消息
void Connection::sendGreetingMessage()
{
    QByteArray greeting = greetingMessage.toUtf8();
    //问候消息的消息头是“GREETING ”
    QByteArray data = "GREETING " + QByteArray::number(greeting.size()) + ' ' + greeting;
    if (write(data) == data.size())
    {
        isGreetingMessageSent = true;
    }
}

//读取流中的数据
int Connection::readDataIntoBuffer(int maxSize)
{
    if (maxSize > MaxBufferSize)//数据太大
    {
        return 0;
    }

    int numBytesBeforeRead = buffer.size();
    if (numBytesBeforeRead == MaxBufferSize)
    {
        abort();//终止当前连接并重设socket
        return 0;
    }

    while (bytesAvailable() > 0 && buffer.size() < maxSize)
    {
        buffer.append(read(1));//读取到的内容加入字节数组
        if (buffer.endsWith(SeparatorToken))//读到结尾了
        {
            break;
        }
    }
    return buffer.size() - numBytesBeforeRead;//本次读取的内容的大小
}

//当前数据类型的长度
int Connection::dataLengthForCurrentDataType()
{
    if (bytesAvailable() <= 0 || readDataIntoBuffer() <= 0 || !buffer.endsWith(SeparatorToken))
    {
        return 0;
    }

    buffer.chop(1);
    int number = buffer.toInt();
    buffer.clear();
    return number;
}

//读协议头
bool Connection::readProtocolHeader()
{
    if (transferTimerId)//终止数据传输
    {
        killTimer(transferTimerId);
        transferTimerId = 0;
    }

    if (readDataIntoBuffer() <= 0)//没有读取到内容
    {
        transferTimerId = startTimer(TransferTimeout);//重新开启传输数据
        return false;
    }

    if (buffer == "PING ")//根据读取到的内容设置数当前数据的类型
    {
        currentDataType = Ping;
    }
    else if (buffer == "PONG ")
    {
        currentDataType = Pong;
    }
    else if (buffer == "MESSAGE ")
    {
        currentDataType = PlainText;
    }
    else if (buffer == "GREETING ")
    {
        currentDataType = Greeting;
    }
    else
    {
        currentDataType = Undefined;
        abort();
        return false;
    }

    buffer.clear();
    numBytesForCurrentDataType = dataLengthForCurrentDataType();
    return true;
}

//是否有足够数据
bool Connection::hasEnoughData()
{
    if (transferTimerId)//终止数据传输
    {
        QObject::killTimer(transferTimerId);
        transferTimerId = 0;
    }

    if (numBytesForCurrentDataType <= 0)
    {
        numBytesForCurrentDataType = dataLengthForCurrentDataType();
    }

    if (bytesAvailable() < numBytesForCurrentDataType || numBytesForCurrentDataType <= 0)
    {
        transferTimerId = startTimer(TransferTimeout);//数据不够重启定时器接收数据
        return false;
    }

    return true;
}

//处理接收到的数据
void Connection::processData()
{
    buffer = read(numBytesForCurrentDataType);
    if (buffer.size() != numBytesForCurrentDataType)
    {
        abort();
        return;
    }

    switch (currentDataType)
    {
        case PlainText:
            emit newMessage(username, QString::fromUtf8(buffer));
            break;
        case Ping:
            write("PONG 1 p");//收到ping消息向对方发pong
            break;
        case Pong:
            pongTime.restart();
            break;
        default:
            break;
    }

    //处理完了之后数据类型设为未定义，数据长度设为0
    currentDataType = Undefined;
    numBytesForCurrentDataType = 0;
    buffer.clear();
}
