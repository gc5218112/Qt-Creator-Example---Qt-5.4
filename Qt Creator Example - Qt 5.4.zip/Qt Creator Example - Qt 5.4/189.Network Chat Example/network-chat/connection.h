#ifndef CONNECTION_H
#define CONNECTION_H

#include <QHostAddress>
#include <QString>
#include <QTcpSocket>
#include <QTime>
#include <QTimer>

static const int MaxBufferSize = 1024000;

class Connection : public QTcpSocket
{
    Q_OBJECT

public:
    enum ConnectionState//连接状态
    {
        WaitingForGreeting,//等待问候
        ReadingGreeting,//读取问候
        ReadyForUse//准备使用
    };
    enum DataType
    {
        PlainText,//纯文本
        Ping,
        Pong,
        Greeting,//问候语
        Undefined//未定义
    };

    Connection(QObject *parent = 0);

    QString name() const;
    void setGreetingMessage(const QString &message);
    bool sendMessage(const QString &message);

signals:
    void readyForUse();
    void newMessage(const QString &from, const QString &message);

protected:
    void timerEvent(QTimerEvent *timerEvent) Q_DECL_OVERRIDE;

private slots:
    void processReadyRead();
    void sendPing();
    void sendGreetingMessage();

private:
    int readDataIntoBuffer(int maxSize = MaxBufferSize);
    int dataLengthForCurrentDataType();
    bool readProtocolHeader();
    bool hasEnoughData();
    void processData();

    QString greetingMessage;//欢迎信息
    QString username;
    QTimer pingTimer;
    QTime pongTime;
    QByteArray buffer;//接收传输数据的字节数组
    ConnectionState state;
    DataType currentDataType;
    int numBytesForCurrentDataType;//当前数据类型的数字字节数
    int transferTimerId;//传输计时器ID
    bool isGreetingMessageSent;//是否发送问候语
};

#endif
