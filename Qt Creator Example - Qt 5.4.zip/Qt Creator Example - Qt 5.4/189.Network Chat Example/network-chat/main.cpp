#include <QApplication>
#include "chatdialog.h"
#include <QtCore/QSettings>
#include <QtNetwork/QNetworkConfigurationManager>
#include <QtNetwork/QNetworkSession>

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    ChatDialog dialog;
    dialog.show();

    return app.exec();
}
