#include "mainwindow.h"
#include "colorswatch.h"
#include "toolbar.h"
#include <QAction>
#include <QLayout>
#include <QMenu>
#include <QMenuBar>
#include <QStatusBar>
#include <QTextEdit>
#include <QFile>
#include <QDataStream>
#include <QFileDialog>
#include <QMessageBox>
#include <QSignalMapper>
#include <QApplication>
#include <QPainter>
#include <QMouseEvent>
#include <QLineEdit>
#include <QComboBox>
#include <QLabel>
#include <QPushButton>
#include <QDebug>

Q_DECLARE_METATYPE(QDockWidget::DockWidgetFeatures)

MainWindow::MainWindow(QWidget *parent, Qt::WindowFlags flags)
    : QMainWindow(parent, flags)
{
    setObjectName("MainWindow");
    setWindowTitle("Qt主窗口示例");

    center = new QTextEdit(this);
    center->setReadOnly(true);
    center->setMinimumSize(400, 205);
    center->setText("这是中心窗口");
    setCentralWidget(center);

    setupToolBar();
    setupMenuBar();
    setupDockWidgets();

    statusBar()->showMessage(tr("状态栏"));
}

void MainWindow::setupToolBar()
{
    for (int i = 0; i < 3; ++i)
    {
        ToolBar *tb = new ToolBar(tr("工具条%1").arg(i + 1), this);
        toolBars.append(tb);
        addToolBar(tb);
    }
}

void MainWindow::setupMenuBar()
{
    QMenu *menu = menuBar()->addMenu(tr("文件"));

    QAction *action = menu->addAction(tr("保存布局"));
    connect(action, SIGNAL(triggered()), this, SLOT(saveLayout()));

    action = menu->addAction(tr("载入布局"));
    connect(action, SIGNAL(triggered()), this, SLOT(loadLayout()));

    action = menu->addAction(tr("转换布局方向"));
    connect(action, SIGNAL(triggered()), this, SLOT(switchLayoutDirection()));

    menu->addSeparator();

    menu->addAction(tr("退出"), this, SLOT(close()));

    QMenu *toolBarMenu = menuBar()->addMenu(tr("工具栏"));
    for (int i = 0; i < toolBars.count(); ++i)
    {
        toolBarMenu->addMenu(toolBars.at(i)->menu);
    }

    dockWidgetMenu = menuBar()->addMenu(tr("可停靠部件"));
}

void MainWindow::saveLayout()
{
    QString fileName = QFileDialog::getSaveFileName(this, tr("保存布局"),tr("newlayout.Layout"));
    if (fileName.isEmpty())
    {
        return;
    }
    QFile file(fileName);
    if (!file.open(QFile::WriteOnly))
    {
        QMessageBox::warning(this, tr("提示"), tr("写入文件出错"));
        return;
    }

    QByteArray geo_data = saveGeometry();
    QByteArray layout_data = saveState();

    bool ok = file.putChar((uchar)geo_data.size());
    if (ok)
    {
        ok = file.write(geo_data) == geo_data.size();
    }
    if (ok)
    {
        ok = file.write(layout_data) == layout_data.size();
    }

    if (!ok)
    {
        QMessageBox::warning(this, tr("提示"), tr("写入文件出错"));
        return;
    }
}

void MainWindow::loadLayout()
{
    QString fileName = QFileDialog::getOpenFileName(this, tr("载入布局"),".","Layout Files(*.Layout)");
    if (fileName.isEmpty())
    {
        return;
    }
    QFile file(fileName);
    if (!file.open(QFile::ReadOnly))
    {
        QMessageBox::warning(this, tr("提示"), tr("打开文件出错"));
        return;
    }

    uchar geo_size;
    QByteArray geo_data;
    QByteArray layout_data;

    bool ok = file.getChar((char*)&geo_size);
    if (ok)
    {
        geo_data = file.read(geo_size);
        ok = geo_data.size() == geo_size;
    }
    if (ok)
    {
        layout_data = file.readAll();
        ok = layout_data.size() > 0;
    }

    if (ok)
    {
        ok = restoreGeometry(geo_data);
    }
    if (ok)
    {
        ok = restoreState(layout_data);
    }

    if (!ok)
    {
        QMessageBox::warning(this, tr("提示"), tr("打开文件出错"));
        return;
    }
}

QAction *addAction(QMenu *menu, const QString &text, QActionGroup *group,
                   QSignalMapper *mapper, int id)
{
    bool first = group->actions().isEmpty();
    QAction *result = menu->addAction(text);
    result->setCheckable(true);
    result->setChecked(first);
    group->addAction(result);
    QObject::connect(result, SIGNAL(triggered()), mapper, SLOT(map()));
    mapper->setMapping(result, id);
    return result;
}

void MainWindow::setupDockWidgets()
{
    qRegisterMetaType<QDockWidget::DockWidgetFeatures>();

    mapper = new QSignalMapper(this);//信号映射器
    connect(mapper, SIGNAL(mapped(int)), this, SLOT(setCorner(int)));

    QMenu *corner_menu = dockWidgetMenu->addMenu(tr("左上角"));
    QActionGroup *group = new QActionGroup(this);
    group->setExclusive(true);
    ::addAction(corner_menu, tr("顶部"), group, mapper, 0);
    ::addAction(corner_menu, tr("左侧"), group, mapper, 1);

    corner_menu = dockWidgetMenu->addMenu(tr("右上角"));
    group = new QActionGroup(this);
    group->setExclusive(true);
    ::addAction(corner_menu, tr("顶部"), group, mapper, 2);
    ::addAction(corner_menu, tr("右侧"), group, mapper, 3);

    corner_menu = dockWidgetMenu->addMenu(tr("左下角"));
    group = new QActionGroup(this);
    group->setExclusive(true);
    ::addAction(corner_menu, tr("底部"), group, mapper, 4);
    ::addAction(corner_menu, tr("左侧"), group, mapper, 5);

    corner_menu = dockWidgetMenu->addMenu(tr("右下角"));
    group = new QActionGroup(this);
    group->setExclusive(true);
    ::addAction(corner_menu, tr("底部"), group, mapper, 6);
    ::addAction(corner_menu, tr("右侧"), group, mapper, 7);

    dockWidgetMenu->addSeparator();

    static const struct Set
    {
        const char * name;
        uint flags;
        Qt::DockWidgetArea area;
    } sets [] = {
        { "黑色字体的", 0, Qt::LeftDockWidgetArea },
        { "白色字体的", 0, Qt::RightDockWidgetArea },
        { "红色字体的", 0, Qt::TopDockWidgetArea },
        { "绿色字体的", 0, Qt::TopDockWidgetArea },
        { "蓝色字体的", 0, Qt::BottomDockWidgetArea },
        { "黄色字体的", 0, Qt::BottomDockWidgetArea }
    };
    const int setCount = sizeof(sets) / sizeof(Set);

    for (int i = 0; i < setCount; ++i)
    {
        ColorSwatch *swatch = new ColorSwatch(tr(sets[i].name), this, Qt::WindowFlags(sets[i].flags));

        QString name = QString::fromLatin1(sets[i].name);

        addDockWidget(sets[i].area, swatch);
        dockWidgetMenu->addMenu(swatch->menu);
    }

    createDockWidgetAction = new QAction(tr("添加可停靠部件"), this);
    connect(createDockWidgetAction, SIGNAL(triggered()), this, SLOT(createDockWidget()));
    destroyDockWidgetMenu = new QMenu(tr("销毁添加的可停靠部件"), this);
    destroyDockWidgetMenu->setEnabled(false);
    connect(destroyDockWidgetMenu, SIGNAL(triggered(QAction*)), this, SLOT(destroyDockWidget(QAction*)));

    dockWidgetMenu->addSeparator();
    dockWidgetMenu->addAction(createDockWidgetAction);
    dockWidgetMenu->addMenu(destroyDockWidgetMenu);
}

void MainWindow::setCorner(int id)
{
    switch (id)
    {
        case 0:
            QMainWindow::setCorner(Qt::TopLeftCorner, Qt::TopDockWidgetArea);
            break;
        case 1:
            QMainWindow::setCorner(Qt::TopLeftCorner, Qt::LeftDockWidgetArea);
            break;
        case 2:
            QMainWindow::setCorner(Qt::TopRightCorner, Qt::TopDockWidgetArea);
            break;
        case 3:
            QMainWindow::setCorner(Qt::TopRightCorner, Qt::RightDockWidgetArea);
            break;
        case 4:
            QMainWindow::setCorner(Qt::BottomLeftCorner, Qt::BottomDockWidgetArea);
            break;
        case 5:
            QMainWindow::setCorner(Qt::BottomLeftCorner, Qt::LeftDockWidgetArea);
            break;
        case 6:
            QMainWindow::setCorner(Qt::BottomRightCorner, Qt::BottomDockWidgetArea);
            break;
        case 7:
            QMainWindow::setCorner(Qt::BottomRightCorner, Qt::RightDockWidgetArea);
            break;
    }
}

void MainWindow::showEvent(QShowEvent *event)
{
    QMainWindow::showEvent(event);
}

void MainWindow::switchLayoutDirection()
{
    if (layoutDirection() == Qt::LeftToRight)
        qApp->setLayoutDirection(Qt::RightToLeft);
    else
        qApp->setLayoutDirection(Qt::LeftToRight);
}

class CreateDockWidgetDialog : public QDialog
{
public:
    CreateDockWidgetDialog(QWidget *parent = 0);

    QString objectName() const;
    Qt::DockWidgetArea location() const;

private:
    QLineEdit *m_objectName;
    QComboBox *m_location;
};

CreateDockWidgetDialog::CreateDockWidgetDialog(QWidget *parent)
    : QDialog(parent)
{
    QGridLayout *layout = new QGridLayout(this);

    layout->addWidget(new QLabel(tr("对象名称")), 0, 0);
    m_objectName = new QLineEdit;
    layout->addWidget(m_objectName, 0, 1);

    layout->addWidget(new QLabel(tr("方向")), 1, 0);
    m_location = new QComboBox;
    m_location->setEditable(false);
    m_location->addItem(tr("上"));
    m_location->addItem(tr("左"));
    m_location->addItem(tr("右"));
    m_location->addItem(tr("下"));
    layout->addWidget(m_location, 1, 1);

    QHBoxLayout *buttonLayout = new QHBoxLayout;
    layout->addLayout(buttonLayout, 2, 0, 1, 2);
    buttonLayout->addStretch();

    QPushButton *cancelButton = new QPushButton(tr("取消"));
    connect(cancelButton, SIGNAL(clicked()), this, SLOT(reject()));
    buttonLayout->addWidget(cancelButton);
    QPushButton *okButton = new QPushButton(tr("确定"));
    connect(okButton, SIGNAL(clicked()), this, SLOT(accept()));
    buttonLayout->addWidget(okButton);

    okButton->setDefault(true);
}

QString CreateDockWidgetDialog::objectName() const
{
    return m_objectName->text();
}

Qt::DockWidgetArea CreateDockWidgetDialog::location() const
{
    switch (m_location->currentIndex())
    {
        case 0: return Qt::TopDockWidgetArea;
        case 1: return Qt::LeftDockWidgetArea;
        case 2: return Qt::RightDockWidgetArea;
        case 3: return Qt::BottomDockWidgetArea;
    }
    return Qt::NoDockWidgetArea;
}

void MainWindow::createDockWidget()
{
    CreateDockWidgetDialog dialog(this);
    int ret = dialog.exec();
    if (ret == QDialog::Rejected)
    {
        return;
    }

    QDockWidget *dw = new QDockWidget;
    dw->setObjectName(dialog.objectName());
    dw->setWindowTitle(dialog.objectName());
    dw->setWidget(new QTextEdit);

    Qt::DockWidgetArea area = dialog.location();
    switch (area)
    {
        case Qt::LeftDockWidgetArea:
        case Qt::RightDockWidgetArea:
        case Qt::TopDockWidgetArea:
        case Qt::BottomDockWidgetArea:
            addDockWidget(area, dw);
            break;
    }

    extraDockWidgets.append(dw);
    destroyDockWidgetMenu->setEnabled(true);
    destroyDockWidgetMenu->addAction(new QAction(dialog.objectName(), this));
}

void MainWindow::destroyDockWidget(QAction *action)
{
    int index = destroyDockWidgetMenu->actions().indexOf(action);
    delete extraDockWidgets.takeAt(index);
    destroyDockWidgetMenu->removeAction(action);
    action->deleteLater();

    if (destroyDockWidgetMenu->isEmpty())
    {
        destroyDockWidgetMenu->setEnabled(false);
    }
}
