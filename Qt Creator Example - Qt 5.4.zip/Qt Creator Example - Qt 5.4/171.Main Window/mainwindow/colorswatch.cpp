#include "colorswatch.h"
#include <QAction>
#include <QtEvents>
#include <QFrame>
#include <QMainWindow>
#include <QMenu>
#include <QPainter>
#include <QImage>
#include <QColor>
#include <QDialog>
#include <QGridLayout>
#include <QSpinBox>
#include <QLabel>
#include <QPainterPath>
#include <QPushButton>
#include <QHBoxLayout>
#include <QBitmap>
#include <QtDebug>

#undef DEBUG_SIZEHINTS

QColor bgColorForName(const QString &name)
{
    if (name == "黑色字体的")
    {
        return QColor("#D8D8D8");
    }
    else if (name == "白色字体的")
    {
        return QColor("#F1F1F1");
    }
    else if (name == "红色字体的")
    {
        return QColor("#F1D8D8");
    }
    else if (name == "绿色字体的")
    {
        return QColor("#D8E4D8");
    }
    else if (name == "蓝色字体的")
    {
        return QColor("#D8D8F1");
    }
    else if (name == "黄色字体的")
    {
        return QColor("#F1F0D8");
    }
    return QColor(name).light(110);
}

QColor fgColorForName(const QString &name)
{
    if (name == "黑色字体的")
    {
        return QColor("#6C6C6C");
    }
    else if (name == "白色字体的")
    {
        return QColor("#F8F8F8");
    }
    else if (name == "红色字体的")
    {
        return QColor("#F86C6C");
    }
    else if (name == "绿色字体的")
    {
        return QColor("#6CB26C");
    }
    else if (name == "蓝色字体的")
    {
        return QColor("#6C6CF8");
    }
    else if (name == "黄色字体的")
    {
        return QColor("#F8F76C");
    }
    return QColor(name);
}

class ColorDock : public QFrame
{
    Q_OBJECT
public:
    ColorDock(const QString &c, QWidget *parent);

    virtual QSize sizeHint() const Q_DECL_OVERRIDE;
    virtual QSize minimumSizeHint() const Q_DECL_OVERRIDE;

    void setCustomSizeHint(const QSize &size);

protected:
    void paintEvent(QPaintEvent *) Q_DECL_OVERRIDE;
    QString color;
    QSize szHint, minSzHint;
};

ColorDock::ColorDock(const QString &c, QWidget *parent)
    : QFrame(parent) , color(c)
{
    QFont font = this->font();
    font.setPointSize(8);
    setFont(font);
    szHint = QSize(-1, -1);
    minSzHint = QSize(125, 75);
}

QSize ColorDock::sizeHint() const
{
    return szHint;
}

QSize ColorDock::minimumSizeHint() const
{
    return minSzHint;
}

void ColorDock::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing);
    p.fillRect(rect(), bgColorForName(color));

    p.save();

    extern void render_qt_text(QPainter *, int, int, const QColor &);
    render_qt_text(&p, width(), height(), fgColorForName(color));

    p.restore();
}

static QSpinBox *createSpinBox(int value, QWidget *parent, int max = 1000)
{
    QSpinBox *result = new QSpinBox(parent);
    result->setMinimum(-1);
    result->setMaximum(max);
    result->setValue(value);
    return result;
}

void ColorDock::setCustomSizeHint(const QSize &size)
{
    szHint = size;
    updateGeometry();
}

ColorSwatch::ColorSwatch(const QString &colorName, QWidget *parent, Qt::WindowFlags flags)
    : QDockWidget(parent, flags)
{
    setObjectName(colorName + tr("可停靠部件"));
    setWindowTitle(objectName() + tr(" [*]"));

    QFrame *swatch = new ColorDock(colorName, this);
    swatch->setFrameStyle(QFrame::Box | QFrame::Sunken);

    setWidget(swatch);

    closableAction = new QAction(tr("可关闭"), this);
    closableAction->setCheckable(true);
    connect(closableAction, SIGNAL(triggered(bool)), SLOT(changeClosable(bool)));

    movableAction = new QAction(tr("可移动"), this);
    movableAction->setCheckable(true);
    connect(movableAction, SIGNAL(triggered(bool)), SLOT(changeMovable(bool)));

    floatableAction = new QAction(tr("可浮动"), this);
    floatableAction->setCheckable(true);
    connect(floatableAction, SIGNAL(triggered(bool)), SLOT(changeFloatable(bool)));

    verticalTitleBarAction = new QAction(tr("垂直标题栏"), this);
    verticalTitleBarAction->setCheckable(true);
    connect(verticalTitleBarAction, SIGNAL(triggered(bool)), SLOT(changeVerticalTitleBar(bool)));

    floatingAction = new QAction(tr("变为浮动状态"), this);
    floatingAction->setCheckable(true);
    connect(floatingAction, SIGNAL(triggered(bool)), SLOT(changeFloating(bool)));

    allowedAreasActions = new QActionGroup(this);
    allowedAreasActions->setExclusive(false);

    allowLeftAction = new QAction(tr("允许在窗口左侧"), this);
    allowLeftAction->setCheckable(true);
    connect(allowLeftAction, SIGNAL(triggered(bool)), SLOT(allowLeft(bool)));

    allowRightAction = new QAction(tr("允许在窗口右侧"), this);
    allowRightAction->setCheckable(true);
    connect(allowRightAction, SIGNAL(triggered(bool)), SLOT(allowRight(bool)));

    allowTopAction = new QAction(tr("允许在窗口上方"), this);
    allowTopAction->setCheckable(true);
    connect(allowTopAction, SIGNAL(triggered(bool)), SLOT(allowTop(bool)));

    allowBottomAction = new QAction(tr("允许在窗口下方"), this);
    allowBottomAction->setCheckable(true);
    connect(allowBottomAction, SIGNAL(triggered(bool)), SLOT(allowBottom(bool)));

    allowedAreasActions->addAction(allowLeftAction);
    allowedAreasActions->addAction(allowRightAction);
    allowedAreasActions->addAction(allowTopAction);
    allowedAreasActions->addAction(allowBottomAction);

    areaActions = new QActionGroup(this);
    areaActions->setExclusive(true);

    leftAction = new QAction(tr("移动到左侧") , this);
    leftAction->setCheckable(true);
    connect(leftAction, SIGNAL(triggered(bool)), SLOT(placeLeft(bool)));

    rightAction = new QAction(tr("移动到右侧") , this);
    rightAction->setCheckable(true);
    connect(rightAction, SIGNAL(triggered(bool)), SLOT(placeRight(bool)));

    topAction = new QAction(tr("移动到上方") , this);
    topAction->setCheckable(true);
    connect(topAction, SIGNAL(triggered(bool)), SLOT(placeTop(bool)));

    bottomAction = new QAction(tr("移动到下方") , this);
    bottomAction->setCheckable(true);
    connect(bottomAction, SIGNAL(triggered(bool)), SLOT(placeBottom(bool)));

    areaActions->addAction(leftAction);
    areaActions->addAction(rightAction);
    areaActions->addAction(topAction);
    areaActions->addAction(bottomAction);

    connect(movableAction, SIGNAL(triggered(bool)), areaActions, SLOT(setEnabled(bool)));
    connect(movableAction, SIGNAL(triggered(bool)), allowedAreasActions, SLOT(setEnabled(bool)));
    connect(movableAction, SIGNAL(triggered(bool)), floatableAction, SLOT(setEnabled(bool)));

    connect(floatableAction, SIGNAL(triggered(bool)), floatingAction, SLOT(setEnabled(bool)));
    connect(floatingAction, SIGNAL(triggered(bool)), floatableAction, SLOT(setDisabled(bool)));

    splitHMenu = new QMenu(this);
    splitHMenu->setTitle(tr("水平拆分为"));
    connect(splitHMenu, SIGNAL(triggered(QAction*)), this, SLOT(splitInto(QAction*)));

    splitVMenu = new QMenu(this);
    splitVMenu->setTitle(tr("垂直拆分为"));
    connect(splitVMenu, SIGNAL(triggered(QAction*)), this, SLOT(splitInto(QAction*)));

    menu = new QMenu(colorName, this);
    menu->addAction(toggleViewAction());
    menu->addSeparator();
    menu->addAction(closableAction);
    menu->addAction(movableAction);
    menu->addAction(floatableAction);
    menu->addAction(floatingAction);
    menu->addAction(verticalTitleBarAction);
    menu->addSeparator();
    menu->addActions(allowedAreasActions->actions());
    menu->addSeparator();
    menu->addActions(areaActions->actions());
    menu->addSeparator();
    menu->addMenu(splitHMenu);
    menu->addMenu(splitVMenu);
    menu->addSeparator();

    connect(menu, SIGNAL(aboutToShow()), this, SLOT(updateContextMenu()));
}

void ColorSwatch::updateContextMenu()
{
    QMainWindow *mainWindow = qobject_cast<QMainWindow *>(parentWidget());
    const Qt::DockWidgetArea area = mainWindow->dockWidgetArea(this);
    const Qt::DockWidgetAreas areas = allowedAreas();

    closableAction->setChecked(features() & QDockWidget::DockWidgetClosable);
    if (windowType() == Qt::Drawer)
    {
        floatableAction->setEnabled(false);
        floatingAction->setEnabled(false);
        movableAction->setEnabled(false);
        verticalTitleBarAction->setChecked(false);
    }
    else
    {
        floatableAction->setChecked(features() & QDockWidget::DockWidgetFloatable);
        floatingAction->setChecked(isWindow());
        movableAction->setChecked(features() & QDockWidget::DockWidgetMovable);
        verticalTitleBarAction->setChecked(features() & QDockWidget::DockWidgetVerticalTitleBar);
    }

    allowLeftAction->setChecked(isAreaAllowed(Qt::LeftDockWidgetArea));
    allowRightAction->setChecked(isAreaAllowed(Qt::RightDockWidgetArea));
    allowTopAction->setChecked(isAreaAllowed(Qt::TopDockWidgetArea));
    allowBottomAction->setChecked(isAreaAllowed(Qt::BottomDockWidgetArea));

    if (allowedAreasActions->isEnabled())
    {
        allowLeftAction->setEnabled(area != Qt::LeftDockWidgetArea);
        allowRightAction->setEnabled(area != Qt::RightDockWidgetArea);
        allowTopAction->setEnabled(area != Qt::TopDockWidgetArea);
        allowBottomAction->setEnabled(area != Qt::BottomDockWidgetArea);
    }

    leftAction->blockSignals(true);
    rightAction->blockSignals(true);
    topAction->blockSignals(true);
    bottomAction->blockSignals(true);

    leftAction->setChecked(area == Qt::LeftDockWidgetArea);
    rightAction->setChecked(area == Qt::RightDockWidgetArea);
    topAction->setChecked(area == Qt::TopDockWidgetArea);
    bottomAction->setChecked(area == Qt::BottomDockWidgetArea);

    leftAction->blockSignals(false);
    rightAction->blockSignals(false);
    topAction->blockSignals(false);
    bottomAction->blockSignals(false);

    if (areaActions->isEnabled())
    {
        leftAction->setEnabled(areas & Qt::LeftDockWidgetArea);
        rightAction->setEnabled(areas & Qt::RightDockWidgetArea);
        topAction->setEnabled(areas & Qt::TopDockWidgetArea);
        bottomAction->setEnabled(areas & Qt::BottomDockWidgetArea);
    }

    splitHMenu->clear();
    splitVMenu->clear();
    QList<ColorSwatch*> dock_list = mainWindow->findChildren<ColorSwatch*>();
    foreach (ColorSwatch *dock, dock_list)
    {
        splitHMenu->addAction(dock->objectName());
        splitVMenu->addAction(dock->objectName());
    }
}

void ColorSwatch::splitInto(QAction *action)
{
    QMainWindow *mainWindow = qobject_cast<QMainWindow *>(parentWidget());
    QList<ColorSwatch*> dock_list = mainWindow->findChildren<ColorSwatch*>();
    ColorSwatch *target = 0;
    foreach (ColorSwatch *dock, dock_list)
    {
        if (action->text() == dock->objectName())
        {
            target = dock;
            break;
        }
    }
    if (target == 0)
        return;

    Qt::Orientation o = action->parent() == splitHMenu
                        ? Qt::Horizontal : Qt::Vertical;
    mainWindow->splitDockWidget(target, this, o);
}

void ColorSwatch::contextMenuEvent(QContextMenuEvent *event)
{
    event->accept();
    menu->exec(event->globalPos());
}

void ColorSwatch::allow(Qt::DockWidgetArea area, bool a)
{
    Qt::DockWidgetAreas areas = allowedAreas();
    areas = a ? areas | area : areas & ~area;
    setAllowedAreas(areas);

    if (areaActions->isEnabled())
    {
        leftAction->setEnabled(areas & Qt::LeftDockWidgetArea);
        rightAction->setEnabled(areas & Qt::RightDockWidgetArea);
        topAction->setEnabled(areas & Qt::TopDockWidgetArea);
        bottomAction->setEnabled(areas & Qt::BottomDockWidgetArea);
    }
}

void ColorSwatch::place(Qt::DockWidgetArea area, bool p)
{
    if (!p) return;

    QMainWindow *mainWindow = qobject_cast<QMainWindow *>(parentWidget());
    mainWindow->addDockWidget(area, this);

    if (allowedAreasActions->isEnabled())
    {
        allowLeftAction->setEnabled(area != Qt::LeftDockWidgetArea);
        allowRightAction->setEnabled(area != Qt::RightDockWidgetArea);
        allowTopAction->setEnabled(area != Qt::TopDockWidgetArea);
        allowBottomAction->setEnabled(area != Qt::BottomDockWidgetArea);
    }
}

void ColorSwatch::setCustomSizeHint(const QSize &size)
{
    if (ColorDock *dock = qobject_cast<ColorDock*>(widget()))
        dock->setCustomSizeHint(size);
}

void ColorSwatch::changeClosable(bool on)
{
    setFeatures(on ? features() | DockWidgetClosable : features() & ~DockWidgetClosable);
}

void ColorSwatch::changeMovable(bool on)
{
    setFeatures(on ? features() | DockWidgetMovable : features() & ~DockWidgetMovable);
}

void ColorSwatch::changeFloatable(bool on)
{
    setFeatures(on ? features() | DockWidgetFloatable : features() & ~DockWidgetFloatable);
}

void ColorSwatch::changeFloating(bool floating)
{
    setFloating(floating);
}

void ColorSwatch::allowLeft(bool a)
{
    allow(Qt::LeftDockWidgetArea, a);
}

void ColorSwatch::allowRight(bool a)
{
    allow(Qt::RightDockWidgetArea, a);
}

void ColorSwatch::allowTop(bool a)
{
    allow(Qt::TopDockWidgetArea, a);
}

void ColorSwatch::allowBottom(bool a)
{
    allow(Qt::BottomDockWidgetArea, a);
}

void ColorSwatch::placeLeft(bool p)
{
    place(Qt::LeftDockWidgetArea, p);
}

void ColorSwatch::placeRight(bool p)
{
    place(Qt::RightDockWidgetArea, p);
}

void ColorSwatch::placeTop(bool p)
{
    place(Qt::TopDockWidgetArea, p);
}

void ColorSwatch::placeBottom(bool p)
{
    place(Qt::BottomDockWidgetArea, p);
}

void ColorSwatch::changeVerticalTitleBar(bool on)
{
    setFeatures(on ? features() | DockWidgetVerticalTitleBar : features() & ~DockWidgetVerticalTitleBar);
}

#include "colorswatch.moc"
