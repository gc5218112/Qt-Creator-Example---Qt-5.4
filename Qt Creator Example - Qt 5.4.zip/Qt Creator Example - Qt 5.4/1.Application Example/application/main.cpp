#include <QApplication>
#include "mainwindow.h"

int main(int argc, char *argv[])
{
    Q_INIT_RESOURCE(application);
/*
Q_INIT_RESOURCE
是Qt的资源机制（resource mechanism)，它使程序在编译时将图片存储在.cpp文件中，
运行时连接它。
这要求你建立一个Qt资源文件：***.qrc，在***.qrc中指定图片位置。编译
时编译器将***.qrc中指定的图片以二进制数的形式存储到Qt自动建立的名为qrc_***.cpp
的文件中，这里的***就是你建立***.qrc时的名字，而你在main()函数中使用
Q_INIT_RESOURCE(name)宏时的name也必须是这个***。
即在main.cpp中：Q_INIT_RESOURCE(资源文件名)
*/
    QApplication app(argc, argv);

    MainWindow mainWin;
    mainWin.resize(600,400);
    mainWin.show();
    return app.exec();
}
