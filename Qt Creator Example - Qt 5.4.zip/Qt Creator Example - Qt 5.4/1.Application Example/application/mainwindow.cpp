#include <QtWidgets>
#include "mainwindow.h"

MainWindow::MainWindow()
{
    textEdit = new QPlainTextEdit;//创建纯文本编辑框对象
    setCentralWidget(textEdit);//设置中心区域部件

    createActions();//创建动作
    createMenus();//创建菜单
    createToolBars();//创建工具栏
    createStatusBar();//创建状态栏

    connect(textEdit->document(), SIGNAL(contentsChanged()),//当编辑框中的内容改变时 标题栏显示的文件名加星号
            this, SLOT(documentWasModified()));

    setCurrentFile("");//初始时当前文件路径设为空
}

//窗口关闭事件
void MainWindow::closeEvent(QCloseEvent *event)
{
    if (maybeSave())//是否要保存文件
    {
        event->accept();//事件处理函数接收此窗口关闭事件
    }
    else
    {
        event->ignore();//事件处理函数忽略此窗口关闭事件
    }
}

//新建文件 槽函数
void MainWindow::newFile()
{
    if (maybeSave())
    {
        textEdit->clear();
        setCurrentFile("");
    }
}

//打开文件 槽函数
void MainWindow::open()
{
    if (maybeSave())
    {
        QString fileName = QFileDialog::getOpenFileName(this);
        if (!fileName.isEmpty())
        {
            loadFile(fileName);
        }
    }
}

//执行保存操作
bool MainWindow::save()
{
    if (curFile.isEmpty()) //新建的文件 另存为
    {
        return saveAs();
    }
    else //打开的文件 保存修改
    {
        return saveFile(curFile);
    }
}

//另存为
bool MainWindow::saveAs()
{
    QFileDialog dialog(this);
    //设置模态对话框
    dialog.setWindowModality(Qt::WindowModal);
    dialog.setAcceptMode(QFileDialog::AcceptSave);
    QStringList files;
    if (dialog.exec())//阻塞 控制权交给对话框
    {
        files = dialog.selectedFiles();//选择的文件路径
    }
    else
    {
        return false;
    }

    return saveFile(files.at(0));
}

//标题栏的窗口标题（文件名）是否加星号
void MainWindow::documentWasModified()
{
    setWindowModified(textEdit->document()->isModified());
}

//创建动作
void MainWindow::createActions()
{
    //新建文件
    newAct = new QAction(QIcon(":/images/new.png"), tr("&新建"), this);
    newAct->setShortcuts(QKeySequence::New);
    newAct->setStatusTip(tr("新建文件"));//状态栏显示提示信息
    connect(newAct, SIGNAL(triggered()), this, SLOT(newFile()));

    //打开文件
    openAct = new QAction(QIcon(":/images/open.png"), tr("&打开..."), this);
    openAct->setShortcuts(QKeySequence::Open);
    openAct->setStatusTip(tr("打开文件"));
    connect(openAct, SIGNAL(triggered()), this, SLOT(open()));

    //保存文件
    saveAct = new QAction(QIcon(":/images/save.png"), tr("&保存"), this);
    saveAct->setShortcuts(QKeySequence::Save);
    saveAct->setStatusTip(tr("保存文件到磁盘"));
    connect(saveAct, SIGNAL(triggered()), this, SLOT(save()));

    //另存为
    saveAsAct = new QAction(tr("另存为..."), this);
    saveAsAct->setShortcuts(QKeySequence::SaveAs);
    saveAsAct->setStatusTip(tr("文档另存为新文件"));
    connect(saveAsAct, SIGNAL(triggered()), this, SLOT(saveAs()));

    //关闭程序
    exitAct = new QAction(tr("关闭"), this);
    exitAct->setShortcuts(QKeySequence::Quit);
    exitAct->setStatusTip(tr("关闭应用"));
    connect(exitAct, SIGNAL(triggered()), this, SLOT(close()));

    //剪切
    cutAct = new QAction(QIcon(":/images/cut.png"), tr("剪切"), this);
    cutAct->setShortcuts(QKeySequence::Cut);
    cutAct->setStatusTip(tr("将当前选择的内容剪切到剪贴板"));
    connect(cutAct, SIGNAL(triggered()), textEdit, SLOT(cut()));

    //复制
    copyAct = new QAction(QIcon(":/images/copy.png"), tr("复制"), this);
    copyAct->setShortcuts(QKeySequence::Copy);
    copyAct->setStatusTip(tr("将当前选择的内容复制到剪贴板"));
    connect(copyAct, SIGNAL(triggered()), textEdit, SLOT(copy()));

    //粘贴
    pasteAct = new QAction(QIcon(":/images/paste.png"), tr("粘贴"), this);
    pasteAct->setShortcuts(QKeySequence::Paste);
    pasteAct->setStatusTip(tr("从剪切板粘贴内容"));
    connect(pasteAct, SIGNAL(triggered()), textEdit, SLOT(paste()));

    cutAct->setEnabled(false);//剪切动作默认不可用
    copyAct->setEnabled(false);//复制动作默认不可用
    connect(textEdit, SIGNAL(copyAvailable(bool)),//剪切功能只有选中内容以后才可用
            cutAct, SLOT(setEnabled(bool)));
    connect(textEdit, SIGNAL(copyAvailable(bool)),
            copyAct, SLOT(setEnabled(bool)));
}

//创建菜单
void MainWindow::createMenus()
{
    fileMenu = menuBar()->addMenu(tr("文件"));
    fileMenu->addAction(newAct);//添加动作
    fileMenu->addAction(openAct);
    fileMenu->addAction(saveAct);
    fileMenu->addAction(saveAsAct);
    fileMenu->addSeparator();//增加一条分隔线
    fileMenu->addAction(exitAct);

    editMenu = menuBar()->addMenu(tr("编辑"));
    editMenu->addAction(cutAct);
    editMenu->addAction(copyAct);
    editMenu->addAction(pasteAct);
}

//创建工具栏
void MainWindow::createToolBars()
{
    fileToolBar = addToolBar(tr("文件"));
    fileToolBar->addAction(newAct);
    fileToolBar->addAction(openAct);
    fileToolBar->addAction(saveAct);

    editToolBar = addToolBar(tr("编辑"));
    editToolBar->addAction(cutAct);
    editToolBar->addAction(copyAct);
    editToolBar->addAction(pasteAct);
}

//创建状态栏
void MainWindow::createStatusBar()
{
    statusBar()->showMessage(tr("准备好了"));//本来默认就有状态栏 这里设置初始状态信息
}

//是否提示保存
bool MainWindow::maybeSave()
{
    if (textEdit->document()->isModified())//document()编辑框中的内容  isModified()是否被修改过
    {
        //编辑框中内容被修改过则弹出一个含三个按钮的对话框
        QMessageBox::StandardButton ret;//标准按钮
        ret = QMessageBox::warning(this,//ret：点击的按钮是哪个
                                   tr("Application"),
                                   tr("文档已改变，是否保存修改?"),
                                   QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel);
        if (ret == QMessageBox::Save)//按下了保存按钮
        {
            return save();//执行保存后退出
        }
        else if (ret == QMessageBox::Cancel)//按下取消按钮
        {
            return false;//返回false 不保存
        }
    }
    return true;
}

//载入文件 流的方式
void MainWindow::loadFile(const QString &fileName)
{
    QFile file(fileName);
    if (!file.open(QFile::ReadOnly | QFile::Text))
    {
        QMessageBox::warning(this,
                             tr("程序提示"),
                             tr("无法载入文件%1:\n%2.").arg(fileName).arg(file.errorString()));
        return;
    }

    QTextStream in(&file);//读取流
#ifndef QT_NO_CURSOR
    QApplication::setOverrideCursor(Qt::WaitCursor);//设置鼠标光标样式
#endif
    textEdit->setPlainText(in.readAll());//内容加载到编辑器
#ifndef QT_NO_CURSOR
    QApplication::restoreOverrideCursor();//恢复鼠标光标样式
#endif
    setCurrentFile(fileName);//设置当前文件
    statusBar()->showMessage(tr("文件已载入"), 2000);//状态栏显示信息
}

//执行保存文件操作
bool MainWindow::saveFile(const QString &fileName)
{
    QFile file(fileName);
    if (!file.open(QFile::WriteOnly | QFile::Text))//打开文件（无则创建）
    {
        QMessageBox::warning(this, tr("警告"),
                             tr("无法载入文件%1:\n%2.").arg(fileName).arg(file.errorString()));
        return false;
    }

    QTextStream out(&file);//文件内容写入流
#ifndef QT_NO_CURSOR
    QApplication::setOverrideCursor(Qt::WaitCursor);//设置鼠标的光标为：等待
#endif
    out << textEdit->toPlainText();//编辑框的内容写入流
#ifndef QT_NO_CURSOR
    QApplication::restoreOverrideCursor();//恢复鼠标光标形状
#endif
    setCurrentFile(fileName);//设置当前文件
    statusBar()->showMessage(tr("文件已保存"), 2000);//状态栏显示：已保存 显示2秒钟
    return true;
}

//设置当前文件
void MainWindow::setCurrentFile(const QString &fileName)
{
    curFile = fileName;//设置当前文件路径
    textEdit->document()->setModified(false);//当前文件修改状态：未修改
    setWindowModified(false);//窗口的标题上去掉*号

    QString shownName = curFile;
    if (curFile.isEmpty())
    {
        shownName = "新建文件.txt";//指定的默认文件名
    }
    setWindowFilePath(shownName);//设置窗口文件路径 在标题栏显示和setWindowTitle(shownName);效果一样
}
