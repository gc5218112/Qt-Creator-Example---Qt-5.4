#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
/*
QT_BEGIN_NAMESPACE：
其实就是个宏，Qt4最初是没有Qt命名空间的，后来才加上的，编译Qt源码时会有选项，是否将这些
类放到专用的Qt命名空间内，默认是没有的。这就出来问题了，为了统一，如果你的代码在默认没有
Qt命名空间的ＳＤＫ中编译，那你就不用在前置声明下面这些类的时候加上命名空间，但如果你在有
Qt命名空间的ＳＤＫ中编译，那就得加上命名空间了，为了屏蔽这个差异，使得你的源码能在这两种
情况下都进行编译，Qt提供了QT_BEGIN_NAMESPACE宏，这样开发者就省得自己来用程序或宏进行处理了。
*/
class QAction;
class QMenu;
class QPlainTextEdit;
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow();

protected:
    void closeEvent(QCloseEvent *event) Q_DECL_OVERRIDE;

private slots:
    void newFile();
    void open();
    bool save();
    bool saveAs();
    void documentWasModified();

private:
    void createActions();
    void createMenus();
    void createToolBars();
    void createStatusBar();
    bool maybeSave();
    void loadFile(const QString &fileName);
    bool saveFile(const QString &fileName);
    void setCurrentFile(const QString &fileName);

    QPlainTextEdit *textEdit;//纯文本的编辑框 不支持富文本
    QString curFile;//当前文件路径 新建文件为空 打开的文件不为空

    QMenu *fileMenu;
    QMenu *editMenu;
    QToolBar *fileToolBar;
    QToolBar *editToolBar;
    QAction *newAct;
    QAction *openAct;
    QAction *saveAct;
    QAction *saveAsAct;
    QAction *exitAct;
    QAction *cutAct;
    QAction *copyAct;
    QAction *pasteAct;
};

#endif
