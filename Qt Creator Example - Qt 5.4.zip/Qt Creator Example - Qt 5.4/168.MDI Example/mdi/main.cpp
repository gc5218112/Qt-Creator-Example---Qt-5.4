#include <QApplication>
#include <QCommandLineParser>
#include <QCommandLineOption>
#include "mainwindow.h"

int main(int argc, char *argv[])
{
    Q_INIT_RESOURCE(mdi);

    QApplication app(argc, argv);

    QCoreApplication::setApplicationVersion(QT_VERSION_STR);

    QCommandLineParser parser;//QCommandLineParser解析命令行参数
    parser.setApplicationDescription("Qt MDI Example");
    parser.addHelpOption();
    parser.addVersionOption();
    parser.addPositionalArgument("文件名", "打开文件");
    parser.process(app);

    MainWindow mainWin;
    //当以命令行的方式运行此程序时，将命令行所带的参数解释为文件路径 打开文件
    foreach (const QString &fileName, parser.positionalArguments())
    {
        mainWin.openFile(fileName);
    }
    mainWin.show();
    return app.exec();
}
