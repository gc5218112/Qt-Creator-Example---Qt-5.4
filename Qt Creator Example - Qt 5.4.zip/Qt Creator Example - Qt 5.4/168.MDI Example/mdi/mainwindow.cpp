#include <QtWidgets>
#include "mainwindow.h"
#include "mdichild.h"
#include <QDebug>

MainWindow::MainWindow()
{
    mdiArea = new QMdiArea;//多文档窗口主窗口，可容纳多个子窗口
    mdiArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAsNeeded);
    mdiArea->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
    setCentralWidget(mdiArea);
//    Qt::ScrollBarAsNeeded   0   滚动条根据需要打开或关闭，默认的策略，根据滚动区域内控件的实际大小和滚动区域的大小比较
//    Qt::ScrollBarAlwaysOff  1   滚动条始终处于关闭状态
//    Qt::ScrollBarAlwaysOn   2   滚动条始终处于打开状态

    //多文档主窗口中添加子窗口时发送的信号
    connect(mdiArea, SIGNAL(subWindowActivated(QMdiSubWindow*)), this, SLOT(updateMenus()));

    windowMapper = new QSignalMapper(this);//信号映射器
    //信号映射器的map()执行完了之后发送mapped信号
    connect(windowMapper, SIGNAL(mapped(QWidget*)), this, SLOT(setActiveSubWindow(QWidget*)));

    createActions();
    createMenus();
    createToolBars();
    createStatusBar();
    updateMenus();

    setWindowTitle(tr("多文档界面"));
    setUnifiedTitleAndToolBarOnMac(true);
}

void MainWindow::closeEvent(QCloseEvent *event)
{
    mdiArea->closeAllSubWindows();
    if (mdiArea->currentSubWindow())
    {
        event->ignore();
    }
    else
    {
        event->accept();
    }
}

//创建一个新文件
void MainWindow::newFile()
{
    MdiChild *child = createMdiChild();//创建子窗口
    child->newFile();
    child->show();
}

//打开已有文件
void MainWindow::open()
{
    QString fileName = QFileDialog::getOpenFileName(this);
    if (!fileName.isEmpty())
    {
        QMdiSubWindow *existing = findMdiChild(fileName);//先检查一下是否已有子窗口打开了该文件
        if (existing)
        {
            mdiArea->setActiveSubWindow(existing);//设置该子窗口为活动窗口
            return;
        }

        if (openFile(fileName))
        {
            statusBar()->showMessage(tr("文件已载入"), 2000);//持续2秒
        }
    }
}

//打开文件
bool MainWindow::openFile(const QString &fileName)
{
    MdiChild *child = createMdiChild();//新建子窗口载入该文件
    const bool succeeded = child->loadFile(fileName);
    if (succeeded)
    {
        child->show();
    }
    else
    {
        child->close();
    }
    return succeeded;
}

//保存文件 保存当前活动子窗口的内容
void MainWindow::save()
{
    if (activeMdiChild() && activeMdiChild()->save())
    {
        statusBar()->showMessage(tr("文件已保存"), 2000);
    }
}

//另存为
void MainWindow::saveAs()
{
    if (activeMdiChild() && activeMdiChild()->saveAs())
    {
        statusBar()->showMessage(tr("文件已保存"), 2000);
    }
}

#ifndef QT_NO_CLIPBOARD
//剪切
void MainWindow::cut()
{
    if (activeMdiChild())//对当前活动窗口操作
    {
        activeMdiChild()->cut();
    }
}

//复制
void MainWindow::copy()
{
    if (activeMdiChild())
    {
        activeMdiChild()->copy();
    }
}

//粘贴
void MainWindow::paste()
{
    if (activeMdiChild())
    {
        activeMdiChild()->paste();
    }
}
#endif

//更新菜单，菜单项可用否切换
void MainWindow::updateMenus()
{
    bool hasMdiChild = (activeMdiChild() != 0);//当前活动子窗口是否为空
    saveAct->setEnabled(hasMdiChild);
    saveAsAct->setEnabled(hasMdiChild);
#ifndef QT_NO_CLIPBOARD
    pasteAct->setEnabled(hasMdiChild);
#endif
    closeAct->setEnabled(hasMdiChild);
    closeAllAct->setEnabled(hasMdiChild);
    tileAct->setEnabled(hasMdiChild);
    cascadeAct->setEnabled(hasMdiChild);
    nextAct->setEnabled(hasMdiChild);
    previousAct->setEnabled(hasMdiChild);
    separatorAct->setVisible(hasMdiChild);

#ifndef QT_NO_CLIPBOARD
    //当前活动子窗口中的光标处的文本是否被选中
    bool hasSelection = (activeMdiChild() && activeMdiChild()->textCursor().hasSelection());
    cutAct->setEnabled(hasSelection);
    copyAct->setEnabled(hasSelection);
#endif
}

//更新子窗口菜单
void MainWindow::updateWindowMenu()
{
    windowMenu->clear();
    windowMenu->addAction(closeAct);
    windowMenu->addAction(closeAllAct);
    windowMenu->addSeparator();
    windowMenu->addAction(tileAct);
    windowMenu->addAction(cascadeAct);
    windowMenu->addSeparator();
    windowMenu->addAction(nextAct);
    windowMenu->addAction(previousAct);
    windowMenu->addAction(separatorAct);

    QList<QMdiSubWindow *> windows = mdiArea->subWindowList();//主窗口的子窗口列表
    separatorAct->setVisible(!windows.isEmpty());//此分隔符当主窗口中有子窗口时可见

    for (int i = 0; i < windows.size(); ++i)
    {
        MdiChild *child = qobject_cast<MdiChild *>(windows.at(i)->widget());

        QString text = tr("%1 %2").arg(i + 1).arg(child->userFriendlyCurrentFile());

        QAction *action  = windowMenu->addAction(text);
        action->setCheckable(true);//增加一个可选中状态
        action ->setChecked(child == activeMdiChild());//当前子窗口是活动窗口是选中

        //将这些动作的点击信号绑定到信号映射器 当点击动作时map()执行
        connect(action, SIGNAL(triggered()), windowMapper, SLOT(map()));

        //建立映射关系：当前action的点击信号triggered()<---->当前的子窗口
        windowMapper->setMapping(action, windows.at(i));
        /*
        QSignalMapper是信号转换器，可将无参数的信号转换成有参数的信号
        当前action的点击信号triggered()<---->当前的子窗口
        可将action的triggered()信号转成map(QObject *sender)
        即map(windows.at(i))
        构造函数中又绑定了
        connect(windowMapper, SIGNAL(mapped(QWidget*)), this, SLOT(setActiveSubWindow(QWidget*)));
        即点击action，setActiveSubWindow执行，对应的子窗口被设为活动窗口
        */
    }
}

//创建子窗口
MdiChild *MainWindow::createMdiChild()
{
    MdiChild *child = new MdiChild;
    mdiArea->addSubWindow(child);//作为多文档主窗口的子窗口（将子窗口转换成QMdiSubWindow类型）

#ifndef QT_NO_CLIPBOARD
    //编辑框中选择或取消选择文本时会发出此信号
    connect(child, SIGNAL(copyAvailable(bool)), cutAct, SLOT(setEnabled(bool)));
    connect(child, SIGNAL(copyAvailable(bool)), copyAct, SLOT(setEnabled(bool)));
#endif

    return child;
}

void MainWindow::createActions()
{
    newAct = new QAction(QIcon(":/images/new.png"), tr("新建"), this);
    newAct->setShortcuts(QKeySequence::New);
    newAct->setStatusTip(tr("创建一个新文件"));
    connect(newAct, SIGNAL(triggered()), this, SLOT(newFile()));

    openAct = new QAction(QIcon(":/images/open.png"), tr("&打开"), this);
    openAct->setShortcuts(QKeySequence::Open);
    openAct->setStatusTip(tr("打开已有文件"));
    connect(openAct, SIGNAL(triggered()), this, SLOT(open()));

    saveAct = new QAction(QIcon(":/images/save.png"), tr("保存"), this);
    saveAct->setShortcuts(QKeySequence::Save);
    saveAct->setStatusTip(tr("保存文件到磁盘"));
    connect(saveAct, SIGNAL(triggered()), this, SLOT(save()));

    saveAsAct = new QAction(tr("另存为"), this);
    saveAsAct->setShortcuts(QKeySequence::SaveAs);
    saveAsAct->setStatusTip(tr("使用其他名称保存文件"));
    connect(saveAsAct, SIGNAL(triggered()), this, SLOT(saveAs()));

    exitAct = new QAction(tr("退出"), this);
    exitAct->setShortcuts(QKeySequence::Quit);
    exitAct->setStatusTip(tr("退出程序"));
    //本应用关闭所有窗口
    connect(exitAct, SIGNAL(triggered()), qApp, SLOT(closeAllWindows()));

#ifndef QT_NO_CLIPBOARD
    cutAct = new QAction(QIcon(":/images/cut.png"), tr("剪切"), this);
    cutAct->setShortcuts(QKeySequence::Cut);
    cutAct->setStatusTip(tr("剪切选定内容到剪切板"));
    connect(cutAct, SIGNAL(triggered()), this, SLOT(cut()));

    copyAct = new QAction(QIcon(":/images/copy.png"), tr("复制"), this);
    copyAct->setShortcuts(QKeySequence::Copy);
    copyAct->setStatusTip(tr("复制选定内容到剪切板"));
    connect(copyAct, SIGNAL(triggered()), this, SLOT(copy()));

    pasteAct = new QAction(QIcon(":/images/paste.png"), tr("粘贴"), this);
    pasteAct->setShortcuts(QKeySequence::Paste);
    pasteAct->setStatusTip(tr("粘贴剪贴板内容"));
    connect(pasteAct, SIGNAL(triggered()), this, SLOT(paste()));
#endif

    closeAct = new QAction(tr("关闭当前活动子窗口"), this);
    closeAct->setStatusTip(tr("关闭当前活动子窗口"));
    connect(closeAct, SIGNAL(triggered()), mdiArea, SLOT(closeActiveSubWindow()));

    closeAllAct = new QAction(tr("关闭所有子窗口"), this);
    closeAllAct->setStatusTip(tr("关闭所有子窗口"));
    connect(closeAllAct, SIGNAL(triggered()), mdiArea, SLOT(closeAllSubWindows()));

    tileAct = new QAction(tr("子窗口充满主窗口"), this);
    tileAct->setStatusTip(tr("当前所有子窗口自动充满主窗口"));
    connect(tileAct, SIGNAL(triggered()), mdiArea, SLOT(tileSubWindows()));

    cascadeAct = new QAction(tr("子窗口串联排列"), this);
    cascadeAct->setStatusTip(tr("当前所有子窗口串联排列"));
    connect(cascadeAct, SIGNAL(triggered()), mdiArea, SLOT(cascadeSubWindows()));

    nextAct = new QAction(tr("切换到下一个子窗口"), this);
    nextAct->setShortcuts(QKeySequence::NextChild);
    nextAct->setStatusTip(tr("移动焦点到下一个子窗口"));
    connect(nextAct, SIGNAL(triggered()), mdiArea, SLOT(activateNextSubWindow()));

    previousAct = new QAction(tr("切换到前一个子窗口"), this);
    previousAct->setShortcuts(QKeySequence::PreviousChild);
    previousAct->setStatusTip(tr("移动焦点到前一个子窗口"));
    connect(previousAct, SIGNAL(triggered()), mdiArea, SLOT(activatePreviousSubWindow()));

    separatorAct = new QAction(this);//分隔符
    separatorAct->setSeparator(true);
}

void MainWindow::createMenus()
{
    fileMenu = menuBar()->addMenu(tr("文件"));
    fileMenu->addAction(newAct);
    fileMenu->addAction(openAct);
    fileMenu->addAction(saveAct);
    fileMenu->addAction(saveAsAct);
    fileMenu->addSeparator();
    QAction *action = fileMenu->addAction(tr("交换布局方向"));
    connect(action, SIGNAL(triggered()), this, SLOT(switchLayoutDirection()));
    fileMenu->addAction(exitAct);

    editMenu = menuBar()->addMenu(tr("编辑"));
#ifndef QT_NO_CLIPBOARD
    editMenu->addAction(cutAct);
    editMenu->addAction(copyAct);
    editMenu->addAction(pasteAct);
#endif

    windowMenu = menuBar()->addMenu(tr("子窗口"));
    updateWindowMenu();
    //这个信号是在菜单显示给用户之前发出的
    connect(windowMenu, SIGNAL(aboutToShow()), this, SLOT(updateWindowMenu()));

    menuBar()->addSeparator();
}

void MainWindow::createToolBars()
{
    fileToolBar = addToolBar(tr("文件"));
    fileToolBar->addAction(newAct);
    fileToolBar->addAction(openAct);
    fileToolBar->addAction(saveAct);

#ifndef QT_NO_CLIPBOARD
    editToolBar = addToolBar(tr("编辑"));
    editToolBar->addAction(cutAct);
    editToolBar->addAction(copyAct);
    editToolBar->addAction(pasteAct);
#endif
}

void MainWindow::createStatusBar()
{
    statusBar()->showMessage(tr("准备好了"));
}

//将当前活动子窗口（转换成自定义的子窗口类型后）返回
MdiChild *MainWindow::activeMdiChild()
{
    if (QMdiSubWindow *activeSubWindow = mdiArea->activeSubWindow())
    {
        return qobject_cast<MdiChild *>(activeSubWindow->widget());
    }

    return 0;
}

//打开文件时查找各个子窗口，看要打开的文件是否已经有子窗口打开了，有则返回该窗口
QMdiSubWindow *MainWindow::findMdiChild(const QString &fileName)
{
    QString canonicalFilePath = QFileInfo(fileName).canonicalFilePath();

    foreach (QMdiSubWindow *window, mdiArea->subWindowList())
    {
        MdiChild *mdiChild = qobject_cast<MdiChild *>(window->widget());
        if (mdiChild->currentFile() == canonicalFilePath)
        {
            return window;
        }
    }
    return 0;
}

//交换布局方向
void MainWindow::switchLayoutDirection()
{
    if (layoutDirection() == Qt::LeftToRight)
    {
        qApp->setLayoutDirection(Qt::RightToLeft);
    }
    else
    {
        qApp->setLayoutDirection(Qt::LeftToRight);
    }
}

//设置当前子窗口为活动窗口
void MainWindow::setActiveSubWindow(QWidget *window)
{
    if (!window)
    {
        return;
    }
    mdiArea->setActiveSubWindow(qobject_cast<QMdiSubWindow *>(window));
}
