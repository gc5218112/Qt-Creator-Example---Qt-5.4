#include <QtWidgets>
#include "mdichild.h"
#include <QDebug>

//作为多文档窗口的子窗口，是一个编辑框
MdiChild::MdiChild()
{
    setAttribute(Qt::WA_DeleteOnClose);//确保关闭窗口时释放资源
    isUntitled = true;//此窗口未命名
}

//新建文件
void MdiChild::newFile()
{
    static int sequenceNumber = 1;//序列数 ，记录创建的文件个数

    isUntitled = true;
    curFile = tr("文档%1.txt").arg(sequenceNumber++);
    setWindowTitle(curFile + "[*]");//设置为子窗口的标题名

    //此编辑框中的文档  contentsChanged当编辑框中文档的内容被修改
    connect(document(), SIGNAL(contentsChanged()), this, SLOT(documentWasModified()));
}

//载入文件
bool MdiChild::loadFile(const QString &fileName)
{
    QFile file(fileName);
    if (!file.open(QFile::ReadOnly | QFile::Text))
    {
        QMessageBox::warning(this, tr("多文档窗口"), tr("无法读取文件%1:\n%2").arg(fileName).arg(file.errorString()));
        return false;
    }

    QTextStream in(&file);
    QApplication::setOverrideCursor(Qt::WaitCursor);//设置光标
    setPlainText(in.readAll());//读取文件所有内容放到编辑框中
    QApplication::restoreOverrideCursor();//恢复光标

    setCurrentFile(fileName);

    //若编辑框中文档被更改
    connect(document(), SIGNAL(contentsChanged()), this, SLOT(documentWasModified()));

    return true;
}

//保存文档
bool MdiChild::save()
{
    if (isUntitled)//未命名，新建的文档
    {
        return saveAs();
    }
    else//即打开的文档
    {
        return saveFile(curFile);
    }
}

//文档另存为
bool MdiChild::saveAs()
{
    QString fileName = QFileDialog::getSaveFileName(this, tr("另存为"), curFile);
    if (fileName.isEmpty())
    {
        return false;
    }

    return saveFile(fileName);
}

//保存文档
bool MdiChild::saveFile(const QString &fileName)
{
    QFile file(fileName);
    if (!file.open(QFile::WriteOnly | QFile::Text))
    {
        QMessageBox::warning(this, tr("保存文档"), tr("无法写入文件%1:\n%2.").arg(fileName).arg(file.errorString()));
        return false;
    }

    QTextStream out(&file);
    QApplication::setOverrideCursor(Qt::WaitCursor);
    out << toPlainText();
    QApplication::restoreOverrideCursor();

    setCurrentFile(fileName);
    return true;
}

//当前文件的文件名
QString MdiChild::userFriendlyCurrentFile()
{
    return strippedName(curFile);
}

//关闭事件
void MdiChild::closeEvent(QCloseEvent *event)
{
    if (maybeSave())
    {
        event->accept();
    }
    else
    {
        event->ignore();
    }
}

//当编辑框中的文档是否被修改，在不在窗口加*号
void MdiChild::documentWasModified()
{
    setWindowModified(document()->isModified());
}

//文件是否保存
bool MdiChild::maybeSave()
{
    if (document()->isModified())
    {
        QMessageBox::StandardButton ret;
        ret = QMessageBox::warning(this, tr("多文档窗口"), tr("'%1' 文件已改变，是否保存？").arg(userFriendlyCurrentFile()), QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel);
        if (ret == QMessageBox::Save)
        {
            return save();
        }
        else if (ret == QMessageBox::Cancel)
        {
            return false;
        }
    }
    return true;
}

//设置当前文件
void MdiChild::setCurrentFile(const QString &fileName)
{
    curFile = QFileInfo(fileName).canonicalFilePath();//当前文件路径
    isUntitled = false;//设置此窗口未命名：否
    document()->setModified(false);//设置文档未被更改过
    setWindowModified(false);//是否在窗口标题后面加*号：否
    setWindowTitle(userFriendlyCurrentFile() + "[*]");
}

//从文件完整路径提取文件名
QString MdiChild::strippedName(const QString &fullFileName)
{
    return QFileInfo(fullFileName).fileName();
}
