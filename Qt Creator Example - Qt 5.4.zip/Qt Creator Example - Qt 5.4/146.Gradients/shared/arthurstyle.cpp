#include "arthurstyle.h"
#include "arthurwidgets.h"
#include <QLayout>
#include <QPainter>
#include <QPainterPath>
#include <QPixmapCache>
#include <QRadioButton>
#include <QString>
#include <QStyleOption>
#include <QtDebug>

QPixmap cached(const QString &img)
{
    if (QPixmap *p = QPixmapCache::find(img))//如果在缓存取能找到该图像
    {
        return *p;
    }

    QPixmap pm;
    //RGB通道的抖动模式：OrderedDither
    //Alpha通道的抖动模式：Qt::OrderedAlphaDither
    pm = QPixmap::fromImage(QImage(img), Qt::OrderedDither | Qt::OrderedAlphaDither);
    if (pm.isNull())
    {
        return QPixmap();
    }

    QPixmapCache::insert(img, pm);//图片插入缓存区
    return pm;
}

ArthurStyle::ArthurStyle()
    : QCommonStyle()
{
    Q_INIT_RESOURCE(shared);//通过初始化使用指定的基本名称.qrc文件中指定的资源。通常情况下，Qt的资源在启动时会自动加载
}

//绘制悬停矩形 效果是矩形两端是半个椭圆   （二）
void ArthurStyle::drawHoverRect(QPainter *painter, const QRect &r) const
{
    qreal h = r.height();//矩形的高
    qreal h2 = r.height() / qreal(2);//矩形高的一半

    QPainterPath path;//绘制路径 用于绘制复杂的图形
    path.addRect(r.x() + h2, r.y() + 0, r.width() - h2 * 2, r.height());//矩形
    path.addEllipse(r.x(), r.y(), h, h);//椭圆
    path.addEllipse(r.x() + r.width() - h, r.y(), h, h);//椭圆
    path.setFillRule(Qt::WindingFill);//填充路径WindingFill
    painter->setPen(Qt::NoPen);
    painter->setBrush(QColor(191, 215, 191));//图形颜色

    painter->setRenderHint(QPainter::Antialiasing);//抗锯齿
    painter->drawPath(path);
}

//绘制原始控件
void ArthurStyle::drawPrimitive(PrimitiveElement element, //要绘制的元素 组件等
                                const QStyleOption *option,//保存了 painter 绘制时所需要的所有数据信息
                                QPainter *painter, //绘制者
                                const QWidget *widget) const//用于辅助绘制
{

    Q_ASSERT(option);
    switch (element)
    {
        case PE_FrameFocusRect:
            break;

        case PE_IndicatorRadioButton://单选按钮
            //强制类型转换    转换为绘制Button所需信息
            if (const QStyleOptionButton *button = qstyleoption_cast<const QStyleOptionButton *>(option))
            {
                //如果是鼠标悬停状态
                bool hover = (button->state & State_Enabled) && (button->state & State_MouseOver);
                painter->save();
                QPixmap radio;
                if (hover)
                {
                    drawHoverRect(painter, widget->rect());//绘制悬停矩形
                }

                if (button->state & State_Sunken)//单选按钮选中还未松开鼠标时
                {
                    radio = cached(":res/images/radiobutton-on.png");
                }
                else if (button->state & State_On)//单选按钮选中松开鼠标后
                {
                    radio = cached(":res/images/radiobutton_on.png");
                }
                else
                {
                    radio = cached(":res/images/radiobutton_off.png");
                }
                painter->drawPixmap(button->rect.topLeft(), radio);//绘制出图像

                painter->restore();
            }
            break;

        case PE_PanelButtonCommand://命令按钮
            if (const QStyleOptionButton *button = qstyleoption_cast<const QStyleOptionButton *>(option))
            {
                //鼠标是否是悬停状态
                bool hover = (button->state & State_Enabled) && (button->state & State_MouseOver);

                painter->save();
                const QPushButton *pushButton = qobject_cast<const QPushButton *>(widget);
                Q_ASSERT(pushButton);
                QWidget *parent = pushButton->parentWidget();
                if (parent && qobject_cast<QGroupBox *>(parent))//按钮放在组合框QGroupBox中
                {
                    QLinearGradient lg(0, 0, 0, parent->height());//线性渐变
                    lg.setColorAt(0, QColor(224,224,224));//颜色变化很小
                    lg.setColorAt(1, QColor(255,255,255));
                    painter->setPen(Qt::NoPen);
                    painter->setBrush(lg);

                    painter->setBrushOrigin(-widget->mapToParent(QPoint(0,0)));

                    painter->drawRect(button->rect);
                    painter->setBrushOrigin(0,0);
                }

                //按钮是否是按下鼠标还未抬起 或 按下鼠标松开
                bool down = (button->state & State_Sunken) || (button->state & State_On);

                QPixmap left, right, mid;
                if (down)
                {
                    left = cached(":res/images/button_pressed_cap_left.png");
                    right = cached(":res/images/button_pressed_cap_right.png");
                    mid = cached(":res/images/button_pressed_stretch.png");
                }
                else
                {
                    left = cached(":res/images/button_normal_cap_left.png");
                    right = cached(":res/images/button_normal_cap_right.png");
                    mid = cached(":res/images/button_normal_stretch.png");
                }
                // 左  矩形范围内平铺中  右
                painter->drawPixmap(button->rect.topLeft(), left);
                //drawTiledPixmap 绘制平铺图像
                painter->drawTiledPixmap(QRect(button->rect.x() + left.width(),
                                               button->rect.y(),
                                               button->rect.width() - left.width() - right.width(),
                                               left.height()),
                                         mid);
                painter->drawPixmap(button->rect.x() + button->rect.width() - right.width(),
                                    button->rect.y(),
                                    right);
                if (hover)
                {
                    //鼠标悬停在按钮上 改变按钮颜色
                    painter->fillRect(widget->rect().adjusted(3,5,-3,-5), QColor(31,127,31,63));
                }
                painter->restore();
            }
            break;

        case PE_FrameGroupBox://组合框
            if (const QStyleOptionFrameV2 *group = qstyleoption_cast<const QStyleOptionFrameV2 *>(option))
            {
                const QRect &r = group->rect;

                painter->save();
                int radius = 14;
                int radius2 = radius*2;

                QPainterPath clipPath;//绘制复杂图形
                clipPath.moveTo(radius, 0);
                clipPath.arcTo(r.right() - radius2, 0, radius2, radius2, 90, -90);
                clipPath.arcTo(r.right() - radius2, r.bottom() - radius2, radius2, radius2, 0, -90);
                clipPath.arcTo(r.left(), r.bottom() - radius2, radius2, radius2, 270, -90);
                clipPath.arcTo(r.left(), r.top(), radius2, radius2, 180, -90);
                painter->setClipPath(clipPath);

                QPixmap titleStretch = cached(":res/images/title_stretch.png");
                QPixmap topLeft = cached(":res/images/groupframe_topleft.png");
                QPixmap topRight = cached(":res/images/groupframe_topright.png");
                QPixmap bottomLeft = cached(":res/images/groupframe_bottom_left.png");
                QPixmap bottomRight = cached(":res/images/groupframe_bottom_right.png");
                QPixmap leftStretch = cached(":res/images/groupframe_left_stretch.png");
                QPixmap topStretch = cached(":res/images/groupframe_top_stretch.png");
                QPixmap rightStretch = cached(":res/images/groupframe_right_stretch.png");
                QPixmap bottomStretch = cached(":res/images/groupframe_bottom_stretch.png");

                QLinearGradient lg(0, 0, 0, r.height());//线性渐变
                lg.setColorAt(0, QColor(224,224,224));
                //lg.setColorAt(0, QColor(255,0,0));
                lg.setColorAt(1, QColor(255,255,255));
                painter->setPen(Qt::NoPen);
                painter->setBrush(lg);
                painter->drawRect(r.adjusted(0, titleStretch.height()/2, 0, 0));
                painter->setClipping(false);

                int topFrameOffset = titleStretch.height()/2 - 2;
                painter->drawPixmap(r.topLeft() + QPoint(0, topFrameOffset), topLeft);
                painter->drawPixmap(r.topRight() - QPoint(topRight.width()-1, 0)
                                    + QPoint(0, topFrameOffset), topRight);
                painter->drawPixmap(r.bottomLeft() - QPoint(0, bottomLeft.height()-1), bottomLeft);
                painter->drawPixmap(r.bottomRight() - QPoint(bottomRight.width()-1,
                                    bottomRight.height()-1), bottomRight);

                QRect left = r;
                left.setY(r.y() + topLeft.height() + topFrameOffset);
                left.setWidth(leftStretch.width());
                left.setHeight(r.height() - topLeft.height() - bottomLeft.height() - topFrameOffset);
                painter->drawTiledPixmap(left, leftStretch);

                QRect top = r;
                top.setX(r.x() + topLeft.width());
                top.setY(r.y() + topFrameOffset);
                top.setWidth(r.width() - topLeft.width() - topRight.width());
                top.setHeight(topLeft.height());
                painter->drawTiledPixmap(top, topStretch);

                QRect right = r;
                right.setX(r.right() - rightStretch.width()+1);
                right.setY(r.y() + topRight.height() + topFrameOffset);
                right.setWidth(rightStretch.width());
                right.setHeight(r.height() - topRight.height()
                                - bottomRight.height() - topFrameOffset);
                painter->drawTiledPixmap(right, rightStretch);

                QRect bottom = r;
                bottom.setX(r.x() + bottomLeft.width());
                bottom.setY(r.bottom() - bottomStretch.height()+1);
                bottom.setWidth(r.width() - bottomLeft.width() - bottomRight.width());
                bottom.setHeight(bottomLeft.height());
                painter->drawTiledPixmap(bottom, bottomStretch);
                painter->restore();
            }
            break;

        default:
            QCommonStyle::drawPrimitive(element, option, painter, widget);
            break;
    }
    return;
}

//绘制组合控件
void ArthurStyle::drawComplexControl(ComplexControl control,
                                     const QStyleOptionComplex *option,
                                     QPainter *painter,
                                     const QWidget *widget) const
{
    switch (control)
    {
        case CC_Slider://滑动条
            if (const QStyleOptionSlider *slider = qstyleoption_cast<const QStyleOptionSlider *>(option))
            {
                QRect groove = subControlRect(CC_Slider, option, SC_SliderGroove, widget);
                QRect handle = subControlRect(CC_Slider, option, SC_SliderHandle, widget);

                painter->save();

                bool hover = (slider->state & State_Enabled) && (slider->state & State_MouseOver);
                if (hover)
                {
                    QRect moderated = widget->rect().adjusted(0, 4, 0, -4);
                    drawHoverRect(painter, moderated);
                }

                if ((option->subControls & SC_SliderGroove) && groove.isValid())
                {
                    QPixmap grv = cached(":res/images/slider_bar.png");
                    painter->drawPixmap(QRect(groove.x() + 5, groove.y(),
                                              groove.width() - 10, grv.height()),
                                        grv);
                }
                if ((option->subControls & SC_SliderHandle) && handle.isValid())
                {
                    QPixmap hndl = cached(":res/images/slider_thumb_on.png");
                    painter->drawPixmap(handle.topLeft(), hndl);
                }

                painter->restore();
            }
            break;
        case CC_GroupBox://组合框
            if (const QStyleOptionGroupBox *groupBox = qstyleoption_cast<const QStyleOptionGroupBox *>(option))
            {
                QStyleOptionGroupBox groupBoxCopy(*groupBox);
                groupBoxCopy.subControls &= ~SC_GroupBoxLabel;
                QCommonStyle::drawComplexControl(control, &groupBoxCopy, painter, widget);

                if (groupBox->subControls & SC_GroupBoxLabel)
                {
                    const QRect &r = groupBox->rect;

                    QPixmap titleLeft = cached(":res/images/title_cap_left.png");
                    QPixmap titleRight = cached(":res/images/title_cap_right.png");
                    QPixmap titleStretch = cached(":res/images/title_stretch.png");

                    int txt_width = groupBox->fontMetrics.width(groupBox->text) + 20;
                    painter->drawPixmap(r.center().x() - txt_width/2, 0, titleLeft);

                    QRect tileRect = subControlRect(control, groupBox, SC_GroupBoxLabel, widget);
                    painter->drawTiledPixmap(tileRect, titleStretch);
                    painter->drawPixmap(tileRect.x() + tileRect.width(), 0, titleRight);

                    int opacity = 31;
                    painter->setPen(QColor(0, 0, 0, opacity));
                    painter->drawText(tileRect.translated(0, 1),
                                      Qt::AlignVCenter | Qt::AlignHCenter, groupBox->text);
                    painter->drawText(tileRect.translated(2, 1),
                                      Qt::AlignVCenter | Qt::AlignHCenter, groupBox->text);
                    painter->setPen(QColor(0, 0, 0, opacity * 2));
                    painter->drawText(tileRect.translated(1, 1),
                                      Qt::AlignVCenter | Qt::AlignHCenter, groupBox->text);
                    painter->setPen(Qt::white);
                    painter->drawText(tileRect, Qt::AlignVCenter | Qt::AlignHCenter, groupBox->text);
                }
            }
            break;
        default:
            QCommonStyle::drawComplexControl(control, option, painter, widget);
            break;
    }
    return;
}

void ArthurStyle::drawControl(QStyle::ControlElement element,
                              const QStyleOption *option,
                              QPainter *painter,
                              const QWidget *widget) const
{
    switch (element)
    {
        case CE_RadioButtonLabel:
            if (const QStyleOptionButton *button = qstyleoption_cast<const QStyleOptionButton *>(option))
            {
                if (button->text.isEmpty())
                {
                    QCommonStyle::drawControl(element, option, painter, widget);
                }
                else
                {
                    painter->save();
                    painter->setPen(Qt::black);
                    painter->drawText(button->rect, Qt::AlignVCenter, button->text);
                    painter->restore();
                }
            }
            break;
        case CE_PushButtonLabel:
            if (const QStyleOptionButton *button = qstyleoption_cast<const QStyleOptionButton *>(option))
            {
                if (button->text.isEmpty())
                {
                    QCommonStyle::drawControl(element, option, painter, widget);
                }
                else
                {
                    painter->save();
                    painter->setPen(Qt::black);
                    painter->drawText(button->rect, Qt::AlignVCenter | Qt::AlignHCenter, button->text);
                    painter->restore();
                }
            }
            break;
        default:
            QCommonStyle::drawControl(element, option, painter, widget);
            break;
        }
}

QRect ArthurStyle::subControlRect(ComplexControl control,
                                  const QStyleOptionComplex *option,
                                  SubControl subControl,
                                  const QWidget *widget) const
{
    QRect rect;

    switch (control)
    {
        default:
            rect = QCommonStyle::subControlRect(control, option, subControl, widget);
            break;
        case CC_GroupBox:
            if (const QStyleOptionGroupBox *group = qstyleoption_cast<const QStyleOptionGroupBox *>(option))
            {
                switch (subControl)
                {
                    default:
                        rect = QCommonStyle::subControlRect(control, option, subControl, widget);
                        break;
                    case SC_GroupBoxContents:
                        rect = QCommonStyle::subControlRect(control, option, subControl, widget);
                        rect.adjust(0, -8, 0, 0);
                        break;
                    case SC_GroupBoxFrame:
                        rect = group->rect;
                        break;
                    case SC_GroupBoxLabel:
                        QPixmap titleLeft = cached(":res/images/title_cap_left.png");
                        QPixmap titleRight = cached(":res/images/title_cap_right.png");
                        QPixmap titleStretch = cached(":res/images/title_stretch.png");
                        int txt_width = group->fontMetrics.width(group->text) + 20;
                        rect = QRect(group->rect.center().x() - txt_width/2 + titleLeft.width(), 0,
                                     txt_width - titleLeft.width() - titleRight.width(),
                                     titleStretch.height());
                        break;
            }
        }
        break;
    }

    if (control == CC_Slider && subControl == SC_SliderHandle)
    {
        rect.setWidth(13);
        rect.setHeight(27);
    }
    else if (control == CC_Slider && subControl == SC_SliderGroove)
    {
        rect.setHeight(9);
        rect.moveTop(27/2 - 9/2);
    }
    return rect;
}

QSize ArthurStyle::sizeFromContents(ContentsType type,
                                    const QStyleOption *option,
                                    const QSize &size,
                                    const QWidget *widget) const
{
    QSize newSize = QCommonStyle::sizeFromContents(type, option, size, widget);

    switch (type)
    {
        case CT_RadioButton:
            newSize += QSize(20, 0);
            break;

        case CT_PushButton:
            newSize.setHeight(26);
            break;

        case CT_Slider:
            newSize.setHeight(27);
            break;

        default:
            break;
    }

    return newSize;
}

int ArthurStyle::pixelMetric(PixelMetric pm,
                             const QStyleOption *opt,
                             const QWidget *widget) const
{
    if (pm == PM_SliderLength)
    {
        return 13;
    }
    return QCommonStyle::pixelMetric(pm, opt, widget);
}

void ArthurStyle::polish(QWidget *widget)
{
    if (widget->layout() && qobject_cast<QGroupBox *>(widget))
    {
        if (widget->findChildren<QGroupBox *>().size() == 0)
        {
            widget->layout()->setSpacing(0);
            widget->layout()->setMargin(12);
        }
        else
        {
            widget->layout()->setMargin(13);
        }
    }

    if (qobject_cast<QPushButton *>(widget)
        || qobject_cast<QRadioButton *>(widget)
        || qobject_cast<QSlider *>(widget))
    {
        widget->setAttribute(Qt::WA_Hover);
    }

    QPalette pal = widget->palette();
    if (widget->isWindow())
    {
        pal.setColor(QPalette::Background, QColor(241, 241, 241));
        widget->setPalette(pal);
    }
}

void ArthurStyle::unpolish(QWidget *widget)
{
    if (qobject_cast<QPushButton *>(widget)
        || qobject_cast<QRadioButton *>(widget)
        || qobject_cast<QSlider *>(widget))
    {
        widget->setAttribute(Qt::WA_Hover, false);
    }
}

void ArthurStyle::polish(QPalette &palette)
{
    palette.setColor(QPalette::Background, QColor(241, 241, 241));
}

QRect ArthurStyle::subElementRect(SubElement element, const QStyleOption *option, const QWidget *widget) const
{
    QRect r;
    switch(element)
    {
        case SE_RadioButtonClickRect:
            r = widget->rect();
            break;
        case SE_RadioButtonContents:
            r = widget->rect().adjusted(20, 0, 0, 0);
            break;
        default:
            r = QCommonStyle::subElementRect(element, option, widget);
            break;
    }

    if (qobject_cast<const QRadioButton*>(widget))
    {
        r = r.adjusted(5, 0, -5, 0);
    }

    return r;
}
