#include "gradients.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    Q_INIT_RESOURCE(gradients);

    QApplication app(argc, argv);

    GradientWidget gradientWidget(0);
    QStyle *arthurStyle = new ArthurStyle();
    gradientWidget.setStyle(arthurStyle);
    QList<QWidget *> widgets = gradientWidget.findChildren<QWidget *>();

    foreach (QWidget *w, widgets)
    {
        w->setStyle(arthurStyle);
        w->setAttribute(Qt::WA_AcceptTouchEvents);
    }
    gradientWidget.show();

    return app.exec();
}
