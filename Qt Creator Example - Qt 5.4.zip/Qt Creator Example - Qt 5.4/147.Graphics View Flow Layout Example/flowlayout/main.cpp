#include "window.h"
#include <QApplication>
#include <QGraphicsView>

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    QGraphicsScene scene;
    QGraphicsView *view = new QGraphicsView(&scene);
    Window *w = new Window;
    scene.addItem(w);

    view->resize(400, 300);
    view->show();

    return app.exec();
}
