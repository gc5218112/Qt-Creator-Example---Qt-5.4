#include <QGraphicsWidget>

class Window : public QGraphicsWidget
{
    Q_OBJECT

public:
    Window();
};
