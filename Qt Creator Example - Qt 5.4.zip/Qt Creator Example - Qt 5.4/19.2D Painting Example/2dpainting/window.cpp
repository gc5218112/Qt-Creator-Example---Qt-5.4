#include "glwidget.h"
#include "widget.h"
#include "window.h"
#include <QGridLayout>
#include <QLabel>
#include <QTimer>

Window::Window()
{
    //窗口绘制两个部件 一个显示原始绘制 一个显示经过OpenGL渲染后的绘制
    //一个部件继承QWidget、一个部件继承QOpenGLWidget 其他基本一样
    setWindowTitle(tr("基于原生和OpenGL控件的2D绘制"));

    Widget *native = new Widget(&helper, this);

    GLWidget *openGL = new GLWidget(&helper, this);

    QLabel *nativeLabel = new QLabel(tr("原生绘制"));
    nativeLabel->setAlignment(Qt::AlignHCenter);//居中对齐

    QLabel *openGLLabel = new QLabel(tr("经过OpenGL渲染，开启抗锯齿"));
    openGLLabel->setAlignment(Qt::AlignHCenter);

    QGridLayout *layout = new QGridLayout;
    layout->addWidget(native, 0, 0);
    layout->addWidget(openGL, 0, 1);
    layout->addWidget(nativeLabel, 1, 0);
    layout->addWidget(openGLLabel, 1, 1);
    setLayout(layout);

    QTimer *timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), native, SLOT(animate()));
    connect(timer, SIGNAL(timeout()), openGL, SLOT(animate()));
    timer->start(50);//此定时器0.05秒触发一次
}
