#include "glwidget.h"
#include "helper.h"
#include <QPainter>
#include <QTimer>

//OpenGL渲染效果显示部件
GLWidget::GLWidget(Helper *helper, QWidget *parent)
    : QOpenGLWidget(parent), helper(helper)
{
    elapsed = 0;
    setFixedSize(400, 400);
    setAutoFillBackground(false);
}

void GLWidget::animate()
{
    elapsed = (elapsed + qobject_cast<QTimer*>(sender())->interval()) % 1000;
    update();
}

void GLWidget::paintEvent(QPaintEvent *event)
{
    QPainter painter;
    painter.begin(this);
    painter.setRenderHint(QPainter::Antialiasing);//开启抗锯齿
    helper->paint(&painter, event, elapsed);
    painter.end();
}
