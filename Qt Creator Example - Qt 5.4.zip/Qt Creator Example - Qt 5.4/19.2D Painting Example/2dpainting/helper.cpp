#include "helper.h"
#include <QPainter>
#include <QPaintEvent>
#include <QWidget>

//本类定义了绘图操作
Helper::Helper()
{
    //线性渐变
    QLinearGradient gradient(QPointF(50, -20), QPointF(80, 20));
    gradient.setColorAt(0.0, Qt::white);
    gradient.setColorAt(1.0, QColor(0xa6, 0xce, 0x39));

    background = QBrush(QColor(64, 32, 64));//设置背景

    circleBrush = QBrush(gradient);//用线性渐变画刷画圆

    circlePen = QPen(Qt::black);
    circlePen.setWidth(1);//圆的边缘线宽度

    textPen = QPen(Qt::white);
    textFont.setPixelSize(50);//文字大小
}

void Helper::paint(QPainter *painter, QPaintEvent *event, int elapsed)
{
    painter->fillRect(event->rect(), background);//绘制背景（200*200）
    painter->translate(200, 200);//移动绘制点到部件中心 使用100,100作为中心点（从0,0移动到100,100）

    painter->save();//保存 QPainter 的状态

    painter->setBrush(circleBrush);//设置画笔
    painter->setPen(circlePen);

    //elapsed:0-950 elapsed一秒钟变化20次 每秒重绘20次 每次画圆30个
    painter->rotate(elapsed * 0.030);//以100,100为中心旋转一定角度 (0,28.5)

    qreal r = elapsed / 1000.0;// (0 , 0.95)
    int n = 30;
    for (int i = 0; i < n; ++i) //画圆
    {
        painter->rotate(30);//每画一个圆画面就旋转30° 花完30个圆刚好转完2圈半
        qreal factor = (i + r) / n;// (0 , 0.998)
        qreal radius = 0 + 120.0 * factor;//(0 , 119.8)
        qreal circleRadius = 1 + factor * 20;//(1 , 20.97)
        painter->drawEllipse(QRectF(radius,
                                    -circleRadius,
                                    circleRadius * 2,
                                    circleRadius * 2));
    }
    painter->restore();//恢复保存的画笔状态

    painter->setPen(textPen);
    painter->setFont(textFont);
    painter->drawText(QRect(-100, -100, 300, 300), //绘制文字
                      Qt::AlignCenter,//在中心绘制
                      QWidget::tr("Qt OpenGL"));
}
