#include "widget.h"
#include "helper.h"
#include <QPainter>
#include <QTimer>
#include <QDebug>

//原生状态绘制窗口
Widget::Widget(Helper *helper, QWidget *parent)
    : QWidget(parent), helper(helper)
{
    elapsed = 0;
    setFixedSize(400, 400);
}

void Widget::animate()
{
    elapsed = (elapsed + qobject_cast<QTimer*>(sender())->interval()) % 1000;
    //qobject_cast<QTimer*>(sender())->interval()) 50 绑定的定时器隔0.05秒触发一次
    //本函数隔0.05秒执行一次 窗口隔0.05秒重绘一次
    update();
}

void Widget::paintEvent(QPaintEvent *event)
{
    QPainter painter;
    painter.begin(this);
    helper->paint(&painter, event, elapsed);
    painter.end();
}
