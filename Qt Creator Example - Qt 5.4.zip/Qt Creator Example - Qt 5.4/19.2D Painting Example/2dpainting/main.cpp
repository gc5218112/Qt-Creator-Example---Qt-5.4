#include "window.h"
#include <QApplication>
#include <QSurfaceFormat>

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    QSurfaceFormat fmt;
    fmt.setSamples(4);
    QSurfaceFormat::setDefaultFormat(fmt);//设置默认渲染格式
    /*
    QSurface是一个可渲染的抽象类，继承自QOffscreenSurface和QWindow。
    QSurfaceFormat代表QSurface的一种格式，包括颜色缓冲（红、绿、蓝、alpha缓冲）、
    深度缓冲、多重采样数量等;
    */

    Window window;
    window.show();
    return app.exec();
}
