#include <QtWidgets>
#include "droparea.h"
#include "dropsitewindow.h"

DropSiteWindow::DropSiteWindow()
{
    abstractLabel = new QLabel(tr("此示例接受来自其他应用程序的拖动，并显示拖动对象提供的MIME类型"));
    //这两句设置当内容超过宽度自动换行
    abstractLabel->setWordWrap(true);
    abstractLabel->adjustSize();

    dropArea = new DropArea;
    connect(dropArea, SIGNAL(changed(const QMimeData*)),
            this, SLOT(updateFormatsTable(const QMimeData*)));

    QStringList labels;
    labels << tr("格式") << tr("内容");

    formatsTable = new QTableWidget;
    formatsTable->setColumnCount(2);
    formatsTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    formatsTable->setHorizontalHeaderLabels(labels);
    formatsTable->horizontalHeader()->setStretchLastSection(true);

    clearButton = new QPushButton(tr("清空"));
    quitButton = new QPushButton(tr("退出"));

    buttonBox = new QDialogButtonBox;
    buttonBox->addButton(clearButton, QDialogButtonBox::ActionRole);
    buttonBox->addButton(quitButton, QDialogButtonBox::RejectRole);

    connect(quitButton, SIGNAL(pressed()), this, SLOT(close()));
    connect(clearButton, SIGNAL(pressed()), dropArea, SLOT(clear()));

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout->addWidget(abstractLabel);
    mainLayout->addWidget(dropArea);
    mainLayout->addWidget(formatsTable);
    mainLayout->addWidget(buttonBox);
    setLayout(mainLayout);

    setWindowTitle(tr("拖拽MimeData信息显示"));
    setMinimumSize(350, 500);
}

//拖拽进入后信号槽函数
void DropSiteWindow::updateFormatsTable(const QMimeData *mimeData)
{
    formatsTable->setRowCount(0);
    if (!mimeData)
    {
        return;
    }

    //解析QMimeData信息
    foreach (QString format, mimeData->formats())
    {
        QTableWidgetItem *formatItem = new QTableWidgetItem(format);
        formatItem->setFlags(Qt::ItemIsEnabled);
        formatItem->setTextAlignment(Qt::AlignTop | Qt::AlignLeft);

        QString text;
        if (format == "text/plain")
        {
            text = mimeData->text().simplified();
        }
        else if (format == "text/html")
        {
            text = mimeData->html().simplified();
        }
        else if (format == "text/uri-list")
        {
            QList<QUrl> urlList = mimeData->urls();
            for (int i = 0; i < urlList.size() && i < 32; ++i)
            {
                text.append(urlList[i].toString() + " ");
            }
        }
        else
        {
            QByteArray data = mimeData->data(format);
            for (int i = 0; i < data.size() && i < 32; ++i)
            {
                QString hex = QString("%1").arg(uchar(data[i]), 2, 16, QChar('0')).toUpper();
                text.append(hex + " ");
            }
        }

        int row = formatsTable->rowCount();
        formatsTable->insertRow(row);
        formatsTable->setItem(row, 0, new QTableWidgetItem(format));
        formatsTable->setItem(row, 1, new QTableWidgetItem(text));
    }

    formatsTable->resizeColumnToContents(0);
}
