#include "droparea.h"
#include <QDragEnterEvent>
#include <QMimeData>

//一个可接受拖拽内容的标签
DropArea::DropArea(QWidget *parent)
    : QLabel(parent)
{
    setMinimumSize(200, 200);
    setFrameStyle(QFrame::Sunken | QFrame::StyledPanel);
    setAlignment(Qt::AlignCenter);
    setAcceptDrops(true);//接受拖拽放下事件
    setAutoFillBackground(true);//自动填充背景
    clear();
}

//拖拽进入事件
void DropArea::dragEnterEvent(QDragEnterEvent *event)
{
    setText(tr("<把拖拽的内容放到这个标签>"));
    setBackgroundRole(QPalette::Highlight);//标签高亮

    event->acceptProposedAction();//接受拖拽动作（猜测）
    emit changed(event->mimeData());//将拖拽封装的mimeData发送出去
}

void DropArea::dragMoveEvent(QDragMoveEvent *event)
{
    event->acceptProposedAction();
}

//放下事件
void DropArea::dropEvent(QDropEvent *event)
{
    const QMimeData *mimeData = event->mimeData();

    if (mimeData->hasImage())//拖拽的是图像
    {
        setPixmap(qvariant_cast<QPixmap>(mimeData->imageData()));
    }
    else if (mimeData->hasHtml())//网页文件
    {
        setText(mimeData->html());
        setTextFormat(Qt::RichText);
    }
    else if (mimeData->hasText())//文本
    {
        setText(mimeData->text());
        setTextFormat(Qt::PlainText);
    }
    else if (mimeData->hasUrls())//网址
    {
        QList<QUrl> urlList = mimeData->urls();
        QString text;
        for (int i = 0; i < urlList.size() && i < 32; ++i)
        {
            QString url = urlList.at(i).path();
            text += url + QString("\n");
        }
        setText(text);
    }
    else //其他数据
    {
        setText(tr("无法显示数据"));
    }

    setBackgroundRole(QPalette::Dark);
    event->acceptProposedAction();
}

//拖拽离开 拖到标签上了但没放下去就离开了
void DropArea::dragLeaveEvent(QDragLeaveEvent *event)
{
    clear();
    event->accept();
}

void DropArea::clear()
{
    setText(tr("<把拖拽的内容放到这个标签>"));
    setBackgroundRole(QPalette::Dark);//暗色

    emit changed();
}
