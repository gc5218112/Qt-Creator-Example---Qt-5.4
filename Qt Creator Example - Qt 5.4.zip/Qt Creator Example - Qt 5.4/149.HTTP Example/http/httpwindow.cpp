#include <QtWidgets>
#include <QtNetwork>
#include "httpwindow.h"
#include "ui_authenticationdialog.h"

HttpWindow::HttpWindow(QWidget *parent)
    : QDialog(parent)
{
    urlLineEdit = new QLineEdit();

    urlLabel = new QLabel(tr("下载地址："));
    urlLabel->setBuddy(urlLineEdit);

    statusLabel = new QLabel(tr("请输入要下载文件的URL"));
    statusLabel->setWordWrap(true);//根据文本长度自动换行

    downloadButton = new QPushButton(tr("下载"));
    downloadButton->setDefault(true);
    downloadButton->setEnabled(false);

    quitButton = new QPushButton(tr("退出"));
    quitButton->setAutoDefault(false);

    buttonBox = new QDialogButtonBox;
    buttonBox->addButton(downloadButton, QDialogButtonBox::ActionRole);
    buttonBox->addButton(quitButton, QDialogButtonBox::RejectRole);

    progressDialog = new QProgressDialog(this);//下载进度条

    //当输入内容不为空 下载按钮可用
    connect(urlLineEdit, SIGNAL(textChanged(QString)), this, SLOT(enableDownloadButton()));

    //authenticationRequired信号当完成服务请求认证的时候，在交付请求内容之前被发射
    //如向服务器请求下载文件 在下载之前服务器返回信息说要你输入用户名密码
    //QAuthenticator 认证对象
    //槽函数是用来处理服务器的认证要求 提交服务器要求的认证信息
    connect(&qnam, SIGNAL(authenticationRequired(QNetworkReply*,QAuthenticator*)),
            this, SLOT(slotAuthenticationRequired(QNetworkReply*,QAuthenticator*)));

#ifndef QT_NO_SSL
    connect(&qnam, SIGNAL(sslErrors(QNetworkReply*,QList<QSslError>)),
            this, SLOT(sslErrors(QNetworkReply*,QList<QSslError>)));
#endif

    connect(progressDialog, SIGNAL(canceled()), this, SLOT(cancelDownload()));
    connect(downloadButton, SIGNAL(clicked()), this, SLOT(downloadFile()));
    connect(quitButton, SIGNAL(clicked()), this, SLOT(close()));

    QHBoxLayout *topLayout = new QHBoxLayout;
    topLayout->addWidget(urlLabel);
    topLayout->addWidget(urlLineEdit);

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout->setSizeConstraint(QLayout::SetDefaultConstraint);
    mainLayout->addLayout(topLayout);
    mainLayout->addWidget(statusLabel);
    mainLayout->addWidget(buttonBox);
    setLayout(mainLayout);

    setWindowTitle(tr("HTTP下载器"));
    urlLineEdit->setFocus();
}

//开始请求
void HttpWindow::startRequest(QUrl url)
{
    //发送一个网络请求 并用reply监听服务器对该网络请求的响应
    reply = qnam.get(QNetworkRequest(url));

    //网络应答结束时 处理服务器发过来的反馈信息
    connect(reply, SIGNAL(finished()), this, SLOT(httpFinished()));
    //当有新数据可读取时 处理新数据（写入文件）
    connect(reply, SIGNAL(readyRead()), this, SLOT(httpReadyRead()));
    //当网络请求的下载进度更新时
    connect(reply, SIGNAL(downloadProgress(qint64,qint64)),
            this, SLOT(updateDataReadProgress(qint64,qint64)));
}

//下载文件
void HttpWindow::downloadFile()
{
    if(urlLineEdit->text().isEmpty())
    {
        QMessageBox::information(this,"http下载器","请输入下载地址");
        return;
    }
    url = urlLineEdit->text();

    QFileInfo fileInfo(url.path());//转换成路径
    QString fileName = fileInfo.fileName();//转换成文件名
    if (fileName.isEmpty())
    {
        fileName = "index.html";
    }

    if (QFile::exists(fileName))
    {
        if (QMessageBox::question(this, tr("HTTP下载器"), tr("在当前文件夹已经存在一个名为 %1 的文件，是否覆盖?").arg(fileName), QMessageBox::Yes|QMessageBox::No, QMessageBox::No) == QMessageBox::No)
        {
            return;
        }
        QFile::remove(fileName);//清除此文件
    }

    file = new QFile(fileName);//用文件名创建文件对象
    if (!file->open(QIODevice::WriteOnly))//只写入方式打开文件
    {
        QMessageBox::information(this, tr("HTTP下载器"), tr("无法保存文件 %1: %2.").arg(fileName).arg(file->errorString()));
        delete file;
        file = 0;
        return;
    }

    progressDialog->setWindowTitle(tr("下载进度"));
    progressDialog->setLabelText(tr("正在从：%1下载文件").arg(fileName));
    progressDialog->adjustSize();

    downloadButton->setEnabled(false);

    httpRequestAborted = false;//是否终止http请求：否
    startRequest(url);
}

//下载进度条对话框的取消下载按钮
void HttpWindow::cancelDownload()
{
    statusLabel->setText(tr("取消下载"));
    httpRequestAborted = true;//是否终止http请求：是
    reply->abort();//停止监听服务器对http请求的响应
    downloadButton->setEnabled(true);
}

//处理服务器发过来的反馈信息
void HttpWindow::httpFinished()
{
    if (httpRequestAborted)//终止了http请求
    {
        if (file)//文件对象存在
        {
            file->close();
            file->remove();
            delete file;
            file = 0;
        }
        reply->deleteLater();//清除reply对象
        progressDialog->hide();//进度对话框隐藏
        return;
    }

    progressDialog->hide();
    file->flush();//刷新文件
    file->close();//关闭文件

    QVariant redirectionTarget = reply->attribute(QNetworkRequest::RedirectionTargetAttribute);
    if (reply->error())
    {
        file->remove();
        QMessageBox::information(this, tr("HTTP下载器"), tr("下载失败： %1.").arg(reply->errorString()));
        downloadButton->setEnabled(true);
    }
    else if (!redirectionTarget.isNull())
    {
        QUrl newUrl = url.resolved(redirectionTarget.toUrl());
        if (QMessageBox::question(this, tr("HTTP下载器"), tr("是否重定向到 %1 ?").arg(newUrl.toString()), QMessageBox::Yes | QMessageBox::No) == QMessageBox::Yes)
        {
            url = newUrl;
            reply->deleteLater();
            file->open(QIODevice::WriteOnly);
            file->resize(0);
            startRequest(url);
            return;
        }
    }
    else
    {
        QString fileName = QFileInfo(QUrl(urlLineEdit->text()).path()).fileName();
        statusLabel->setText(tr("已下载 %1 到 %2").arg(fileName).arg(QDir::currentPath()));
        downloadButton->setEnabled(true);
        adjustSize();//自动调整窗口大小
    }

    reply->deleteLater();
    reply = 0;
    delete file;
    file = 0;
}

//当有新数据可读取时
void HttpWindow::httpReadyRead()
{
    if (file)//如果文件对象存在 将服务器返回的所有内容写入文件对象
    {
        file->write(reply->readAll());
    }
}

//将网络下载进度更新信息设置到下载进度框
void HttpWindow::updateDataReadProgress(qint64 bytesRead, qint64 totalBytes)
{
    if (httpRequestAborted)
    {
        return;
    }

    progressDialog->setMaximum(totalBytes);
    progressDialog->setValue(bytesRead);
}

//下载按钮是否可用
void HttpWindow::enableDownloadButton()
{
    downloadButton->setEnabled(!urlLineEdit->text().isEmpty());
}

//处理服务器的认证要求 给服务器发送认证信息
void HttpWindow::slotAuthenticationRequired(QNetworkReply*,QAuthenticator *authenticator)
{
    //打开ui设计的的对话框
    QDialog dlg;
    Ui::Dialog ui;
    ui.setupUi(&dlg);
    dlg.adjustSize();
    ui.siteDescription->setText(tr("%1 at %2").arg(authenticator->realm()).arg(url.host()));
    ui.userEdit->setText(url.userName());
    ui.passwordEdit->setText(url.password());

    //输入服务器所需的认证用户名密码
    if (dlg.exec() == QDialog::Accepted)
    {
        authenticator->setUser(ui.userEdit->text());
        authenticator->setPassword(ui.passwordEdit->text());
    }
}

#ifndef QT_NO_SSL
void HttpWindow::sslErrors(QNetworkReply*,const QList<QSslError> &errors)
{
    QString errorString;
    foreach (const QSslError &error, errors)
    {
        if (!errorString.isEmpty())
        {
            errorString += ", ";
        }
        errorString += error.errorString();
    }

    if (QMessageBox::warning(this, tr("HTTP下载器"), tr("发生了一个或多个SSL错误： %1").arg(errorString), QMessageBox::Ignore | QMessageBox::Abort) == QMessageBox::Ignore)
    {
        reply->ignoreSslErrors();
    }
}
#endif
