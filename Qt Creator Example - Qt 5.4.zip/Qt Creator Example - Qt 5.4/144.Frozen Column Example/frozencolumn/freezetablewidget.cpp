#include "freezetablewidget.h"
#include <QScrollBar>
#include <QHeaderView>
#include <QDebug>

FreezeTableWidget::FreezeTableWidget(QAbstractItemModel * model)
{
    setModel(model);//设置本视图要显示的模型

    //此视图作为本视图的子项 此子视图显示在父视图的上面
    //拖动父视图时候不影响子视图 就有了列固定的视觉效果
    frozenTableView = new QTableView(this);

    init();

    //改变列宽的信号
    connect(horizontalHeader(),SIGNAL(sectionResized(int,int,int)), this, SLOT(updateSectionWidth(int,int,int)));
    //改变行高的信号
    connect(verticalHeader(),SIGNAL(sectionResized(int,int,int)), this, SLOT(updateSectionHeight(int,int,int)));

    connect(frozenTableView->verticalScrollBar(), SIGNAL(valueChanged(int)), verticalScrollBar(), SLOT(setValue(int)));
    connect(verticalScrollBar(), SIGNAL(valueChanged(int)), frozenTableView->verticalScrollBar(), SLOT(setValue(int)));
}

FreezeTableWidget::~FreezeTableWidget()
{
    delete frozenTableView;
}

void FreezeTableWidget::init()
{
    frozenTableView->setModel(model());//设置QTableView要显示的模型
    frozenTableView->setFocusPolicy(Qt::NoFocus);//视图不获得焦点
    frozenTableView->verticalHeader()->hide();//隐藏QTableView自带的行号
    frozenTableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Fixed);//表头自适应模式设置:根据内容自动调整列宽

    viewport()->stackUnder(frozenTableView);//设置此frozenTableView视图堆叠在本视图上方
    //设置样式
    frozenTableView->setStyleSheet("QTableView { border: none;"
                                                 "background-color: #FF0000;"//#8EDE21
                                                 "selection-background-color: #999}");

    frozenTableView->setSelectionModel(selectionModel());

    //两个视图显示的是一样的内容 frozenTableView只需要显示第一列内容 其余列全部隐藏
    for (int col = 1; col < model()->columnCount(); ++col)
    {
        frozenTableView->setColumnHidden(col, true);//隐藏第col列
    }

    //这句比较关键 设置子视图的第一列始终和父视图的第一列列宽一样 即父视图的第一列始终被子视图的第一列挡着
    frozenTableView->setColumnWidth(0, columnWidth(0) );

    frozenTableView->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);//关闭滚动条
    frozenTableView->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    frozenTableView->show();

    updateFrozenTableGeometry();

    setHorizontalScrollMode(ScrollPerPixel);//设置滚动条滚动模型：按像素（猜）
    setVerticalScrollMode(ScrollPerPixel);
    frozenTableView->setVerticalScrollMode(ScrollPerPixel);
}

//改变列宽槽函数
void FreezeTableWidget::updateSectionWidth(int logicalIndex, int /* oldSize */, int newSize)
{
    if (logicalIndex == 0)
    {
        frozenTableView->setColumnWidth(0, newSize);
        updateFrozenTableGeometry();
    }
}

//改变行高槽函数
void FreezeTableWidget::updateSectionHeight(int logicalIndex, int /* oldSize */, int newSize)
{
    frozenTableView->setRowHeight(logicalIndex, newSize);
}

void FreezeTableWidget::resizeEvent(QResizeEvent * event)
{
    QTableView::resizeEvent(event);
    updateFrozenTableGeometry();
}

QModelIndex FreezeTableWidget::moveCursor(CursorAction cursorAction, Qt::KeyboardModifiers modifiers)
{
    QModelIndex current = QTableView::moveCursor(cursorAction, modifiers);

    if (cursorAction == MoveLeft && current.column() > 0 && visualRect(current).topLeft().x() < frozenTableView->columnWidth(0) )
    {
        const int newValue = horizontalScrollBar()->value() + visualRect(current).topLeft().x() - frozenTableView->columnWidth(0);
        horizontalScrollBar()->setValue(newValue);
    }
    return current;
}

void FreezeTableWidget::scrollTo (const QModelIndex & index, ScrollHint hint)
{
    if (index.column() > 0)
    {
        QTableView::scrollTo(index, hint);
    }
}

void FreezeTableWidget::updateFrozenTableGeometry()
{
    frozenTableView->setGeometry(verticalHeader()->width() + frameWidth(), frameWidth(), columnWidth(0), viewport()->height() + horizontalHeader()->height());
}
