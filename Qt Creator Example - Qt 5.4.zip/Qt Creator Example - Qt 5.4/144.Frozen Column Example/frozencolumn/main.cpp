#include <QApplication>
#include <QStandardItemModel>
#include <QFile>
#include "freezetablewidget.h"
#include <QDebug>

int main(int argc, char* argv[])
{
    Q_INIT_RESOURCE(grades);

    QApplication app( argc, argv );

    //创建模型并从文件读取数据作为模型的数据
    QStandardItemModel *model = new QStandardItemModel();

    QFile file(":/grades.txt");
    if (file.open(QFile::ReadOnly))
    {
        //读取一行（最后一个字符是换行符），若这行超过200字符则只读前200个字符
        QString line = file.readLine(200);//读取第一行
        QStringList list = line.simplified().split(",");
        model->setHorizontalHeaderLabels(list);//设置表格的表头

        int row = 0;
        QStandardItem *newItem = 0;//模型的数据项 看起来像表格的单元格
        while (file.canReadLine())
        {
            line = file.readLine(200);
            if (!line.startsWith("#") && line.contains(","))
            {
                list= line.simplified().split(",");
                for (int col = 0; col < list.length(); ++col)
                {
                    newItem = new QStandardItem(list.at(col));
                    model->setItem(row, col, newItem);
                }
                ++row;
            }
        }
    }
    file.close();

    //显示模型数据的视图
    FreezeTableWidget *tableView = new FreezeTableWidget(model);

    tableView->setWindowTitle(QObject::tr("固定列例子"));
    tableView->resize(560, 680);
    tableView->show();
    return app.exec();
}
