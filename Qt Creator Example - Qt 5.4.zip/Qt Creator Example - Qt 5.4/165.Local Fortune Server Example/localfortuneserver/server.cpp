#include <QtWidgets>
#include <QtNetwork>
#include <stdlib.h>
#include "server.h"
#include <qlocalserver.h>
#include <qlocalsocket.h>

Server::Server(QWidget *parent)
    : QDialog(parent)
{
    statusLabel = new QLabel;
    statusLabel->setWordWrap(true);
    quitButton = new QPushButton(tr("退出"));
    quitButton->setAutoDefault(false);

    //QLocalServer提供了一个基于本地套接字(socket)的服务端(server)
    //QLocalServer可以接受来自本地socket的连接
    server = new QLocalServer(this);
    if (!server->listen("fortune"))
    {
        QMessageBox::critical(this, tr("本地服务端"), tr("无法启动服务端：%1").arg(server->errorString()));
        close();
        return;
    }

    statusLabel->setText(tr("服务端已运行，现在请运行客户端"));

    fortunes << tr("消息001")
             << tr("消息002")
             << tr("消息003")
             << tr("消息004")
             << tr("消息005")
             << tr("消息006");

    connect(quitButton, SIGNAL(clicked()), this, SLOT(close()));

    //newConnection()是在每次server与client连接上时所发出的信号
    connect(server, SIGNAL(newConnection()), this, SLOT(sendFortune()));

    QHBoxLayout *buttonLayout = new QHBoxLayout;
    buttonLayout->addStretch(1);
    buttonLayout->addWidget(quitButton);
    buttonLayout->addStretch(1);

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout->addWidget(statusLabel);
    mainLayout->addLayout(buttonLayout);
    setLayout(mainLayout);

    setWindowTitle(tr("本地服务端"));
}

//向客户端发送消息
void Server::sendFortune()
{
    QByteArray block;
    QDataStream out(&block, QIODevice::WriteOnly);
    out.setVersion(QDataStream::Qt_5_4);
    out << (quint16)0;
    out << fortunes.at(qrand() % fortunes.size());
    out.device()->seek(0);
    out << (quint16)(block.size() - sizeof(quint16));

    QLocalSocket *clientConnection = server->nextPendingConnection();
    //当断开连接时清楚本地套接字对象
    connect(clientConnection, SIGNAL(disconnected()), clientConnection, SLOT(deleteLater()));

    clientConnection->write(block);
    clientConnection->flush();
    clientConnection->disconnectFromServer();
}
