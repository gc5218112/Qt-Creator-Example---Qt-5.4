#include <QtWidgets>
#include "imagedelegate.h"
#include <QDebug>

//自定义委托类 用于表格操作
ImageDelegate::ImageDelegate(QObject *parent)
    : QItemDelegate(parent)
{
}

//返回修改数据的组件
QWidget *ImageDelegate::createEditor(QWidget *parent,
                                     const QStyleOptionViewItem & /* option */,
                                     const QModelIndex &index) const
{

    QComboBox *comboBox = new QComboBox(parent);

    //QModelIndex用于定位模型中的数据
    if (index.column() == 1)//当前是第1列
    {
        comboBox->addItem(tr("正常"));
        comboBox->addItem(tr("激活"));
        comboBox->addItem(tr("禁用"));
        comboBox->addItem(tr("选中"));
    }
    else if (index.column() == 2)
    {
        comboBox->addItem(tr("关闭"));
        comboBox->addItem(tr("打开"));
    }

    //切换下拉项时的信号
    connect(comboBox, SIGNAL(activated(int)), this, SLOT(emitCommitData()));

    return comboBox;
}

//为editor提供编辑的原始数据
void ImageDelegate::setEditorData(QWidget *editor, const QModelIndex &index) const
{
    qDebug()<<index.column()<<" "<<index.data();
    //-> 列号 定位到的模型中的内容（当前操作选中的单元格中的内容）

    QComboBox *comboBox = qobject_cast<QComboBox *>(editor);
    if (!comboBox)
    {
        return;
    }

    qDebug()<<index.model()->data(index).toString();
    int pos = comboBox->findText(index.model()->data(index).toString(), Qt::MatchExactly);
    comboBox->setCurrentIndex(pos);
}

//根据editor的数据更新model的数据
void ImageDelegate::setModelData(QWidget *editor, QAbstractItemModel *model, const QModelIndex &index) const
{
    //目前操作的那个下拉框
    QComboBox *comboBox = qobject_cast<QComboBox *>(editor);
    if (!comboBox)
    {
        return;
    }

    model->setData(index, comboBox->currentText());
}

void ImageDelegate::emitCommitData()
{
    //commitData提交数据信号 改好了单元格中的数据后发送信号 这里发送的是选则下拉的那个下拉框
    emit commitData(qobject_cast<QWidget *>(sender()));
}
