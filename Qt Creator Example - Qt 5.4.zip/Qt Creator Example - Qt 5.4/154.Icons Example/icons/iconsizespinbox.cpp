#include <QtWidgets>
#include "iconsizespinbox.h"

//图像尺寸微调框
IconSizeSpinBox::IconSizeSpinBox(QWidget *parent)
    : QSpinBox(parent)
{
}

//将输入的文本解读为适当的值 如 30 x 30 -> 30
int IconSizeSpinBox::valueFromText(const QString &text) const
{
    QRegExp regExp(tr("(\\d+)(\\s*[xx]\\s*\\d+)?"));

    if (regExp.exactMatch(text))
    {
        return regExp.cap(1).toInt();
    }
    else
    {
        return 0;
    }
}

//将值转换成字符串 如输入30 -> 30 x 30
QString IconSizeSpinBox::textFromValue(int value) const
{
    return tr("%1 x %1").arg(value);
}
