#include <QtWidgets>
#include "iconpreviewarea.h"
#include "iconsizespinbox.h"
#include "imagedelegate.h"
#include "mainwindow.h"
#include <QDebug>

MainWindow::MainWindow()
{
    centralWidget = new QWidget;
    setCentralWidget(centralWidget);

    createPreviewGroupBox();
    createImagesGroupBox();
    createIconSizeGroupBox();

    createActions();
    createMenus();
    createContextMenu();

    QGridLayout *mainLayout = new QGridLayout;
    mainLayout->addWidget(previewGroupBox, 0, 0, 1, 2);
    mainLayout->addWidget(imagesGroupBox, 1, 0);
    mainLayout->addWidget(iconSizeGroupBox, 1, 1);
    centralWidget->setLayout(mainLayout);

    setWindowTitle(tr("图标演示"));
    checkCurrentStyle();
    otherRadioButton->click();

    resize(minimumSizeHint());
}

void MainWindow::about()
{
    QMessageBox::about(this, tr("关于本程序"),
            tr("此 <b>图标</b> 示例说明Qt如何基于一组图像以不同模式"
               "（活动、正常、禁用和选中）和状态（打开和关闭）呈现图标"));
}

//更改窗口风格
void MainWindow::changeStyle(bool checked)
{
    if (!checked)
    {
        return;
    }

    QAction *action = qobject_cast<QAction *>(sender());//信号发送者

    //创建QAction对象时候将风格名称存入了action->data()
    QStyle *style = QStyleFactory::create(action->data().toString());
    Q_ASSERT(style);
    QApplication::setStyle(style);//对整个应用使用风格

    //窗口中的部件使用风格
    smallRadioButton->setText(tr("Small (%1 x %1)").arg(style->pixelMetric(QStyle::PM_SmallIconSize)));
    largeRadioButton->setText(tr("Large (%1 x %1)").arg(style->pixelMetric(QStyle::PM_LargeIconSize)));
    toolBarRadioButton->setText(tr("Toolbars (%1 x %1)").arg(style->pixelMetric(QStyle::PM_ToolBarIconSize)));
    listViewRadioButton->setText(tr("List views (%1 x %1)").arg(style->pixelMetric(QStyle::PM_ListViewIconSize)));
    iconViewRadioButton->setText(tr("Icon views (%1 x %1)").arg(style->pixelMetric(QStyle::PM_IconViewIconSize)));
    tabBarRadioButton->setText(tr("Tab bars (%1 x %1)").arg(style->pixelMetric(QStyle::PM_TabBarIconSize)));

    changeSize();
}

//改变图标大小
void MainWindow::changeSize(bool checked)
{
    if (!checked)
    {
        return;
    }

    int extent;

    if (otherRadioButton->isChecked())
    {
        extent = otherSpinBox->value();
    }
    else
    {
        QStyle::PixelMetric metric;

        if (smallRadioButton->isChecked())
        {
            metric = QStyle::PM_SmallIconSize;
        }
        else if (largeRadioButton->isChecked())
        {
            metric = QStyle::PM_LargeIconSize;
        }
        else if (toolBarRadioButton->isChecked())
        {
            metric = QStyle::PM_ToolBarIconSize;
        }
        else if (listViewRadioButton->isChecked())
        {
            metric = QStyle::PM_ListViewIconSize;
        }
        else if (iconViewRadioButton->isChecked())
        {
            metric = QStyle::PM_IconViewIconSize;
        }
        else
        {
            metric = QStyle::PM_TabBarIconSize;
        }
        extent = QApplication::style()->pixelMetric(metric);
    }
    previewArea->setSize(QSize(extent, extent));
    otherSpinBox->setEnabled(otherRadioButton->isChecked());//若未选中此单选框 微调框不可用
}

//改变预览区标签上的图标图像
void MainWindow::changeIcon()
{
    QIcon icon;

    for (int row = 0; row < imagesTable->rowCount(); ++row)//行
    {
        QTableWidgetItem *item0 = imagesTable->item(row, 0);//表格项
        QTableWidgetItem *item1 = imagesTable->item(row, 1);
        QTableWidgetItem *item2 = imagesTable->item(row, 2);

        if (item0->checkState() == Qt::Checked)//表格窗口项前面的复选框选中
        {
            QIcon::Mode mode;
            if (item1->text() == tr("正常"))
            {
                mode = QIcon::Normal;
            }
            else if (item1->text() == tr("激活"))
            {
                mode = QIcon::Active;
            }
            else if (item1->text() == tr("禁用"))
            {
                mode = QIcon::Disabled;
            }
            else
            {
                mode = QIcon::Selected;
            }

            QIcon::State state;
            if (item2->text() == tr("打开"))
            {
                state = QIcon::On;
            }
            else
            {
                state = QIcon::Off;
            }

            QString fileName = item0->data(Qt::UserRole).toString();
            qDebug()<<fileName;
            QImage image(fileName);
            if (!image.isNull())
            {
                //根据fileName路径的图像创建一个图标文件
                icon.addPixmap(QPixmap::fromImage(image), mode, state);
            }
        }
    }

    previewArea->setIcon(icon);//将此图标放到预览区显示
}

//添加图像 可多选 一张图像是一行数据
void MainWindow::addImages()
{
    QStringList fileNames = QFileDialog::getOpenFileNames(this,
                                    tr("打开图片"), "",
                                    tr("Images (*.png *.xpm *.jpg);;"
                                       "All Files (*)"));
    if (!fileNames.isEmpty())//可能选中了多张图片 为每张图像创建一行
    {
        foreach (QString fileName, fileNames)
        {
            int row = imagesTable->rowCount();//目前表格行数
            imagesTable->setRowCount(row + 1);//行数+1

            //路径中提取文件名
            QString imageName = QFileInfo(fileName).baseName();

            //本行的第一列 存放文件名
            QTableWidgetItem *item0 = new QTableWidgetItem(imageName);
            item0->setData(Qt::UserRole, fileName);
            item0->setFlags(item0->flags() & ~Qt::ItemIsEditable);//设置第一列不可编辑（猜）

            QTableWidgetItem *item1 = new QTableWidgetItem(tr("正常"));
            QTableWidgetItem *item2 = new QTableWidgetItem(tr("关闭"));

            //开启了根据图片文件名猜测图标模式、状态
            if (guessModeStateAct->isChecked())
            {
                if (fileName.contains("_act"))
                {
                    item1->setText(tr("正常"));
                }
                else if (fileName.contains("_dis"))
                {
                    item1->setText(tr("禁用"));
                }
                else if (fileName.contains("_sel"))
                {
                    item1->setText(tr("选中"));
                }

                if (fileName.contains("_on"))
                {
                    item2->setText(tr("打开"));
                }
            }
            imagesTable->setItem(row, 0, item0);
            imagesTable->setItem(row, 1, item1);
            imagesTable->setItem(row, 2, item2);
            imagesTable->openPersistentEditor(item1);//设置此列的内容可编辑
            imagesTable->openPersistentEditor(item2);

            item0->setCheckState(Qt::Checked);//第一列增加一个可选中状态 且设为选中
        }
    }
}

//清除所有图像
void MainWindow::removeAllImages()
{
    imagesTable->setRowCount(0);
    changeIcon();
}

void MainWindow::createPreviewGroupBox()
{
    previewGroupBox = new QGroupBox(tr("预览"));

    previewArea = new IconPreviewArea;//创建图标预览区域

    QVBoxLayout *layout = new QVBoxLayout;
    layout->addWidget(previewArea);
    previewGroupBox->setLayout(layout);
}

void MainWindow::createImagesGroupBox()
{
    imagesGroupBox = new QGroupBox(tr("图标选项"));

    imagesTable = new QTableWidget;
    imagesTable->setSelectionMode(QAbstractItemView::NoSelection);//所有的项都不能选中,单元格也就无法编辑
    imagesTable->setItemDelegate(new ImageDelegate(this));//为此表格窗口创建一个委托 便于操作数据

    QStringList labels;
    labels << tr("图像") << tr("模式") << tr("状态");

    imagesTable->horizontalHeader()->setDefaultSectionSize(90);
    imagesTable->setColumnCount(3);
    imagesTable->setHorizontalHeaderLabels(labels);//设置表头

    imagesTable->horizontalHeader()->setSectionResizeMode(0, QHeaderView::ResizeToContents);//设置根据内容自动调整列宽
    imagesTable->horizontalHeader()->setSectionResizeMode(1, QHeaderView::Fixed);
    imagesTable->horizontalHeader()->setSectionResizeMode(2, QHeaderView::Fixed);
    imagesTable->verticalHeader()->hide();//隐藏垂直表头

    //当改变表格中的内容时的信号 因为前面设置了无法选中，编辑框中的内容无法更改 效果是：更改下拉框中选中的项执行槽函数
    connect(imagesTable, SIGNAL(itemChanged(QTableWidgetItem*)), this, SLOT(changeIcon()));

    QVBoxLayout *layout = new QVBoxLayout;
    layout->addWidget(imagesTable);
    imagesGroupBox->setLayout(layout);
}

void MainWindow::createIconSizeGroupBox()
{
    iconSizeGroupBox = new QGroupBox(tr("图标尺寸"));

    smallRadioButton = new QRadioButton;
    largeRadioButton = new QRadioButton;
    toolBarRadioButton = new QRadioButton;
    listViewRadioButton = new QRadioButton;
    iconViewRadioButton = new QRadioButton;
    tabBarRadioButton = new QRadioButton;
    otherRadioButton = new QRadioButton(tr("其他："));

    otherSpinBox = new IconSizeSpinBox;
    otherSpinBox->setRange(8, 128);//输入数值范围
    otherSpinBox->setValue(64);

    connect(smallRadioButton, SIGNAL(toggled(bool)), this, SLOT(changeSize(bool)));
    connect(largeRadioButton, SIGNAL(toggled(bool)), this, SLOT(changeSize(bool)));
    connect(toolBarRadioButton, SIGNAL(toggled(bool)), this, SLOT(changeSize(bool)));
    connect(listViewRadioButton, SIGNAL(toggled(bool)), this, SLOT(changeSize(bool)));
    connect(iconViewRadioButton, SIGNAL(toggled(bool)), this, SLOT(changeSize(bool)));
    connect(tabBarRadioButton, SIGNAL(toggled(bool)), this, SLOT(changeSize(bool)));
    connect(otherRadioButton, SIGNAL(toggled(bool)), this, SLOT(changeSize(bool)));
    connect(otherSpinBox, SIGNAL(valueChanged(int)), this, SLOT(changeSize()));

    QHBoxLayout *otherSizeLayout = new QHBoxLayout;
    otherSizeLayout->addWidget(otherRadioButton);
    otherSizeLayout->addWidget(otherSpinBox);
    otherSizeLayout->addStretch();

    QGridLayout *layout = new QGridLayout;
    layout->addWidget(smallRadioButton, 0, 0);
    layout->addWidget(largeRadioButton, 1, 0);
    layout->addWidget(toolBarRadioButton, 2, 0);
    layout->addWidget(listViewRadioButton, 0, 1);
    layout->addWidget(iconViewRadioButton, 1, 1);
    layout->addWidget(tabBarRadioButton, 2, 1);
    layout->addLayout(otherSizeLayout, 3, 0, 1, 2);
    layout->setRowStretch(4, 1);
    iconSizeGroupBox->setLayout(layout);
}

void MainWindow::createActions()
{
    addImagesAct = new QAction(tr("添加图像"), this);
    addImagesAct->setShortcut(tr("Ctrl+A"));
    connect(addImagesAct, SIGNAL(triggered()), this, SLOT(addImages()));

    removeAllImagesAct = new QAction(tr("清除所有图像"), this);
    removeAllImagesAct->setShortcut(tr("Ctrl+R"));
    connect(removeAllImagesAct, SIGNAL(triggered()), this, SLOT(removeAllImages()));

    exitAct = new QAction(tr("退出"), this);
    exitAct->setShortcuts(QKeySequence::Quit);
    connect(exitAct, SIGNAL(triggered()), this, SLOT(close()));

    //动作集合QActionGroup中的动作每次只能选中一个
    styleActionGroup = new QActionGroup(this);
    foreach (QString styleName, QStyleFactory::keys())
    {
        QAction *action = new QAction(styleActionGroup);
        action->setText(tr("%1 窗口风格").arg(styleName));
        action->setData(styleName);
        action->setCheckable(true);//可选中
        connect(action, SIGNAL(triggered(bool)), this, SLOT(changeStyle(bool)));
    }

    guessModeStateAct = new QAction(tr("根据文件名推测图片的模式、状态"), this);
    guessModeStateAct->setCheckable(true);//可选中
    guessModeStateAct->setChecked(true);//默认选中

    aboutAct = new QAction(tr("关于"), this);
    connect(aboutAct, SIGNAL(triggered()), this, SLOT(about()));
}

void MainWindow::createMenus()
{
    fileMenu = menuBar()->addMenu(tr("文件"));
    fileMenu->addAction(addImagesAct);
    fileMenu->addAction(removeAllImagesAct);
    fileMenu->addSeparator();
    fileMenu->addAction(exitAct);

    viewMenu = menuBar()->addMenu(tr("视图"));
    foreach (QAction *action, styleActionGroup->actions())
    {
        viewMenu->addAction(action);
    }
    viewMenu->addSeparator();//分界符
    viewMenu->addAction(guessModeStateAct);

    menuBar()->addSeparator();

    helpMenu = menuBar()->addMenu(tr("帮助"));
    helpMenu->addAction(aboutAct);
}

//给表格窗口添加一个右键菜单
void MainWindow::createContextMenu()
{
    imagesTable->setContextMenuPolicy(Qt::ActionsContextMenu);
    imagesTable->addAction(addImagesAct);
    imagesTable->addAction(removeAllImagesAct);
}

//开启程序时候显示选择的应用风格是QApplication的风格
void MainWindow::checkCurrentStyle()
{
    foreach (QAction *action, styleActionGroup->actions())
    {
        QString styleName = action->data().toString();
        QStyle *candidate = QStyleFactory::create(styleName);
        Q_ASSERT(candidate);
        if (candidate->metaObject()->className() == QApplication::style()->metaObject()->className())
        {
            qDebug()<<candidate->metaObject()->className();
            action->trigger();
            return;
        }
        delete candidate;
    }
}
