#include <QtWidgets>
#include "iconpreviewarea.h"

//图标预览区域
IconPreviewArea::IconPreviewArea(QWidget *parent)
    : QWidget(parent)
{
    QGridLayout *mainLayout = new QGridLayout;
    setLayout(mainLayout);

    stateLabels[0] = createHeaderLabel(tr("关闭（Off）"));
    stateLabels[1] = createHeaderLabel(tr("打开（On）"));
    Q_ASSERT(NumStates == 2);

    modeLabels[0] = createHeaderLabel(tr("正常（Normal）"));
    modeLabels[1] = createHeaderLabel(tr("激活（Active）"));
    modeLabels[2] = createHeaderLabel(tr("禁用（Disabled）"));
    modeLabels[3] = createHeaderLabel(tr("选中（Selected）"));
    Q_ASSERT(NumModes == 4);

    for (int j = 0; j < NumStates; ++j)
    {
        mainLayout->addWidget(stateLabels[j], j + 1, 0);
    }

    for (int i = 0; i < NumModes; ++i)
    {
        mainLayout->addWidget(modeLabels[i], 0, i + 1);

        for (int j = 0; j < NumStates; ++j)
        {
            pixmapLabels[i][j] = createPixmapLabel();
            mainLayout->addWidget(pixmapLabels[i][j], j + 1, i + 1);
        }
    }
}

//设置图标
void IconPreviewArea::setIcon(const QIcon &icon)
{
    this->icon = icon;
    updatePixmapLabels();
}

//设置图标大小
void IconPreviewArea::setSize(const QSize &size)
{
    if (size != this->size)
    {
        this->size = size;
        updatePixmapLabels();
    }
}

//显示文字的标签
QLabel *IconPreviewArea::createHeaderLabel(const QString &text)
{
    QLabel *label = new QLabel(tr("<b>%1</b>").arg(text));//加粗
    label->setAlignment(Qt::AlignCenter);//居中
    return label;
}

//显示图标的正方形标签
QLabel *IconPreviewArea::createPixmapLabel()
{
    QLabel *label = new QLabel;
    label->setEnabled(false);
    label->setAlignment(Qt::AlignCenter);//内容居中
    label->setFrameShape(QFrame::Box);
    label->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    label->setBackgroundRole(QPalette::Base);
    label->setAutoFillBackground(true);//自动填充背景
    label->setMinimumSize(132, 132);
    return label;
}

//更新标签上显示的图像
void IconPreviewArea::updatePixmapLabels()
{
    for (int i = 0; i < NumModes; ++i)//宽：4
    {
        QIcon::Mode mode;
        if (i == 0)
        {
            mode = QIcon::Normal;
        }
        else if (i == 1)
        {
            mode = QIcon::Active;
        }
        else if (i == 2)
        {
            mode = QIcon::Disabled;
        }
        else
        {
            mode = QIcon::Selected;
        }

        for (int j = 0; j < NumStates; ++j)//高：2
        {
            //第0行 QIcon::off 第1行 QIcon::On
            QIcon::State state = (j == 0) ? QIcon::Off : QIcon::On;
            QPixmap pixmap = icon.pixmap(size, mode, state);//图标转换成图像
            pixmapLabels[i][j]->setPixmap(pixmap);//图像放到当前标签
            pixmapLabels[i][j]->setEnabled(!pixmap.isNull());
        }
    }
}
