#include "textprogressbar.h"
#include <QByteArray>
#include <stdio.h>

//文本进度条
TextProgressBar::TextProgressBar()
    : value(0), maximum(-1), iteration(0)
{
}

void TextProgressBar::clear()
{
    printf("\n");
    fflush(stdout);

    iteration = 0;
    value = 0;
    maximum = -1;
}

void TextProgressBar::update()
{
    ++iteration;

    if (maximum > 0)
    {
        //知道了最大值，绘制进度条
        int percent = value * 100 / maximum;
        int hashes = percent / 2;

        QByteArray progressbar(hashes, '#');
        if (percent % 2)
        {
            progressbar += '>';
        }

        printf("\r[%-50s] %3d%% %s     ", progressbar.constData(), percent, qPrintable(message));
    }
    else
    {
        //未知最大值，还不能绘制进度条
        int center = (iteration % 48) + 1;
        QByteArray before(qMax(center - 2, 0), ' ');
        QByteArray after(qMin(center + 2, 50), ' ');

        printf("\r[%s###%s]      %s      ", before.constData(), after.constData(), qPrintable(message));
    }
}

void TextProgressBar::setMessage(const QString &m)
{
    message = m;
}

void TextProgressBar::setStatus(qint64 val, qint64 max)
{
    value = val;
    maximum = max;
}
