#include "downloadmanager.h"
#include <QFileInfo>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QString>
#include <QStringList>
#include <QTimer>
#include <stdio.h>

DownloadManager::DownloadManager(QObject *parent)
    : QObject(parent), downloadedCount(0), totalCount(0)
{
}

void DownloadManager::append(const QStringList &urlList)//参数：下载地址列表
{
    foreach (QString url, urlList)
    {
        append(QUrl::fromEncoded(url.toLocal8Bit()));
    }

    if (downloadQueue.isEmpty())
    {
        QTimer::singleShot(0, this, SIGNAL(finished()));
    }
}

void DownloadManager::append(const QUrl &url)
{
    if (downloadQueue.isEmpty())
    {
        QTimer::singleShot(0, this, SLOT(startNextDownload()));
    }

    downloadQueue.enqueue(url);//下载地址加入队列
    ++totalCount;
}

//确定保存的文件名
QString DownloadManager::saveFileName(const QUrl &url)
{
    QString path = url.path();
    QString basename = QFileInfo(path).fileName();

    if (basename.isEmpty())
    {
        basename = "download";
    }

    if (QFile::exists(basename))
    {
        int i = 0;
        basename += '.';
        while (QFile::exists(basename + QString::number(i)))
        {
            ++i;
        }

        basename += QString::number(i);
    }

    return basename;
}

//开始下一个文件的下载
void DownloadManager::startNextDownload()
{
    if (downloadQueue.isEmpty())
    {
        printf("%d/%d 文件下载成功\n", downloadedCount, totalCount);
        emit finished();
        return;
    }

    QUrl url = downloadQueue.dequeue();//移除最前面的项

    QString filename = saveFileName(url);//要保存的文件名
    output.setFileName(filename);
    if (!output.open(QIODevice::WriteOnly))
    {
        fprintf(stderr, "保存文件出错：'%s'，下载'%s'：%s\n",
                qPrintable(filename), url.toEncoded().constData(), qPrintable(output.errorString()));

        startNextDownload();
        return;//忽略本次下载
    }

    QNetworkRequest request(url);
    currentDownload = manager.get(request);
    connect(currentDownload, SIGNAL(downloadProgress(qint64,qint64)),
            SLOT(downloadProgress(qint64,qint64)));
    connect(currentDownload, SIGNAL(finished()), SLOT(downloadFinished()));
    connect(currentDownload, SIGNAL(readyRead()), SLOT(downloadReadyRead()));

    printf("正在下载 %s...\n", url.toEncoded().constData());
    downloadTime.start();
}

void DownloadManager::downloadProgress(qint64 bytesReceived, qint64 bytesTotal)
{
    progressBar.setStatus(bytesReceived, bytesTotal);

    //计算下载速度
    double speed = bytesReceived * 1000.0 / downloadTime.elapsed();
    QString unit;
    if (speed < 1024)
    {
        unit = "bytes/sec";
    }
    else if (speed < 1024*1024)
    {
        speed /= 1024;
        unit = "kB/s";
    }
    else
    {
        speed /= 1024*1024;
        unit = "MB/s";
    }

    progressBar.setMessage(QString::fromLatin1("%1 %2").arg(speed, 3, 'f', 1).arg(unit));
    progressBar.update();
}

void DownloadManager::downloadFinished()
{
    progressBar.clear();
    output.close();

    if (currentDownload->error())
    {
        fprintf(stderr, "下载失败：%s\n", qPrintable(currentDownload->errorString()));
    }
    else
    {
        printf("下载成功\n");
        ++downloadedCount;
    }

    currentDownload->deleteLater();
    startNextDownload();
}

void DownloadManager::downloadReadyRead()
{
    //下载的所有内容写入文件
    output.write(currentDownload->readAll());
}
