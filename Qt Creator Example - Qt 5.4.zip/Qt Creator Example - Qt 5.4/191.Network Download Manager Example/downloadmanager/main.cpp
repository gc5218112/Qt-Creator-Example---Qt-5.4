#include <QCoreApplication>
#include <QStringList>
#include "downloadmanager.h"
#include <stdio.h>

int main(int argc, char **argv)
{
    QCoreApplication app(argc, argv);
    QStringList arguments = app.arguments();
    arguments.takeFirst();//移除第一个参数（程序名）

    if (arguments.isEmpty())
    {
        return 0;
    }

    DownloadManager manager;
    manager.append(arguments);

    QObject::connect(&manager, SIGNAL(finished()), &app, SLOT(quit()));
    app.exec();
}
