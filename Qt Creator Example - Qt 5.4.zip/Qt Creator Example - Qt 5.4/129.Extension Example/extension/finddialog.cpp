#include <QtWidgets>
#include "finddialog.h"

FindDialog::FindDialog(QWidget *parent)
    : QDialog(parent)
{
    label = new QLabel(tr("搜索关键词："));
    lineEdit = new QLineEdit;
    label->setBuddy(lineEdit);

    caseCheckBox = new QCheckBox(tr("复选框01"));
    fromStartCheckBox = new QCheckBox(tr("复选框02"));
    fromStartCheckBox->setChecked(true);//选中复选框

    findButton = new QPushButton(tr("搜索"));
    findButton->setDefault(true);//外观设置：按钮有蓝色的边界

    moreButton = new QPushButton(tr("对话框延伸"));
    moreButton->setCheckable(true);//设置可检查按钮状态：按下/弹起
    //设置之后点击按钮按钮陷下去，再次点击按钮弹起来
    //按钮的checkable设置为true，才会检测toggled变化情况

    //作为容器存放3个复选框
    extension = new QWidget;

    wholeWordsCheckBox = new QCheckBox(tr("复选框03"));
    backwardCheckBox = new QCheckBox(tr("复选框04"));
    searchSelectionCheckBox = new QCheckBox(tr("复选框05"));

    buttonBox = new QDialogButtonBox(Qt::Vertical);
    buttonBox->addButton(findButton, QDialogButtonBox::ActionRole);
    buttonBox->addButton(moreButton, QDialogButtonBox::ActionRole);

    //按钮按下/弹起->toggled(true)/toggled(fasle) 作为容器的部件可见/不可见
    connect(moreButton, SIGNAL(toggled(bool)), extension, SLOT(setVisible(bool)));

    QVBoxLayout *extensionLayout = new QVBoxLayout;
    extensionLayout->setMargin(0);
    extensionLayout->addWidget(wholeWordsCheckBox);
    extensionLayout->addWidget(backwardCheckBox);
    extensionLayout->addWidget(searchSelectionCheckBox);
    extension->setLayout(extensionLayout);

    QHBoxLayout *topLeftLayout = new QHBoxLayout;
    topLeftLayout->addWidget(label);
    topLeftLayout->addWidget(lineEdit);

    QVBoxLayout *leftLayout = new QVBoxLayout;
    leftLayout->addLayout(topLeftLayout);
    leftLayout->addWidget(caseCheckBox);
    leftLayout->addWidget(fromStartCheckBox);

    QGridLayout *mainLayout = new QGridLayout;
    mainLayout->setSizeConstraint(QLayout::SetFixedSize);
    mainLayout->addLayout(leftLayout, 0, 0);
    mainLayout->addWidget(buttonBox, 0, 1);
    mainLayout->addWidget(extension, 1, 0, 1, 2);
    mainLayout->setRowStretch(2, 1);

    setLayout(mainLayout);

    setWindowTitle(tr("对话框延伸"));
    extension->hide();
}
