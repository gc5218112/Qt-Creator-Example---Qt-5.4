#ifndef HAPPYBIRTHDAYSONG_H
#define HAPPYBIRTHDAYSONG_H

#include <QQmlPropertyValueSource>
#include <QQmlProperty>

#include <QStringList>

class HappyBirthdaySong : public QObject, public QQmlPropertyValueSource
{
    Q_OBJECT
    Q_PROPERTY(QString name READ name WRITE setName NOTIFY nameChanged)
    Q_INTERFACES(QQmlPropertyValueSource)
public:
    HappyBirthdaySong(QObject *parent = 0);

    virtual void setTarget(const QQmlProperty &);

    QString name() const;
    void setName(const QString &);

private slots:
    void advance();

signals:
    void nameChanged();
private:
    int m_line;
    QStringList m_lyrics;
    QQmlProperty m_target;
    QString m_name;
};

#endif // HAPPYBIRTHDAYSONG_H

