#include <QtCore/qbytearray.h>
#include <QtCore/qpair.h>
#include <QtCore/qjsondocument.h>
#include <QtCore/qjsonobject.h>
#include <QtCore/qsortfilterproxymodel.h>
#include <Enginio/enginioclient.h>
#include <Enginio/enginioreply.h>
#include <QtGui/qicon.h>
#include <QtWidgets/qpushbutton.h>
#include "addressbookmodel.h"
#include "backendhelper.h"
#include "mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    setupUi(this);
    QByteArray EnginioBackendId = backendId("云端地址簿");

    client = new EnginioClient(this);
    client->setBackendId(EnginioBackendId);

    // this line is a debugging conviniance, passing all errors to qDebug()
    QObject::connect(client, &EnginioClient::error, this, &MainWindow::error);

    model = new AddressBookModel(this);
    model->setClient(client);

    QJsonObject query;
    query["objectType"] = QString::fromUtf8("objects.addressbook");
    model->setQuery(query);
    //![model]

    tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);

    //![assignProxyModel]
    sortFilterProxyModel = new QSortFilterProxyModel(this);
    sortFilterProxyModel->setSourceModel(model);
    tableView->setSortingEnabled(true);
    tableView->setModel(sortFilterProxyModel);
    //![assignProxyModel]

    // create the full text search based on searchEdit text value
    QObject::connect(searchEdit, &QLineEdit::returnPressed, this, &MainWindow::onSearchEdit);

    // clear the status bar when the search is finished
    QObject::connect(model, &AddressBookModel::searchFinished, this, &MainWindow::onSearchFinished);

    // append an empty row
    QObject::connect(add, &QPushButton::clicked, this, &MainWindow::onAddRow);

    // enable remove button when a row is selected
    QObject::connect(tableView->selectionModel(), &QItemSelectionModel::selectionChanged, this, &MainWindow::onSelectionChanged);

    // remove selected rows
    QObject::connect(remove, &QPushButton::clicked, this, &MainWindow::onRemoveRow);
}

void MainWindow::onSearchEdit()
{
    model->newSearch(searchEdit->text());
    statusbar->showMessage(QStringLiteral("Searching for: ") + searchEdit->text());
    searchEdit->clear();
}

void MainWindow::onSearchFinished()
{
    statusbar->showMessage(QStringLiteral("Search finished"), 1500);
}

void MainWindow::onAddRow()
{
    QJsonObject item;
    item.insert("objectType", QString::fromUtf8("objects.addressbook"));
    EnginioReply *reply = model->append(item);
    QObject::connect(reply, &EnginioReply::finished, reply, &EnginioReply::deleteLater);
}

void MainWindow::onSelectionChanged()
{
    remove->setEnabled(tableView->selectionModel()->selectedRows().count());
}

void MainWindow::onRemoveRow()
{
    foreach (const QModelIndex &index, tableView->selectionModel()->selectedRows()) {
        QModelIndex sourceIndex = sortFilterProxyModel->mapToSource(index);
        EnginioReply *reply = model->remove(sourceIndex.row());
        QObject::connect(reply, &EnginioReply::finished, reply, &EnginioReply::deleteLater);
    }
}

void MainWindow::error(EnginioReply *error)
{
    qWarning() << Q_FUNC_INFO << error;
}


