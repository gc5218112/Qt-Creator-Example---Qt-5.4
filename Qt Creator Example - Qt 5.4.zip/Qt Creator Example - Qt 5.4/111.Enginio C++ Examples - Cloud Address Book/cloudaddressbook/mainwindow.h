#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QtWidgets/qmainwindow.h>
#include "ui_mainwindow.h"

QT_BEGIN_NAMESPACE
class EnginioClient;
class EnginioReply;
class QSortFilterProxyModel;
QT_END_NAMESPACE


QT_USE_NAMESPACE

class AddressBookModel;

class MainWindow : public QMainWindow, Ui_MainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = 0);

private slots:
    void onSearchEdit();
    void onSearchFinished();
    void onAddRow();
    void onSelectionChanged();
    void onRemoveRow();
    void error(EnginioReply *error);

private:
    // The Enginio client object used in all enginio operations
    EnginioClient *client;

    // Enginio object model containing addresses
    AddressBookModel *model;
    QSortFilterProxyModel *sortFilterProxyModel;
};

#endif // MAINWINDOW_H
