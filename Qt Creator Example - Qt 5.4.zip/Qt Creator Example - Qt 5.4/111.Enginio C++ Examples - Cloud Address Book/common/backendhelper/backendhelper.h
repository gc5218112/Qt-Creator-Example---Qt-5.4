#ifndef ENGINIO_EXAMPLE_BACKEND_HELPER
#define ENGINIO_EXAMPLE_BACKEND_HELPER

#include <QtCore>

QByteArray backendId(const QString &exampleName);

#endif
