#ifndef MENUS_H
#define MENUS_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
class QTextEdit;
QT_END_NAMESPACE

class QMenus : public QMainWindow
{
    Q_OBJECT

public:
    QMenus(QWidget *parent = 0);

public slots:
    void fileOpen();
    void fileSave();

    void editNormal();
    void editBold();
    void editUnderline();

    void editAdvancedFont();
    void editAdvancedStyle();

    void helpAbout();
    void helpAboutQt();

private:
    QTextEdit *editor;
};

#endif // MENUS_H
