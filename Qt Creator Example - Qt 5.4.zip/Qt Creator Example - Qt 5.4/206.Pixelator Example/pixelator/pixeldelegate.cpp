#include "pixeldelegate.h"
#include <QPainter>
#include <QDebug>

//自定义模型项委托
PixelDelegate::PixelDelegate(QObject *parent)
    : QAbstractItemDelegate(parent)
{
    pixelSize = 12;//像素尺寸
}

void PixelDelegate::paint(QPainter *painter, const QStyleOptionViewItem &option,
                          const QModelIndex &index) const
{
    if (option.state & QStyle::State_Selected)
    {
        //painter->fillRect(option.rect, Qt::red);//选中的项变成红色
        painter->fillRect(option.rect, option.palette.highlight());
    }

    int size = qMin(option.rect.width(), option.rect.height());
    //当前位置在模型中的值，即该位置的像素的灰度值，范围：0~255
    int brightness = index.model()->data(index, Qt::DisplayRole).toInt();
    //半径，即影响的范围，和像素值有关，0~6
    double radius = (size / 2.0) - (brightness / 255.0 * size / 2.0);
    qDebug()<<size<<" "<<brightness<<" "<<radius;

    if (radius == 0.0)//则不绘制圆，是白色的
    {
        return;
    }

    painter->save();
    painter->setRenderHint(QPainter::Antialiasing, true);
    painter->setPen(Qt::NoPen);
    if (option.state & QStyle::State_Selected)
    {
        painter->setBrush(option.palette.highlightedText());
    }
    else
    {
        painter->setBrush(option.palette.text());
    }

    //绘制一个圆
    painter->drawEllipse(QRectF(option.rect.x() + option.rect.width() / 2 - radius,
                                option.rect.y() + option.rect.height() / 2 - radius,
                                2 * radius, 2 * radius));
    painter->restore();
}

//设置模型项的尺寸
QSize PixelDelegate::sizeHint(const QStyleOptionViewItem & /* option */,
                              const QModelIndex & /* index */) const
{
    return QSize(pixelSize, pixelSize);
}

void PixelDelegate::setPixelSize(int size)
{
    pixelSize = size;
}
