#include "imagemodel.h"

//自定义图片模型，模型中的数据来自于图片像素
ImageModel::ImageModel(QObject *parent)
    : QAbstractTableModel(parent)
{
}

//设置要处理图片
void ImageModel::setImage(const QImage &image)
{
    beginResetModel();//模型状态重置开始
    modelImage = image;
    endResetModel();//模型状态重置结束
}

int ImageModel::rowCount(const QModelIndex & /* parent */) const
{
    return modelImage.height();
}

int ImageModel::columnCount(const QModelIndex & /* parent */) const
{
    return modelImage.width();
}

QVariant ImageModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || role != Qt::DisplayRole)
    {
        return QVariant();
    }
    //图像的灰度图的像素值
    return qGray(modelImage.pixel(index.column(), index.row()));
}

QVariant ImageModel::headerData(int /* section */,
                                Qt::Orientation /* orientation */,
                                int role) const
{
    if (role == Qt::SizeHintRole)//该数据的数据角色是：表示一个数据项所占据的屏幕尺寸（QSize类型的）
    {
        return QSize(1, 1);
    }
    return QVariant();
}
