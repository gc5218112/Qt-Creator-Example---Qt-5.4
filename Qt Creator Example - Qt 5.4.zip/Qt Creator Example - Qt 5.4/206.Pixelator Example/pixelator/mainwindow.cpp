#include "imagemodel.h"
#include "mainwindow.h"
#include "pixeldelegate.h"
#include <QtWidgets>
#ifndef QT_NO_PRINTER
#include <QPrinter>
#include <QPrintDialog>
#endif

MainWindow::MainWindow()
{
    currentPath = QDir::homePath();
    model = new ImageModel(this);

    QWidget *centralWidget = new QWidget;

    view = new QTableView;
    view->setShowGrid(false);//不显示网格
    view->horizontalHeader()->hide();//水平、垂直头都不可见
    view->verticalHeader()->hide();
    view->horizontalHeader()->setMinimumSectionSize(1);
    view->verticalHeader()->setMinimumSectionSize(1);
    view->setModel(model);//显示的数据是一张图像的灰度像素值

    //不设置委托则显示的是像素的灰度值
    PixelDelegate *delegate = new PixelDelegate(this);
    view->setItemDelegate(delegate);

    QLabel *pixelSizeLabel = new QLabel(tr("像素尺寸："));
    QSpinBox *pixelSizeSpinBox = new QSpinBox;
    pixelSizeSpinBox->setMinimum(4);
    pixelSizeSpinBox->setMaximum(32);
    pixelSizeSpinBox->setValue(12);

    QMenu *fileMenu = new QMenu(tr("文件"), this);
    QAction *openAction = fileMenu->addAction(tr("打开"));
    openAction->setShortcuts(QKeySequence::Open);

    printAction = fileMenu->addAction(tr("打印"));
    printAction->setEnabled(false);
    printAction->setShortcut(QKeySequence::Print);

    QAction *quitAction = fileMenu->addAction(tr("退出"));
    quitAction->setShortcuts(QKeySequence::Quit);

    menuBar()->addMenu(fileMenu);
    menuBar()->addSeparator();

    connect(openAction, SIGNAL(triggered()), this, SLOT(chooseImage()));
    connect(printAction, SIGNAL(triggered()), this, SLOT(printImage()));
    connect(quitAction, SIGNAL(triggered()), qApp, SLOT(quit()));
    connect(pixelSizeSpinBox, SIGNAL(valueChanged(int)), delegate, SLOT(setPixelSize(int)));
    connect(pixelSizeSpinBox, SIGNAL(valueChanged(int)), this, SLOT(updateView()));

    QHBoxLayout *controlsLayout = new QHBoxLayout;
    controlsLayout->addWidget(pixelSizeLabel);
    controlsLayout->addWidget(pixelSizeSpinBox);
    controlsLayout->addStretch(1);

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout->addWidget(view);
    mainLayout->addLayout(controlsLayout);
    centralWidget->setLayout(mainLayout);

    setCentralWidget(centralWidget);

    setWindowTitle(tr("字符画"));
    resize(640, 480);
}

void MainWindow::chooseImage()
{
    QString fileName = QFileDialog::getOpenFileName(this, tr("选择图片"), currentPath, "*");

    if (!fileName.isEmpty())
    {
        openImage(fileName);
    }
}

void MainWindow::openImage(const QString &fileName)
{
    QImage image;

    if (image.load(fileName))
    {
        model->setImage(image);
        if (!fileName.startsWith(":/"))
        {
            currentPath = fileName;
            //文件路径显示在标题栏
            setWindowTitle(tr("%1 - 像素转换器").arg(currentPath));
        }

        printAction->setEnabled(true);
        updateView();
    }
}

//打印灰度字符图
void MainWindow::printImage()
{
#if !defined(QT_NO_PRINTER) && !defined(QT_NO_PRINTDIALOG)
    if (model->rowCount(QModelIndex()) * model->columnCount(QModelIndex()) > 90000)
    {
        QMessageBox::StandardButton answer;
        answer = QMessageBox::question(this, tr("图像尺寸太大"),
                                       tr("要打印的图像可能非常大，确定打印？"),
                                       QMessageBox::Yes | QMessageBox::No);
        if (answer == QMessageBox::No)
        {
            return;
        }
    }

    QPrinter printer(QPrinter::HighResolution);

    QPrintDialog dlg(&printer, this);
    dlg.setWindowTitle(tr("打印图像"));

    if (dlg.exec() != QDialog::Accepted)
    {
        return;
    }

    QPainter painter;
    painter.begin(&printer);

    int rows = model->rowCount(QModelIndex());
    int columns = model->columnCount(QModelIndex());
    int sourceWidth = (columns + 1) * ItemSize;
    int sourceHeight = (rows + 1) * ItemSize;

    painter.save();

    double xscale = printer.pageRect().width() / double(sourceWidth);
    double yscale = printer.pageRect().height() / double(sourceHeight);
    double scale = qMin(xscale, yscale);

    painter.translate(printer.paperRect().x() + printer.pageRect().width() / 2,
                      printer.paperRect().y() + printer.pageRect().height() / 2);
    painter.scale(scale, scale);
    painter.translate(-sourceWidth / 2, -sourceHeight / 2);

    QStyleOptionViewItem option;
    QModelIndex parent = QModelIndex();

    QProgressDialog progress(tr("正在打印"), tr("取消"), 0, rows, this);
    progress.setWindowModality(Qt::ApplicationModal);//模态
    float y = ItemSize / 2;

    for (int row = 0; row < rows; ++row)
    {
        progress.setValue(row);
        qApp->processEvents();
        if (progress.wasCanceled())
        {
            break;
        }

        float x = ItemSize / 2;

        for (int column = 0; column < columns; ++column)
        {
            option.rect = QRect(int(x), int(y), ItemSize, ItemSize);
            view->itemDelegate()->paint(&painter, option,
                                        model->index(row, column, parent));
            x = x + ItemSize;
        }
        y = y + ItemSize;
    }
    progress.setValue(rows);

    painter.restore();
    painter.end();

    if (progress.wasCanceled())
    {
        QMessageBox::information(this, tr("取消打印"), tr("打印已取消"), QMessageBox::Cancel);
    }
#else
    QMessageBox::information(this, tr("打印取消"), tr("此Qt构建不支持打印"), QMessageBox::Cancel);
#endif
}

void MainWindow::updateView()
{
    view->resizeColumnsToContents();//根据内容调整列宽
    view->resizeRowsToContents();//根据内容调整行高
}
