#include <QtCore>
#include <stdio.h>
#include <QDebug>

//阶乘 b*n!(b为常数)
class Factorial : public QObject
{
    Q_OBJECT
    Q_PROPERTY(int x READ x WRITE setX)
    Q_PROPERTY(int fac READ fac WRITE setFac)
public:
    Factorial(QObject *parent = 0)
        : QObject(parent), m_x(-1), m_fac(1)
    {
    }

    int x() const
    {
        return m_x;
    }

    void setX(int x)
    {
        if (x == m_x)
        {
            return;
        }
        m_x = x;
        emit xChanged(x);
    }

    int fac() const
    {
        return m_fac;
    }

    void setFac(int fac)
    {
        m_fac = fac;
    }

Q_SIGNALS:
    void xChanged(int value);

private:
    int m_x;//b*n!(b为常数)...n
    int m_fac;//b*n!(b为常数)...b
};

//无目标转换 转换之后状态不变，只是属性值变了
class FactorialLoopTransition : public QSignalTransition
{
public:
    FactorialLoopTransition(Factorial *fact)
        : QSignalTransition(fact, SIGNAL(xChanged(int))), m_fact(fact)
    {}

    //信号转换条件 b*n! 这里当n>1时转换信号
    virtual bool eventTest(QEvent *e) Q_DECL_OVERRIDE
    {
        if (!QSignalTransition::eventTest(e))
        {
            return false;
        }
        QStateMachine::SignalEvent *se = static_cast<QStateMachine::SignalEvent*>(e);
        qDebug()<<se->arguments().at(0).toInt();
        return se->arguments().at(0).toInt() > 1;
    }

    //当状态转换时调用此函数 b*n!     b=b*n,n=n-1
    virtual void onTransition(QEvent *e) Q_DECL_OVERRIDE
    {
        QStateMachine::SignalEvent *se = static_cast<QStateMachine::SignalEvent*>(e);
        int x = se->arguments().at(0).toInt();
        int fac = m_fact->property("fac").toInt();
        m_fact->setProperty("fac",  x * fac);
        m_fact->setProperty("x",  x - 1);
    }

private:
    Factorial *m_fact;
};

class FactorialDoneTransition : public QSignalTransition
{
public:
    FactorialDoneTransition(Factorial *fact)
        : QSignalTransition(fact, SIGNAL(xChanged(int))), m_fact(fact)
    {}

    //b*n! 这里当n=1时转换信号
    virtual bool eventTest(QEvent *e) Q_DECL_OVERRIDE
    {
        if (!QSignalTransition::eventTest(e))
        {
            return false;
        }
        QStateMachine::SignalEvent *se = static_cast<QStateMachine::SignalEvent*>(e);
        return se->arguments().at(0).toInt() == 1;
    }

    //b=b*n 打印出此时b的值
    virtual void onTransition(QEvent *) Q_DECL_OVERRIDE
    {
        fprintf(stdout, "%d\n", m_fact->property("fac").toInt());
    }

private:
    Factorial *m_fact;
};

int main(int argc, char **argv)
{
    QCoreApplication app(argc, argv);
    Factorial factorial;
    QStateMachine machine;

    QState *compute = new QState(&machine);
    compute->assignProperty(&factorial, "fac", 4);
    compute->assignProperty(&factorial, "x", 6);
    //当x>1时无目标转换，只改变值，状态不变--计算
    compute->addTransition(new FactorialLoopTransition(&factorial));

    //当x=1时，切换到此状态--打印结果
    QFinalState *done = new QFinalState(&machine);

    FactorialDoneTransition *doneTransition = new FactorialDoneTransition(&factorial);
    doneTransition->setTargetState(done);
    compute->addTransition(doneTransition);

    machine.setInitialState(compute);
    QObject::connect(&machine, SIGNAL(finished()), &app, SLOT(quit()));
    machine.start();

    return app.exec();
}

#include "main.moc"
