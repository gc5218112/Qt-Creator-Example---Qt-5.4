#include "pathstroke.h"
#include <QApplication>

int main(int argc, char **argv)
{
    Q_INIT_RESOURCE(pathstroke);

    QApplication app(argc, argv);

    bool smallScreen = QApplication::arguments().contains("-small-screen");

    PathStrokeWidget pathStrokeWidget(smallScreen);
    QStyle *arthurStyle = new ArthurStyle();
    pathStrokeWidget.setStyle(arthurStyle);
    QList<QWidget *> widgets = pathStrokeWidget.findChildren<QWidget *>();
    foreach (QWidget *w, widgets)
    {
        w->setStyle(arthurStyle);
        w->setAttribute(Qt::WA_AcceptTouchEvents);
    }

    if (smallScreen)
        pathStrokeWidget.showFullScreen();
    else
        pathStrokeWidget.show();

#ifdef QT_KEYPAD_NAVIGATION
    QApplication::setNavigationMode(Qt::NavigationModeCursorAuto);
#endif
    return app.exec();
}
