#include <QtWin>
#include <QGuiApplication>
#include <QScopedArrayPointer>
#include <QStringList>
#include <QPixmap>
#include <QImage>
#include <QFileInfo>
#include <QDir>
#include <iostream>
#include <QDebug>

int main(int argc, char *argv[])
{
    QGuiApplication a(argc, argv);

    //应用的参数列表
    QStringList arguments = QCoreApplication::arguments();
    arguments.pop_front();
    const bool large = !arguments.isEmpty() && arguments.front() == "-l";
    if (large)
    {
        arguments.pop_front();
    }

    if (arguments.size() < 1)
    {
        std::cout << "此程序在可执行文件目录下用命令行运行，带参数：要提取的文件名" << QT_VERSION_STR << "\n";
        return 1;
    }
    const QString sourceFile = arguments.at(0);
    QString imageFileRoot = arguments.size() > 1 ? arguments.at(1) : QDir::currentPath();
    const QFileInfo imageFileRootInfo(imageFileRoot);
    if (!imageFileRootInfo.isDir())
    {
        std::cerr << imageFileRoot.toStdString() << "不是文件夹\n";
        return 1;
    }

    const UINT iconCount = ExtractIconEx((wchar_t *)sourceFile.utf16(), -1, 0, 0, 0);
    if (!iconCount)
    {
        std::cerr << sourceFile.toStdString() << "不包含图标\n";
        return 1;
    }

    QScopedArrayPointer<HICON> icons(new HICON[iconCount]);
    const UINT extractedIconCount = large ? ExtractIconEx((wchar_t *)sourceFile.utf16(), 0, icons.data(), 0, iconCount) :
                                            ExtractIconEx((wchar_t *)sourceFile.utf16(), 0, 0, icons.data(), iconCount);
    if (!extractedIconCount)
    {
        qErrnoWarning("从%s提取图标失败", qPrintable(sourceFile));
        return 1;
    }

    std::cout << sourceFile.toStdString() << " contains " << extractedIconCount << " icon(s).\n";

    imageFileRoot = imageFileRootInfo.absoluteFilePath() + QLatin1Char('/') + QFileInfo(sourceFile).baseName();
    for (UINT i = 0; i < extractedIconCount; ++i)
    {
        const QPixmap pixmap = QtWin::fromHICON(icons[i]);
        if (pixmap.isNull())
        {
            std::cerr << "图标转换成图片出错\n";
            return 1;
        }
        const QString fileName = QString::fromLatin1("%1%2.png").arg(imageFileRoot).arg(i, 3, 10, QLatin1Char('0'));
        if (!pixmap.save(fileName))
        {
            std::cerr << "写入图片文件失败" << fileName.toStdString() << ".\n";
            return 1;
        }
        std::cout << "完成图片写入"
                  << QDir::toNativeSeparators(fileName).toStdString() << ".\n";
    }
    return 0;
}
