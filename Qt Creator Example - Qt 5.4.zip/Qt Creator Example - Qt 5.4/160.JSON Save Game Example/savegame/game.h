#ifndef GAME_H
#define GAME_H

#include <QJsonObject>
#include <QList>
#include "character.h"
#include "level.h"

class Game
{
public:
    Game();

    enum SaveFormat //保存格式
    {
        Json, //Json格式
        Binary//二进制格式
    };

    const Character &player() const;
    const QList<Level> &levels() const;

    void newGame();
    bool loadGame(SaveFormat saveFormat);
    bool saveGame(SaveFormat saveFormat) const;

    void read(const QJsonObject &json);
    void write(QJsonObject &json) const;
private:
    Character mPlayer;
    QList<Level> mLevels;
};

#endif // GAME_H
