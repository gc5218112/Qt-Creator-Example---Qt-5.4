#include "game.h"
#include <QFile>
#include <QJsonArray>
#include <QJsonDocument>
#include <QDebug>

Game::Game()
{
}

const Character &Game::player() const
{
    return mPlayer;
}

const QList<Level> &Game::levels() const
{
    return mLevels;
}

void Game::newGame()
{
    mPlayer = Character();//新建一个游戏角色
    mPlayer.setName(QObject::tr("张三"));
    mPlayer.setClassType(Character::Archer);
    mPlayer.setLevel(15);

    mLevels.clear();

    Level village;//村子
    QList<Character> villageNpcs;
    //集合中加入一个角色：铁匠巴里，10级，战士
    villageNpcs.append(Character(QObject::tr("铁匠巴里"), 10, Character::Warrior));
    //集合中加入一个角色：商人特里，10级，战士
    villageNpcs.append(Character(QObject::tr("商人特里"), 10, Character::Warrior));
    village.setNpcs(villageNpcs);//此集合中的角色设为NPC
    mLevels.append(village);

    Level dungeon;//地牢
    QList<Character> dungeonNpcs;
    //集合中加入3个角色
    dungeonNpcs.append(Character(QObject::tr("邪恶的埃里克"), 20, Character::Mage));
    dungeonNpcs.append(Character(QObject::tr("埃里克的助手1"), 5, Character::Warrior));
    dungeonNpcs.append(Character(QObject::tr("埃里克的助手2"), 5, Character::Warrior));
    dungeon.setNpcs(dungeonNpcs);//此集合中角色设为NPC
    mLevels.append(dungeon);
}

//载入游戏存档
bool Game::loadGame(Game::SaveFormat saveFormat)
{
    QFile loadFile(saveFormat == Json ? QObject::tr("../savegame/save.json") : QObject::tr("../savegame/save.dat"));

    if (!loadFile.open(QIODevice::ReadOnly))
    {
        qWarning("无法打开存档文件");
        return false;
    }

    QByteArray saveData = loadFile.readAll();

    QJsonDocument loadDoc(saveFormat == Json ? QJsonDocument::fromJson(saveData) : QJsonDocument::fromBinaryData(saveData));
    qDebug()<<loadDoc.toVariant();

    read(loadDoc.object());

    return true;
}

bool Game::saveGame(Game::SaveFormat saveFormat) const
{
    QFile saveFile(saveFormat == Json ? QObject::tr("../savegame/save.json") : QObject::tr("../savegame/save.dat"));

    if (!saveFile.open(QIODevice::WriteOnly))
    {
        qWarning("无法保存存档文件");
        return false;
    }

    QJsonObject gameObject;
    write(gameObject);
    QJsonDocument saveDoc(gameObject);
    saveFile.write(saveFormat == Json ? saveDoc.toJson() : saveDoc.toBinaryData());

    return true;
}

//读取游戏存档
void Game::read(const QJsonObject &json)
{
    mPlayer.read(json["player"].toObject());//读取json文件中的"player"对象

    mLevels.clear();
    QJsonArray levelArray = json["levels"].toArray();//读取json文件中的"levels"数组
    for (int levelIndex = 0; levelIndex < levelArray.size(); ++levelIndex)
    {
        QJsonObject levelObject = levelArray[levelIndex].toObject();//该数组含多个QJsonObject对象
        Level level;
        level.read(levelObject);
        mLevels.append(level);
    }
}

void Game::write(QJsonObject &json) const
{
    QJsonObject playerObject;
    mPlayer.write(playerObject);
    json["player"] = playerObject;

    QJsonArray levelArray;
    foreach (const Level level, mLevels)
    {
        QJsonObject levelObject;
        level.write(levelObject);
        levelArray.append(levelObject);
    }
    json["levels"] = levelArray;
}
