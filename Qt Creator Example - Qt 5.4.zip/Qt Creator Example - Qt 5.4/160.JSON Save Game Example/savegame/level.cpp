#include "level.h"
#include <QJsonArray>
#include <QDebug>

//游戏场景
Level::Level()
{
}

//返回本场景的NPC列表
const QList<Character> &Level::npcs() const
{
    return mNpcs;
}

void Level::setNpcs(const QList<Character> &npcs)
{
    mNpcs = npcs;
}

//读取QJsonArray数组中的NPC信息
void Level::read(const QJsonObject &json)
{
    mNpcs.clear();
    QJsonArray npcArray = json["npcs"].toArray();
    for (int npcIndex = 0; npcIndex < npcArray.size(); ++npcIndex)
    {
        QJsonObject npcObject = npcArray[npcIndex].toObject();
        Character npc;
        npc.read(npcObject);
        mNpcs.append(npc);
    }
}

//将场景中所有的NPC信息写入QJsonArray数组
void Level::write(QJsonObject &json) const
{
    QJsonArray npcArray;
    foreach (const Character npc, mNpcs)
    {
        QJsonObject npcObject;
        npc.write(npcObject);//当前NPC信息创建QJsonObject对象
        npcArray.append(npcObject);//该QJsonObject对象添加到QJsonArray数组
    }
    json["npcs"] = npcArray;
}
