#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "ui_mainwindowbase.h"

QT_BEGIN_NAMESPACE
class QPrinter;
class QTextEdit;
class QTreeWidget;
class QTreeWidgetItem;
QT_END_NAMESPACE

typedef QList<QTreeWidgetItem *> StyleItems;

class MainWindow : public QMainWindow, private Ui::MainWindowBase
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = 0);

public slots:
    void on_action_select_triggered();
#if !defined(QT_NO_PRINTER) && !defined(QT_NO_PRINTDIALOG)
    void on_action_print_triggered();
    void on_action_printPreview_triggered();
#endif
    void on_action_unsecelct_triggered();
#if !defined(QT_NO_PRINTER) && !defined(QT_NO_PRINTDIALOG)
    void printDocument(QPrinter *printer);
    void printPage(int index, QPainter *painter, QPrinter *printer);
#endif
    void showFont(QTreeWidgetItem *item);
    void updateStyles(QTreeWidgetItem *item, int column);

private:
    QMap<QString, StyleItems> currentPageMap();
    void markUnmarkFonts(Qt::CheckState state);
    void setupFontTree();

    QList<int> sampleSizes;
    QMap<QString, StyleItems> pageMap;
    int markedCount;//所有选中项的总个数
};

#endif // MAINWINDOW_H
