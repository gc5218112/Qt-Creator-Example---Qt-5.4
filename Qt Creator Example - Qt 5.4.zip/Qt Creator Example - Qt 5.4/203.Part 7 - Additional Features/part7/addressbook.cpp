#include <QtWidgets>
#include "addressbook.h"

AddressBook::AddressBook(QWidget *parent)
    : QWidget(parent)
{
    QLabel *nameLabel = new QLabel(tr("名字："));
    nameLine = new QLineEdit;
    nameLine->setReadOnly(true);

    QLabel *addressLabel = new QLabel(tr("地址："));
    addressText = new QTextEdit;
    addressText->setReadOnly(true);

    addButton = new QPushButton(tr("添加"));

    editButton = new QPushButton(tr("编辑"));
    editButton->setEnabled(false);

    removeButton = new QPushButton(tr("删除"));
    removeButton->setEnabled(false);

    findButton = new QPushButton(tr("查找"));
    findButton->setEnabled(false);

    submitButton = new QPushButton(tr("提交"));
    submitButton->hide();

    cancelButton = new QPushButton(tr("取消"));
    cancelButton->hide();

    nextButton = new QPushButton(tr("下一个"));
    nextButton->setEnabled(false);

    previousButton = new QPushButton(tr("前一个"));
    previousButton->setEnabled(false);

    loadButton = new QPushButton(tr("载入"));
    loadButton->setToolTip(tr("从文件中加载联系人"));

    saveButton = new QPushButton(tr("保存"));
    saveButton->setToolTip(tr("将联系人保存到文件"));
    saveButton->setEnabled(false);

    exportButton = new QPushButton(tr("导出"));
    exportButton->setToolTip(tr("以vCard形式导出"));
    exportButton->setEnabled(false);

    dialog = new FindDialog(this);

    connect(addButton, SIGNAL(clicked()), this, SLOT(addContact()));
    connect(submitButton, SIGNAL(clicked()), this, SLOT(submitContact()));
    connect(editButton, SIGNAL(clicked()), this, SLOT(editContact()));
    connect(cancelButton, SIGNAL(clicked()), this, SLOT(cancel()));
    connect(removeButton, SIGNAL(clicked()), this, SLOT(removeContact()));
    connect(findButton, SIGNAL(clicked()), this, SLOT(findContact()));
    connect(nextButton, SIGNAL(clicked()), this, SLOT(next()));
    connect(previousButton, SIGNAL(clicked()), this, SLOT(previous()));
    connect(loadButton, SIGNAL(clicked()), this, SLOT(loadFromFile()));
    connect(saveButton, SIGNAL(clicked()), this, SLOT(saveToFile()));
    connect(exportButton, SIGNAL(clicked()), this, SLOT(exportAsVCard()));

    QVBoxLayout *buttonLayout1 = new QVBoxLayout;
    buttonLayout1->addWidget(addButton);
    buttonLayout1->addWidget(editButton);
    buttonLayout1->addWidget(removeButton);
    buttonLayout1->addWidget(findButton);
    buttonLayout1->addWidget(submitButton);
    buttonLayout1->addWidget(cancelButton);
    buttonLayout1->addWidget(loadButton);
    buttonLayout1->addWidget(saveButton);
    buttonLayout1->addWidget(exportButton);
    buttonLayout1->addStretch();

    QHBoxLayout *buttonLayout2 = new QHBoxLayout;
    buttonLayout2->addWidget(previousButton);
    buttonLayout2->addWidget(nextButton);

    QGridLayout *mainLayout = new QGridLayout;
    mainLayout->addWidget(nameLabel, 0, 0);
    mainLayout->addWidget(nameLine, 0, 1);
    mainLayout->addWidget(addressLabel, 1, 0, Qt::AlignTop);
    mainLayout->addWidget(addressText, 1, 1);
    mainLayout->addLayout(buttonLayout1, 1, 2);
    mainLayout->addLayout(buttonLayout2, 2, 1);

    setLayout(mainLayout);
    setWindowTitle(tr("地址薄"));
}

//添加
void AddressBook::addContact()
{
    oldName = nameLine->text();
    oldAddress = addressText->toPlainText();

    nameLine->clear();
    addressText->clear();

    updateInterface(AddingMode);
}

//编辑
void AddressBook::editContact()
{
    oldName = nameLine->text();
    oldAddress = addressText->toPlainText();

    updateInterface(EditingMode);
}

//提交
void AddressBook::submitContact()
{
    QString name = nameLine->text();
    QString address = addressText->toPlainText();

    if (name.isEmpty() || address.isEmpty())
    {
        QMessageBox::information(this, tr("空域"), tr("请输入姓名和地址"));
        return;
    }

    if (currentMode == AddingMode)
    {
        if (!contacts.contains(name))
        {
            contacts.insert(name, address);
            QMessageBox::information(this, tr("添加成功"), tr("\"%1\"已添加到通讯录中").arg(name));
        }
        else
        {
            QMessageBox::information(this, tr("添加失败"), tr("\"%1\"已经在你的通讯录里了").arg(name));
        }
    }
    else if (currentMode == EditingMode)
    {
        if (oldName != name)
        {
            if (!contacts.contains(name))
            {
                QMessageBox::information(this, tr("编辑成功"), tr("\"%1\"已在通讯录中编辑").arg(oldName));
                contacts.remove(oldName);
                contacts.insert(name, address);
            }
            else
            {
                QMessageBox::information(this, tr("编辑不成功"), tr("\"%1\"已在通讯录中编辑").arg(name));
            }
        }
        else if (oldAddress != address)
        {
            QMessageBox::information(this, tr("编辑成功"), tr("\"%1\"已在通讯录中编辑").arg(name));
            contacts[name] = address;
        }
    }

    updateInterface(NavigationMode);
}

//取消
void AddressBook::cancel()
{
    nameLine->setText(oldName);
    addressText->setText(oldAddress);
    updateInterface(NavigationMode);
}

//删除
void AddressBook::removeContact()
{
    QString name = nameLine->text();

    if (contacts.contains(name))
    {
        int button = QMessageBox::question(this, tr("确认删除"), tr("您确定要删除吗\"%1\"？").arg(name),
                                           QMessageBox::Yes | QMessageBox::No);

        if (button == QMessageBox::Yes)
        {
            previous();
            contacts.remove(name);
            QMessageBox::information(this, tr("删除成功"), tr("\"%1\"已从通讯录中删除").arg(name));
        }
    }

    updateInterface(NavigationMode);
}

//显示下一条
void AddressBook::next()
{
    QString name = nameLine->text();
    QMap<QString, QString>::iterator i = contacts.find(name);

    if (i != contacts.end())
    {
        i++;
    }

    if (i == contacts.end())
    {
        i = contacts.begin();
    }

    nameLine->setText(i.key());
    addressText->setText(i.value());
}

//显示前一条
void AddressBook::previous()
{
    QString name = nameLine->text();
    QMap<QString, QString>::iterator i = contacts.find(name);

    if (i == contacts.end())
    {
        nameLine->clear();
        addressText->clear();
        return;
    }

    if (i == contacts.begin())
    {
        i = contacts.end();
    }

    i--;
    nameLine->setText(i.key());
    addressText->setText(i.value());
}

//查找
void AddressBook::findContact()
{
    dialog->show();

    if (dialog->exec() == 1)
    {
        QString contactName = dialog->getFindText();

        if (contacts.contains(contactName))
        {
            nameLine->setText(contactName);
            addressText->setText(contacts.value(contactName));
        }
        else
        {
            QMessageBox::information(this, tr("无法找到"), tr("\"%1\"不在你的通讯录里").arg(contactName));
            return;
        }
    }

    updateInterface(NavigationMode);
}

//更新模式
void AddressBook::updateInterface(Mode mode)
{
    currentMode = mode;

    switch (currentMode)
    {

        case AddingMode:
        case EditingMode:

            nameLine->setReadOnly(false);//可编辑
            nameLine->setFocus(Qt::OtherFocusReason);
            addressText->setReadOnly(false);//可编辑

            addButton->setEnabled(false);//添加
            editButton->setEnabled(false);//编辑
            removeButton->setEnabled(false);//输出

            nextButton->setEnabled(false);//下一个
            previousButton->setEnabled(false);//前一个

            submitButton->show();
            cancelButton->show();

            loadButton->setEnabled(false);//载入
            saveButton->setEnabled(false);//保存
            exportButton->setEnabled(false);//导入
            break;

        case NavigationMode:

            if (contacts.isEmpty())
            {
                nameLine->clear();
                addressText->clear();
            }

            nameLine->setReadOnly(true);
            addressText->setReadOnly(true);
            addButton->setEnabled(true);

            int number = contacts.size();
            editButton->setEnabled(number >= 1);
            removeButton->setEnabled(number >= 1);
            findButton->setEnabled(number > 2);
            nextButton->setEnabled(number > 1);
            previousButton->setEnabled(number > 1);

            submitButton->hide();
            cancelButton->hide();

            exportButton->setEnabled(number >= 1);

            loadButton->setEnabled(true);
            saveButton->setEnabled(number >= 1);
            break;
    }
}

//保存为abk格式
void AddressBook::saveToFile()
{
    QString fileName = QFileDialog::getSaveFileName(this, tr("保存地址簿"), "",
                                                    tr("Address Book (*.abk);;All Files (*)"));

    if (fileName.isEmpty())
    {
        return;
    }
    else
    {
        QFile file(fileName);

        if (!file.open(QIODevice::WriteOnly))
        {
            QMessageBox::information(this, tr("无法打开文件"), file.errorString());
            return;
        }

        QDataStream out(&file);
        out.setVersion(QDataStream::Qt_5_4);
        out << contacts;
    }

    updateInterface(NavigationMode);
}

//载入
void AddressBook::loadFromFile()
{
    QString fileName = QFileDialog::getOpenFileName(this, tr("打开通讯录"), "",
                                                    tr("Address Book (*.abk);;All Files (*)"));

    if (fileName.isEmpty())
    {
        return;
    }

    else
    {
        QFile file(fileName);

        if (!file.open(QIODevice::ReadOnly))
        {
            QMessageBox::information(this, tr("无法打开文件"), file.errorString());
            return;
        }

        QDataStream in(&file);
        in.setVersion(QDataStream::Qt_5_4);
        contacts.empty();
        in >> contacts;

        QMap<QString, QString>::iterator i = contacts.begin();
        nameLine->setText(i.key());
        addressText->setText(i.value());
    }

    updateInterface(NavigationMode);
}

//以vCard文件形式导出
void AddressBook::exportAsVCard()
{
    QString name = nameLine->text();
    QString address = addressText->toPlainText();
    QString firstName;
    QString lastName;
    QStringList nameList;

    int index = name.indexOf(" ");

    if (index != -1)
    {
        nameList = name.split(QRegExp("\\s+"), QString::SkipEmptyParts);
        firstName = nameList.first();
        lastName = nameList.last();
    }
    else
    {
        firstName = name;
        lastName = "";
    }

    QString fileName = QFileDialog::getSaveFileName(this, tr("以vCard形式导出"), "",
                                                    tr("vCard Files (*.vcf);;All Files (*)"));

    if (fileName.isEmpty())
    {
        return;
    }

    QFile file(fileName);
    if (!file.open(QIODevice::WriteOnly))
    {
        QMessageBox::information(this, tr("无法打开文件"), file.errorString());
        return;
    }

    QTextStream out(&file);
    out << "BEGIN:VCARD" << "\n";
    out << "VERSION:2.1" << "\n";
    out << "N:" << lastName << ";" << firstName << "\n";

    if (!nameList.isEmpty())
    {
        out << "FN:" << nameList.join(' ') << "\n";
    }
    else
    {
        out << "FN:" << firstName << "\n";
    }
    address.replace(";", "\\;", Qt::CaseInsensitive);
    address.replace("\n", ";", Qt::CaseInsensitive);
    address.replace(",", " ", Qt::CaseInsensitive);

    out << "ADR;HOME:;" << address << "\n";
    out << "END:VCARD" << "\n";

    QMessageBox::information(this, tr("导出成功"), tr("\"%1\"已导出为vCard").arg(name));
}
