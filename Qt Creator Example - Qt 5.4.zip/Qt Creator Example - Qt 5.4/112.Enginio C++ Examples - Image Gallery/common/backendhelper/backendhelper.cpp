#include <Enginio/enginioclient.h>
#include <QtWidgets>
#include "backendhelper.h"
#include "ui_helperdialog.h"

const QString backendIdKey = QStringLiteral("backendId");
const QString showAgainKey = QStringLiteral("showAgain");

QByteArray backendId(const QString &exampleName)
{

    QString fileName = QStringLiteral("EnginioExamples.conf");
    for (int i = 0; i < 4; ++i)
    {
        if (QFile::exists(fileName))
            break;
        fileName = fileName.prepend("../");
    }

    QFileInfo settingsFile = QFileInfo(fileName);

    QScopedPointer<QSettings> settings(settingsFile.exists()
        ? new QSettings(settingsFile.absoluteFilePath(), QSettings::IniFormat)
        : new QSettings("com.digia", "EnginioExamples"));

    settings->beginGroup(exampleName);
    QByteArray id = settings->value(backendIdKey).toByteArray();
    bool askAgain = settings->value(showAgainKey, true).toBool();

    if (askAgain || id.isEmpty())
    {
        Ui::Dialog dialog;
        QDialog d;
        dialog.setupUi(&d);
        dialog.exampleName->setText(exampleName);
        dialog.backendId->setText(id);

        if (d.exec() == QDialog::Accepted) {
            id = dialog.backendId->text().toLocal8Bit();
            askAgain = !dialog.askAgain->isChecked();
            settings->setValue(backendIdKey, id);
            settings->setValue(showAgainKey, askAgain);
        }
    }

    settings->endGroup();
    settings->sync();

    return id;
}

