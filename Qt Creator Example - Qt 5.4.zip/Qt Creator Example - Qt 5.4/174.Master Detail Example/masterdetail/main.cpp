#include <QtWidgets>
#include "database.h"
#include "mainwindow.h"

int main(int argc, char *argv[])
{
    Q_INIT_RESOURCE(masterdetail);

    QApplication app(argc, argv);

    if (!createConnection())//创建artists（艺术家）、albums（专辑）表
    {
        return 1;
    }

    QFile *albumDetails = new QFile("../masterdetail/albumdetails.xml");
    MainWindow window("artists", "albums", albumDetails);
    window.show();
    return app.exec();
}
