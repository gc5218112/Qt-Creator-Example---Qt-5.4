#include "mainwindow.h"
#include "dialog.h"
#include <QtWidgets>
#include <QtSql>
#include <QtXml>
#include <QDebug>

extern int uniqueAlbumId;
extern int uniqueArtistId;

MainWindow::MainWindow(const QString &artistTable, const QString &albumTable,
                       QFile *albumDetails, QWidget *parent)
     : QMainWindow(parent)
{
    file = albumDetails;
    readAlbumData();//读取文件保存成DOM树

    model = new QSqlRelationalTableModel(this);//数据库关系表模型
    model->setTable(albumTable);//模型数据来源于"专辑"表
    //将专辑表的第3列设置为"艺术家"表"id"列的外键，在"专辑"表中显示此列时显示的列名为"artist"
    model->setRelation(2, QSqlRelation(artistTable, "id", "artist"));
    model->select();

    QGroupBox *artists = createArtistGroupBox();
    QGroupBox *albums = createAlbumGroupBox();
    QGroupBox *details = createDetailsGroupBox();

    artistView->setCurrentIndex(0);
    uniqueAlbumId = model->rowCount();
    uniqueArtistId = artistView->count();

    connect(model, SIGNAL(rowsInserted(QModelIndex,int,int)), this, SLOT(updateHeader(QModelIndex,int,int)));
    connect(model, SIGNAL(rowsRemoved(QModelIndex,int,int)), this, SLOT(updateHeader(QModelIndex,int,int)));

    QGridLayout *layout = new QGridLayout;
    layout->addWidget(artists, 0, 0);
    layout->addWidget(albums, 1, 0);
    layout->addWidget(details, 0, 1, 2, 1);
    layout->setColumnStretch(1, 1);
    layout->setColumnMinimumWidth(0, 500);

    QWidget *widget = new QWidget;
    widget->setLayout(layout);
    setCentralWidget(widget);
    createMenuBar();

    showImageLabel();
    resize(850, 400);
    setWindowTitle(tr("音乐档案"));
}

//艺术家选择下拉框选择的艺术家变化时 row选择的序号
void MainWindow::changeArtist(int row)
{
    if (row > 0)
    {
        //"专辑"表的第3列所关联的外键列所在的表的第row行第2列.即艺术家名字
        QModelIndex index = model->relationModel(2)->index(row, 1);
        //在"专辑"表中筛选（过滤）数据，选择艺术家名字=index.data().toString()的行
        model->setFilter("artist = '" + index.data().toString() + '\'') ;
        showArtistProfile(index);//显示艺术家index.data()的简介
    }
    else if (row == 0)
    {
        model->setFilter(QString());//不设置筛选条件 全部显示"专辑"表信息
        showImageLabel();
    }
    else
    {
        return;
    }
}

//显示艺术家index.data()的简介 QModelIndex模型项
void MainWindow::showArtistProfile(QModelIndex index)
{
    //"专辑"表的第3列所关联的外键列所在的表，即"艺术家表"中该模型项所在的行
    QSqlRecord record = model->relationModel(2)->record(index.row());

    QString name = record.value("artist").toString();
    QString count = record.value("albumcount").toString();
    profileLabel->setText(tr("艺术家：%1 \n" \
                             "专辑数目：%2").arg(name).arg(count));

    profileLabel->show();
    iconLabel->show();

    titleLabel->hide();
    trackList->hide();
    imageLabel->hide();
}

//显示专辑详细信息
void MainWindow::showAlbumDetails(QModelIndex index)
{
    //选中模型项所在的行
    QSqlRecord record = model->record(index.row());

    QString artist = record.value("artist").toString();
    QString title = record.value("title").toString();
    QString year = record.value("year").toString();
    QString albumId = record.value("albumid").toString();

    showArtistProfile(indexOfArtist(artist));
    titleLabel->setText(tr("专辑标题：%1 (%2)").arg(title).arg(year));
    titleLabel->show();

    //DOM树中标签为"album"的节点集合 多个
    QDomNodeList albums = albumData.elementsByTagName("album");
    for (int i = 0; i < albums.count(); i++)
    {
        QDomNode album = albums.item(i);//一个节点
        /*
        <album id="数字" >
            <track number="01" >歌曲01</track>
            <track number="02" >歌曲02</track>
            ......
        </album>
        */
        //id==此专辑id的专辑
        if (album.toElement().attribute("id") == albumId)
        {
            //album.toElement()选中的专辑中所有的歌名
            getTrackList(album.toElement());
            break;
        }
    }
    if (trackList->count() != 0)
    {
        trackList->show();
    }
}

//读取专辑中所有歌名用来创建QListWidgetItem
void MainWindow::getTrackList(QDomNode album)
{
    //album是<album>部分
    /*
    <album>
        <track number="01" >歌曲01</track>
        <track number="02" >歌曲02</track>
        ......
    </album>
    */
    trackList->clear();

    QDomNodeList tracks = album.childNodes();//<track>部分（多个）
    QDomNode track;
    QString trackNumber;

    for (int j = 0; j < tracks.count(); j++)
    {
        track = tracks.item(j);

        //<track number="01">歌曲名</track>
        trackNumber = track.toElement().attribute("number");//歌曲名

        QListWidgetItem *item = new QListWidgetItem(trackList);
        item->setText(trackNumber + ": " + track.toElement().text());
    }
}

//新增专辑
void MainWindow::addAlbum()
{
    //                          模型    DOM树形文档  XML文件
    Dialog *dialog = new Dialog(model, albumData, file, this);
    int accepted = dialog->exec();

    if (accepted == 1)
    {
        int lastRow = model->rowCount() - 1;
        albumView->selectRow(lastRow);
        albumView->scrollToBottom();
        showAlbumDetails(model->index(lastRow, 0));
    }
}

//删除专辑
void MainWindow::deleteAlbum()
{
    //选中的行
    QModelIndexList selection = albumView->selectionModel()->selectedRows(0);

    if (!selection.empty())
    {
        QModelIndex idIndex = selection.at(0);
        int id = idIndex.data().toInt();
        QString title = idIndex.sibling(idIndex.row(), 1).data().toString();
        QString artist = idIndex.sibling(idIndex.row(), 2).data().toString();

        QMessageBox::StandardButton button;
        button = QMessageBox::question(this, tr("删除专辑"),
                                       tr("你确定要删除：'%1'的专辑：'%2'吗？").arg(title, artist),
                                       QMessageBox::Yes | QMessageBox::No);

        if (button == QMessageBox::Yes)
        {
            removeAlbumFromFile(id);
            removeAlbumFromDatabase(idIndex);
            decreaseAlbumCount(indexOfArtist(artist));
            showImageLabel();
        }
    }
    else
    {
        QMessageBox::information(this, tr("Delete Album"),
                                 tr("Select the album you want to delete."));
    }
}

//在DOM树删除<album id=""></album>结点 只删除内存中的，XML文件没删
void MainWindow::removeAlbumFromFile(int id)
{
    //XML文件中所有标签名称为album的标签 有多个
    QDomNodeList albums = albumData.elementsByTagName("album");

    for (int i = 0; i < albums.count(); i++)
    {
        QDomNode node = albums.item(i);//其中一个名称为album的标签
        if (node.toElement().attribute("id").toInt() == id)
        {
            albumData.elementsByTagName("archive").item(0).removeChild(node);
            break;
        }
    }
}

//专辑表中移除此模型项所在的行
void MainWindow::removeAlbumFromDatabase(QModelIndex index)
{
    model->removeRow(index.row());
}

//修改专辑数目
void MainWindow::decreaseAlbumCount(QModelIndex artistIndex)
{
    int row = artistIndex.row();//该模型项所在的行号
    QModelIndex albumCountIndex = artistIndex.sibling(row, 2);
    int albumCount = albumCountIndex.data().toInt();

    //"专辑"表的第3列所关联的外键列所在的表，即"艺术家表"  此模型数据来自此表
    QSqlTableModel *artists = model->relationModel(2);

    if (albumCount == 1)
    {
        artists->removeRow(row);
        showImageLabel();
    }
    else
    {
        artists->setData(albumCountIndex, QVariant(albumCount - 1));
    }
}

//读取文件保存到DOM树型结构
void MainWindow::readAlbumData()
{
    if (!file->open(QIODevice::ReadOnly))//打开此文件
    {
        return;
    }

    if (!albumData.setContent(file))//将XML文档解析为DOM树型结构存入内存中
    {
        file->close();
        return;
    }
    file->close();
}

QGroupBox* MainWindow::createArtistGroupBox()
{
    artistView = new QComboBox;

    //QSqlRelationalTableModel::relationModel(int)
    //返回一个QSqlTableModel对象，用于访问哪个列是外键的表
    //也就是访问第三列所关联的外键列所在的表，将这个表打包成模型 也就是整个"艺术家"表
    artistView->setModel(model->relationModel(2));
    artistView->setModelColumn(1);//该模型的第二列，也就是"艺术家"表第二列，艺术家名字

    //当选择的下拉框的项变化时
    connect(artistView, SIGNAL(currentIndexChanged(int)), this, SLOT(changeArtist(int)));

    QGroupBox *box = new QGroupBox(tr("艺术家"));

    QGridLayout *layout = new QGridLayout;
    layout->addWidget(artistView, 0, 0);
    box->setLayout(layout);

    return box;
}

QGroupBox* MainWindow::createAlbumGroupBox()
{
    QGroupBox *box = new QGroupBox(tr("专辑"));

    albumView = new QTableView;
    albumView->setEditTriggers(QAbstractItemView::NoEditTriggers);//无法编辑
    albumView->setSortingEnabled(true);//可以点击表头排序
    albumView->setSelectionBehavior(QAbstractItemView::SelectRows);//选择只能选中单行
    albumView->setSelectionMode(QAbstractItemView::SingleSelection);//只能单选
    albumView->setShowGrid(false);//显示网格
    albumView->verticalHeader()->hide();//隐藏垂直表头
    albumView->setAlternatingRowColors(true);//隔行自动变色
    albumView->setModel(model);//要显示的数据模型
    adjustHeader();//自动调整表头

    QLocale locale = albumView->locale();
    //QLocale::OmitGroupSeparator 设置数字转成字符串函数将不会在其返回值中插入组分隔符
    locale.setNumberOptions(QLocale::OmitGroupSeparator);
    albumView->setLocale(locale);

    //点击的视图中的内容（选中）
    connect(albumView, SIGNAL(clicked(QModelIndex)), this, SLOT(showAlbumDetails(QModelIndex)));
    connect(albumView, SIGNAL(activated(QModelIndex)), this, SLOT(showAlbumDetails(QModelIndex)));

    QVBoxLayout *layout = new QVBoxLayout;
    layout->addWidget(albumView, 0, 0);
    box->setLayout(layout);

    return box;
}

QGroupBox* MainWindow::createDetailsGroupBox()
{
    QGroupBox *box = new QGroupBox(tr("详细信息"));

    profileLabel = new QLabel;
    profileLabel->setWordWrap(true);
    profileLabel->setAlignment(Qt::AlignBottom);//靠上居中

    titleLabel = new QLabel;
    titleLabel->setWordWrap(true);
    titleLabel->setAlignment(Qt::AlignBottom);

    iconLabel = new QLabel();
    iconLabel->setAlignment(Qt::AlignBottom | Qt::AlignRight);
    iconLabel->setPixmap(QPixmap(":/images/icon.png"));

    imageLabel = new QLabel;
    imageLabel->setWordWrap(true);
    imageLabel->setAlignment(Qt::AlignCenter);
    imageLabel->setPixmap(QPixmap(":/images/image.png"));

    trackList = new QListWidget;

    QGridLayout *layout = new QGridLayout;
    layout->addWidget(imageLabel, 0, 0, 3, 2);
    layout->addWidget(profileLabel, 0, 0);
    layout->addWidget(iconLabel, 0, 1);
    layout->addWidget(titleLabel, 1, 0, 1, 2);
    layout->addWidget(trackList, 2, 0, 1, 2);
    layout->setRowStretch(2, 1);
    box->setLayout(layout);

    return box;
}

//增删改变了内存中的DOM文件和内存中的数据库、XML文件 本程序用的是内存数据库 重新打开程序都恢复（除非删了XML文件默认的的内容）
void MainWindow::createMenuBar()
{
    QAction *addAction = new QAction(tr("新增专辑"), this);
    addAction->setShortcut(tr("Ctrl+A"));

    QAction *deleteAction = new QAction(tr("删除专辑"), this);
    deleteAction->setShortcut(tr("Ctrl+D"));

    QAction *quitAction = new QAction(tr("退出"), this);
    quitAction->setShortcuts(QKeySequence::Quit);

    QMenu *fileMenu = menuBar()->addMenu(tr("文件"));
    fileMenu->addAction(addAction);
    fileMenu->addAction(deleteAction);
    fileMenu->addSeparator();
    fileMenu->addAction(quitAction);

    connect(addAction, SIGNAL(triggered(bool)), this, SLOT(addAlbum()));
    connect(deleteAction, SIGNAL(triggered(bool)), this, SLOT(deleteAlbum()));
    connect(quitAction, SIGNAL(triggered(bool)), this, SLOT(close()));
}

//显示图像标签
void MainWindow::showImageLabel()
{
    profileLabel->hide();
    titleLabel->hide();
    iconLabel->hide();
    trackList->hide();
    imageLabel->show();
}

QModelIndex MainWindow::indexOfArtist(const QString &artist)
{
    //"专辑"表的第3列所关联的外键列所在的表，即"艺术家表"  此模型数据来自此表
    QSqlTableModel *artistModel = model->relationModel(2);

    for (int i = 0; i < artistModel->rowCount(); i++)
    {
        QSqlRecord record =  artistModel->record(i);
        if (record.value("artist") == artist)
        {
            return artistModel->index(i, 1);
        }
    }
    return QModelIndex();
}

void MainWindow::updateHeader(QModelIndex, int, int)
{
    adjustHeader();
}

void MainWindow::adjustHeader()
{
    albumView->hideColumn(0);
    albumView->horizontalHeader()->setSectionResizeMode(1, QHeaderView::Stretch);
    albumView->resizeColumnToContents(2);
    albumView->resizeColumnToContents(3);
}
