#include "dialog.h"

int uniqueAlbumId;
int uniqueArtistId;

//新增专辑对话框
Dialog::Dialog(QSqlRelationalTableModel *albums, QDomDocument details,
               QFile *output, QWidget *parent)
     : QDialog(parent)
{
    model = albums;//模型，数据来源于"专辑"表
    albumDetails = details;//DOM树型文件
    outputFile = output;//XML文件路径（保存创建的结点时有用）

    QGroupBox *inputWidgetBox = createInputWidgets();
    QDialogButtonBox *buttonBox = createButtons();

    QVBoxLayout *layout = new QVBoxLayout;
    layout->addWidget(inputWidgetBox);
    layout->addWidget(buttonBox);
    setLayout(layout);

    setWindowTitle(tr("新增专辑"));
}

//提交按钮
void Dialog::submit()
{
    QString artist = artistEditor->text();
    QString title = titleEditor->text();

    if (artist.isEmpty() || title.isEmpty())
    {
        QMessageBox::information(this, tr("新增专辑"), tr("请输入正确的艺术家名字和专辑名称"));
    }
    else
    {
        int artistId = findArtistId(artist);//看这个艺术家是否存在，存在则返回id,不存在则新建后返回id
        int albumId = addNewAlbum(title, artistId);//新增专辑后返回专辑id

        QStringList tracks;//专辑中的歌名，用逗号分隔
        tracks = tracksEditor->text().split(',', QString::SkipEmptyParts);
        addTracks(albumId, tracks);//专辑id、歌名存入XML文件(专辑id,歌名)

        increaseAlbumCount(indexOfArtist(artist));//更新数据库中艺术家的专辑数量
        accept();
    }
}

//查找此艺术家名字是否存在于表中
int Dialog::findArtistId(const QString &artist)
{
    //"专辑"表的第3列所关联的外键列所在的表，即"艺术家表" 此模型数据来自此表
    QSqlTableModel *artistModel = model->relationModel(2);
    int row = 0;

    while (row < artistModel->rowCount())
    {
        QSqlRecord record = artistModel->record(row);//此表中一行
        if (record.value("artist") == artist)//该行的"artist"列的内容
        {
            return record.value("id").toInt();//返回此行的id，即艺术家id值
        }
        else
        {
            row++;
        }
    }
    return addNewArtist(artist);//没查到就新建一个艺术家
}

//新建艺术家
int Dialog::addNewArtist(const QString &name)
{
    //"专辑"表的第3列所关联的外键列所在的表，即"艺术家表"  此模型数据来自此表
    QSqlTableModel *artistModel = model->relationModel(2);
    QSqlRecord record;//数据表的一行

    int id = generateArtistId();

    //QSqlField 类在SQL数据库表和视图中操作字段，表示数据库中单个列的特征
    QSqlField f1("id", QVariant::Int);
    QSqlField f2("artist", QVariant::String);
    QSqlField f3("albumcount", QVariant::Int);

    f1.setValue(QVariant(id));//设置该行"的"id"列的值为id
    f2.setValue(QVariant(name));//设置该行的"artist"列的值为name
    f3.setValue(QVariant(0));//设置该行的"albumcount"列的值为0

    record.append(f1);
    record.append(f2);
    record.append(f3);

    artistModel->insertRecord(-1, record);//向表中插入该行
    return id;
}

//新增专辑
int Dialog::addNewAlbum(const QString &title, int artistId)
{
    int id = generateAlbumId();
    QSqlRecord record;

    QSqlField f1("albumid", QVariant::Int);
    QSqlField f2("title", QVariant::String);
    QSqlField f3("artistid", QVariant::Int);
    QSqlField f4("year", QVariant::Int);

    f1.setValue(QVariant(id));
    f2.setValue(QVariant(title));
    f3.setValue(QVariant(artistId));
    f4.setValue(QVariant(yearEditor->value()));
    record.append(f1);
    record.append(f2);
    record.append(f3);
    record.append(f4);

    model->insertRecord(-1, record);//向"专辑"表中插入此专辑
    return id;
}

//专辑id、歌名存入DOM树形文件(专辑id,歌名)
void Dialog::addTracks(int albumId, QStringList tracks)
{
    //创建结点<album></album>
    QDomElement albumNode = albumDetails.createElement("album");
    albumNode.setAttribute("id", albumId);//<album id="专辑id"></album>

    for (int i = 0; i < tracks.count(); i++)
    {
        QString trackNumber = QString::number(i);//数字转字符
        if (i < 10)
        {
            trackNumber.prepend("0");// 1->01
        }

        //歌名作为该结点的文本
        QDomText textNode = albumDetails.createTextNode(tracks.at(i));

        //创建结点<track></track>
        QDomElement trackNode = albumDetails.createElement("track");
        trackNode.setAttribute("number", trackNumber);
        trackNode.appendChild(textNode);
        //<track number="01">歌名</track>

        albumNode.appendChild(trackNode);
        /*
        <album id="专辑id">
          <track number="01">歌名</track>
        </album>
        */
    }

    //创建结点<archive></archive>
    QDomNodeList archive = albumDetails.elementsByTagName("archive");
    archive.item(0).appendChild(albumNode);
    /*
    <archive>
        <album id="专辑id">
          <track number="01">歌名</track>
        </album>
    </archive>
    */

    //下面这几句可以注释掉  将创建的结点存入XML文件
    if (!outputFile->open(QIODevice::WriteOnly))
    {
        return;
    }
    else
    {
        QTextStream stream(outputFile);
        archive.item(0).save(stream, 4);//将创建的结点存入XML文件
        outputFile->close();
    }
}

//更新艺术家的专辑数量
void Dialog::increaseAlbumCount(QModelIndex artistIndex)
{
    //"专辑"表的第3列所关联的外键列所在的表，即"艺术家表"  此模型数据来自此表
    QSqlTableModel *artistModel = model->relationModel(2);

    QModelIndex albumCountIndex;
    albumCountIndex = artistIndex.sibling(artistIndex.row(), 2);

    int albumCount = albumCountIndex.data().toInt();
    artistModel->setData(albumCountIndex, QVariant(albumCount + 1));
}

void Dialog::revert()
{
    artistEditor->clear();
    titleEditor->clear();
    yearEditor->setValue(QDate::currentDate().year());
    tracksEditor->clear();
}

QGroupBox *Dialog::createInputWidgets()
{
    QGroupBox *box = new QGroupBox(tr("新增专辑"));

    QLabel *artistLabel = new QLabel(tr("艺术家："));
    QLabel *titleLabel = new QLabel(tr("专辑标题："));
    QLabel *yearLabel = new QLabel(tr("年份："));
    QLabel *tracksLabel = new QLabel(tr("专辑中的歌名（用逗号隔开）："));

    artistEditor = new QLineEdit;
    titleEditor = new QLineEdit;

    yearEditor = new QSpinBox;
    yearEditor->setMinimum(1900);
    yearEditor->setMaximum(QDate::currentDate().year());//当前年份
    yearEditor->setValue(yearEditor->maximum());
    yearEditor->setReadOnly(false);

    tracksEditor = new QLineEdit;

    QGridLayout *layout = new QGridLayout;
    layout->addWidget(artistLabel, 0, 0);
    layout->addWidget(artistEditor, 0, 1);
    layout->addWidget(titleLabel, 1, 0);
    layout->addWidget(titleEditor, 1, 1);
    layout->addWidget(yearLabel, 2, 0);
    layout->addWidget(yearEditor, 2, 1);
    layout->addWidget(tracksLabel, 3, 0, 1, 2);
    layout->addWidget(tracksEditor, 4, 0, 1, 2);
    box->setLayout(layout);

    return box;
}

QDialogButtonBox *Dialog::createButtons()
{
    QPushButton *closeButton = new QPushButton(tr("关闭"));
    QPushButton *revertButton = new QPushButton(tr("重新输入"));
    QPushButton *submitButton = new QPushButton(tr("提交"));

    closeButton->setDefault(true);

    connect(closeButton, SIGNAL(clicked()), this, SLOT(close()));
    connect(revertButton, SIGNAL(clicked()), this, SLOT(revert()));
    connect(submitButton, SIGNAL(clicked()), this, SLOT(submit()));

    QDialogButtonBox *buttonBox = new QDialogButtonBox;
    buttonBox->addButton(submitButton, QDialogButtonBox::ResetRole);
    buttonBox->addButton(revertButton, QDialogButtonBox::ResetRole);
    buttonBox->addButton(closeButton, QDialogButtonBox::RejectRole);

    return buttonBox;
}

//根据名字查找此艺术家在"艺术家"表中的位置
QModelIndex Dialog::indexOfArtist(const QString &artist)
{
    //"专辑"表的第3列所关联的外键列所在的表，即"艺术家表"  此模型数据来自此表
    QSqlTableModel *artistModel = model->relationModel(2);

    for (int i = 0; i < artistModel->rowCount(); i++)
    {
        QSqlRecord record =  artistModel->record(i);//一行
        if (record.value("artist") == artist)
        {
            return artistModel->index(i, 1);
        }
    }

    return QModelIndex();
}

int Dialog::generateArtistId()
{
    uniqueArtistId += 1;
    return uniqueArtistId;
}

int Dialog::generateAlbumId()
{
    uniqueAlbumId += 1;
    return uniqueAlbumId;
}
