#include <QApplication>
#include <QtCore>
#include <stdlib.h>
#include "server.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    Server server;
    server.show();

    //随机种子初始化 如果程序没有这句的话，那么每次运行都会产生相同的随机数
    //使用它要#include <stdlib.h>
    qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));

    return app.exec();
}
