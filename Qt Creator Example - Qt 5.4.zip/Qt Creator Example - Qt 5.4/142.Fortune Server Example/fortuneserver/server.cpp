#include <QtWidgets>
#include <QtNetwork>
#include <stdlib.h>
#include "server.h"
#include <QDebug>

Server::Server(QWidget *parent)
:   QDialog(parent), tcpServer(0), networkSession(0)
{
    statusLabel = new QLabel;
    statusLabel->adjustSize();
    statusLabel->setWordWrap(true);
    statusLabel->setAlignment(Qt::AlignTop);


    quitButton = new QPushButton(tr("关闭"));
    //设置按钮是否为自动默认按钮   对话框中同一时刻只能有一个默认按钮，当用户按回车键时，等价于在对话框中单击这个按钮。
    quitButton->setAutoDefault(false);

    QNetworkConfigurationManager manager;//QNetworkConfigurationManager 创建设备网络配置信息对象

    //QNetworkConfigurationManager::NetworkSessionRequired如果设置了该标志，则平台需要在执行网络操作之前创建网络会话。
    //capabilities()返回当前平台支持的功能。
    if (manager.capabilities() & QNetworkConfigurationManager::NetworkSessionRequired)//检测平台是否具有网络通讯能力
    {
        //获取保存的网络配置
        QSettings settings(QSettings::UserScope, QLatin1String("QtProject"));
        settings.beginGroup(QLatin1String("QtNetwork"));
        const QString id = settings.value(QLatin1String("DefaultNetworkConfiguration")).toString();
        settings.endGroup();

        // 如果当前未发现保存的网络配置，请使用系统默认值
        //会话配置参数是通过QNetworkConfiguration对象决定的
        QNetworkConfiguration config = manager.configurationFromIdentifier(id);
        if ((config.state() & QNetworkConfiguration::Discovered) != QNetworkConfiguration::Discovered)
        {
            config = manager.defaultConfiguration();
        }

        //会话是指一个终端用户与交互系统进行通讯的过程
        networkSession = new QNetworkSession(config, this);//使用该网络配置创建一个网络会话 用于和客户端通信
        connect(networkSession, SIGNAL(opened()), this, SLOT(sessionOpened()));

        statusLabel->setText(tr("正在打开网络会话"));
        networkSession->open();
        qDebug()<<"one";

    }
    else
    {
        sessionOpened();
        qDebug()<<"two";

    }

//    fortunes << tr("我读的书愈多，就愈亲近世界，愈明了生活的意义，愈觉得生活的重要")
//             << tr("笨蛋自以为聪明，聪明人才知道自己是笨蛋")
//             << tr("谁不会休息，谁就不会工作")
//             << tr("真的猛士，敢于直面惨淡的人生，敢于正视淋漓的鲜血")
//             << tr("如果你被置于某种地位的时间足够长久，你的行为就会开始适应那种地位的要求")
//             << tr("生活是恼人的牢笼。一个有思想的人到成年时期，对生活有了成熟的感觉，他就不能不感到他关在一个无从脱逃的牢笼里面")
//             << tr("睡眠和休息丧失了时间，却取得了明天工作的精力");

    fortunes << tr("")
             <<tr("")<<tr("")<<tr("")<<tr("")<<tr("");


    connect(quitButton, SIGNAL(clicked()), this, SLOT(close()));

    //当有新的客户端连接时 发射newConnection()信号
    connect(tcpServer, SIGNAL(newConnection()), this, SLOT(sendFortune()));

    QHBoxLayout *buttonLayout = new QHBoxLayout;
    buttonLayout->addStretch(1);
    buttonLayout->addWidget(quitButton);
    buttonLayout->addStretch(1);

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout->addWidget(statusLabel);
    mainLayout->addLayout(buttonLayout);
    setLayout(mainLayout);

    setWindowTitle(tr("服务端"));
}

//打开网络会话
void Server::sessionOpened()
{
    // 保存使用的配置
    if (networkSession)//网络会话已存在
    {
        QNetworkConfiguration config = networkSession->configuration();//获取网络会话的配置
        QString id;
        if (config.type() == QNetworkConfiguration::UserChoice)
        {
            id = networkSession->sessionProperty(QLatin1String("UserChoiceConfiguration")).toString();
        }
        else
        {
            id = config.identifier();
        }

        QSettings settings(QSettings::UserScope, QLatin1String("QtProject"));
        settings.beginGroup(QLatin1String("QtNetwork"));
        settings.setValue(QLatin1String("DefaultNetworkConfiguration"), id);
        settings.endGroup();
    }

    tcpServer = new QTcpServer(this);//新建tcp服务器
    if (!tcpServer->listen())//开始监听 这个监听是基于所有地址，任意端口的
    {
        QMessageBox::critical(this, tr("服务器提示"),
                              tr("无法启动服务: %1.").arg(tcpServer->errorString()));
        close();
        return;
    }

    QString ipAddress;
    QList<QHostAddress> ipAddressesList = QNetworkInterface::allAddresses();//返回所有主机能够监听到的IPv4的地址

    //取出第一个非主机地址的IPv4地址
    for (int i = 0; i < ipAddressesList.size(); ++i)
    {
        if (ipAddressesList.at(i) != QHostAddress::LocalHost && ipAddressesList.at(i).toIPv4Address())
        {
            ipAddress = ipAddressesList.at(i).toString();
            break;
        }
    }
    //如果没有发现则使用主机的IPv4地址
    if (ipAddress.isEmpty())
    {
        ipAddress = QHostAddress(QHostAddress::LocalHost).toString();
    }
    statusLabel->setText(tr("服务器正在运行\nIP地址：%1\n端口号：%2\n"
                            "现在可打开客户端").arg(ipAddress).arg(tcpServer->serverPort()));
}

//将信息发到客户端 《qt creator编程入门》 P434有详解
void Server::sendFortune()
{
    QByteArray block;
    QDataStream out(&block, QIODevice::WriteOnly);//QDataSteam作为二进制输入输出流，使用QTcpSocket传输数据的常用方法
    out.setVersion(QDataStream::Qt_5_4);
    out << (quint16)0;
    out << fortunes.at(qrand() % fortunes.size());//从QStringList中随机取一条
    out.device()->seek(0);
    out << (quint16)(block.size() - sizeof(quint16));

    QTcpSocket *clientConnection = tcpServer->nextPendingConnection();
    connect(clientConnection, SIGNAL(disconnected()),
            clientConnection, SLOT(deleteLater()));

    clientConnection->write(block);
    clientConnection->disconnectFromHost();
}
