#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),tcpServer(0), networkSession(0),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    setWindowTitle("服务端");

    QFont ft;
    ft.setPointSize(12);
    ui->label->setFont(ft);//设置标签字体大小
    ui->label_2->setFont(ft);

    QNetworkConfigurationManager manager;//QNetworkConfigurationManager 创建设备网络配置信息对象

    //QNetworkConfigurationManager::NetworkSessionRequired如果设置了该标志，则平台需要在执行网络操作之前创建网络会话。
    //capabilities()返回当前平台支持的功能。
    if (manager.capabilities() & QNetworkConfigurationManager::NetworkSessionRequired)//检测平台是否具有网络通讯能力
    {
        //获取保存的网络配置
        QSettings settings(QSettings::UserScope, QLatin1String("QtProject"));
        settings.beginGroup(QLatin1String("QtNetwork"));
        const QString id = settings.value(QLatin1String("DefaultNetworkConfiguration")).toString();
        settings.endGroup();

        //如果当前未发现保存的网络配置，请使用系统默认值
        //会话配置参数是通过QNetworkConfiguration对象决定的
        QNetworkConfiguration config = manager.configurationFromIdentifier(id);
        if ((config.state() & QNetworkConfiguration::Discovered) != QNetworkConfiguration::Discovered)
        {
            config = manager.defaultConfiguration();
        }

        //会话是指一个终端用户与交互系统进行通讯的过程
        networkSession = new QNetworkSession(config, this);//使用该网络配置创建一个网络会话 用于和客户端通信
        connect(networkSession, SIGNAL(opened()), this, SLOT(sessionOpened()));

        ui->label->setText(tr("正在打开网络会话"));
        networkSession->open();
    }
    else
    {
        sessionOpened();
    }

    //当有新的客户端连接时 发射newConnection()信号
    connect(tcpServer, SIGNAL(newConnection()), this, SLOT(sendFortune()));
}

Widget::~Widget()
{
    delete ui;
}

//打开网络会话
void Widget::sessionOpened()
{
    // 保存使用的配置
    if (networkSession)//网络会话已存在
    {
        QNetworkConfiguration config = networkSession->configuration();//获取网络会话的配置
        QString id;
        if (config.type() == QNetworkConfiguration::UserChoice)
        {
            id = networkSession->sessionProperty(QLatin1String("UserChoiceConfiguration")).toString();
        }
        else
        {
            id = config.identifier();
        }

        QSettings settings(QSettings::UserScope, QLatin1String("QtProject"));
        settings.beginGroup(QLatin1String("QtNetwork"));
        settings.setValue(QLatin1String("DefaultNetworkConfiguration"), id);
        settings.endGroup();
    }

    tcpServer = new QTcpServer(this);//新建tcp服务器
    if (!tcpServer->listen())//开始监听 这个监听是基于所有地址，任意端口的
    {
        QMessageBox::critical(this, tr("服务端提示"),
                              tr("无法启动服务: %1.").arg(tcpServer->errorString()));
        close();
        return;
    }

    QString ipAddress;
    QList<QHostAddress> ipAddressesList = QNetworkInterface::allAddresses();//返回所有主机能够监听到的IPv4的地址

    //取出第一个非主机地址的IPv4地址
    for (int i = 0; i < ipAddressesList.size(); ++i)
    {
        if (ipAddressesList.at(i) != QHostAddress::LocalHost && ipAddressesList.at(i).toIPv4Address())
        {
            ipAddress = ipAddressesList.at(i).toString();
            break;
        }
    }
    //如果没有发现则使用主机的IPv4地址
    if (ipAddress.isEmpty())
    {
        ipAddress = QHostAddress(QHostAddress::LocalHost).toString();
    }
    ui->label->setText(tr("服务端正在运行\nIP地址：%1\n端口号：%2\n"
                          "现在可打开客户端").arg(ipAddress).arg(tcpServer->serverPort()));
}

//将信息发到客户端 《qt creator编程入门》 P434有详解
void Widget::sendFortune()
{
    QByteArray block;
    QDataStream out(&block, QIODevice::WriteOnly);//QDataSteam作为二进制输入输出流，使用QTcpSocket传输数据的常用方法
    out.setVersion(QDataStream::Qt_5_4);
    out << (quint16)0;
    out << message_info;
    out.device()->seek(0);
    out << (quint16)(block.size() - sizeof(quint16));

    QTcpSocket *clientConnection = tcpServer->nextPendingConnection();
    connect(clientConnection, SIGNAL(disconnected()),
            clientConnection, SLOT(deleteLater()));

    clientConnection->write(block);
    clientConnection->disconnectFromHost();
}

void Widget::on_pushButton_clicked()
{
    QString str_message = ui->textEdit->toPlainText();
    if(str_message.isEmpty())
    {
        QMessageBox::information(this,tr("提示"),tr("请输入要发送的内容"));
        return;
    }
    message_info = str_message;
    ui->textEdit->clear();
}
