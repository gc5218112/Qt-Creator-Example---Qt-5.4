#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QLabel>
#include <QPushButton>
#include <QTcpServer>
#include <QPushButton>
#include <QNetworkSession>
#include <QDebug>
#include <QSettings>
#include <QtWidgets>
#include <QtNetwork>
#include <QMessageBox>

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

private slots:
    void sessionOpened();
    void sendFortune();

    void on_pushButton_clicked();

private:
    QTcpServer *tcpServer;//提供了一个基于TCP的服务
    QString message_info;
    QNetworkSession *networkSession;//提供系统网络接口控制

private:
    Ui::Widget *ui;
};

#endif // WIDGET_H
