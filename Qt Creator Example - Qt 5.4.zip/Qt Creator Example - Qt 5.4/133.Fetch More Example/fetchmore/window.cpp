#include "filelistmodel.h"
#include "window.h"
#include <QtWidgets>
#include <QDebug>

Window::Window(QWidget *parent)
    : QWidget(parent)
{
    FileListModel *model = new FileListModel(this);
    model->setDirPath("d:/");

    QLabel *label = new QLabel(tr("目录："));
    QLineEdit *lineEdit = new QLineEdit;
    label->setBuddy(lineEdit);
    lineEdit->setText("d:/");

    QListView *view = new QListView;
    view->setModel(model);

    logViewer = new QTextBrowser;//富文本浏览器
    logViewer->setSizePolicy(QSizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred));

    connect(lineEdit, SIGNAL(textChanged(QString)), model, SLOT(setDirPath(QString)));
    connect(lineEdit, SIGNAL(textChanged(QString)), logViewer, SLOT(clear()));
    connect(model, SIGNAL(numberPopulated(int)), this, SLOT(updateLog(int)));

    QGridLayout *layout = new QGridLayout;
    layout->addWidget(label, 0, 0);
    layout->addWidget(lineEdit, 0, 1);
    layout->addWidget(view, 1, 0, 1, 2);
    layout->addWidget(logViewer, 2, 0, 1, 2);

    setLayout(layout);
    setWindowTitle(tr("文件目录匹配"));
}

void Window::updateLog(int number)
{
    logViewer->append(tr("此目录有%1项文件/文件夹").arg(number));
}
