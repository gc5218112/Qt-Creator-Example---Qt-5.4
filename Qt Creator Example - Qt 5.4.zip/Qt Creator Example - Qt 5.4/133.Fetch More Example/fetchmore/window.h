#ifndef WINDOW_H
#define WINDOW_H

#include <QWidget>

QT_BEGIN_NAMESPACE
class QTextBrowser;
QT_END_NAMESPACE

class Window : public QWidget
{
    Q_OBJECT

public:
    Window(QWidget *parent = 0);

public slots:
    void updateLog(int number);

private:
    QTextBrowser *logViewer;
};

#endif // WINDOW_H
