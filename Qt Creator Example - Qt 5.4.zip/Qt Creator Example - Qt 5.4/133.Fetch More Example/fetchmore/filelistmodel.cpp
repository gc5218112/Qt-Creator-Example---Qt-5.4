#include "filelistmodel.h"
#include <QApplication>
#include <QBrush>
#include <QDir>
#include <QPalette>
#include <QDebug>

FileListModel::FileListModel(QObject *parent)
    : QAbstractListModel(parent)
{
}

int FileListModel::rowCount(const QModelIndex & /* parent */) const
{
    return fileCount;
}

//模型中的数据
QVariant FileListModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid())
    {
        return QVariant();
    }

    if (index.row() >= fileList.size() || index.row() < 0)
    {
        return QVariant();
    }

    if (role == Qt::DisplayRole)//数据用于视图的文本显示
    {
        //qDebug()<<fileList.at(index.row());//该目录的文件名
        return fileList.at(index.row());//该index模型项中的数据是此文件名
    }
    else if (role == Qt::BackgroundRole)
    {
        int batch = (index.row() / 100) % 2;
        if (batch == 0)
        {
            return qApp->palette().base();
        }
        else
        {
            return qApp->palette().alternateBase();
        }
    }
    return QVariant();
}

//canFetchMore返回true则调用fetchMore()
bool FileListModel::canFetchMore(const QModelIndex & /* index */) const
{
    if (fileCount < fileList.size())//即当该目录中文件列表不为空时执行fetchMore()向模型中插入行
    {
        return true;
    }
    else
    {
        return false;
    }
}

void FileListModel::fetchMore(const QModelIndex & /* index */)
{
    int remainder = fileList.size() - fileCount;
    int itemsToFetch = qMin(100, remainder);

    //开始插入行 插入从第0行到第itemsToFetch - 1行
    beginInsertRows(QModelIndex(), fileCount, fileCount + itemsToFetch - 1);

    fileCount += itemsToFetch;

    qDebug()<<remainder<<itemsToFetch<<fileCount;//三个都是目录中文件的数目

    endInsertRows();

    emit numberPopulated(itemsToFetch);//已插入行完毕
}

//设置目录
void FileListModel::setDirPath(const QString &path)
{
    QDir dir(path);

    beginResetModel();//开始重新设置模型中的数据
    fileList = dir.entryList();//目录中文件名列表
    fileCount = 0;
    endResetModel();//结束重新设置模型中的数据
}
