#include <QApplication>
#include <QMenu>
#include <QPixmap>
#include <QWidget>
#include <qmacfunctions.h>

int main(int argc, char **argv)
{
    QApplication app(argc, argv);

    QWidget widget;
    widget.show();

    // Pixmap <-> CGImage conversion
    QPixmap pixmap(":qtlogo.png");
    CGImageRef cgImage = QtMac::toCGImageRef(pixmap);
    QPixmap pixmap2 = QtMac::fromCGImageRef(cgImage);

    return app.exec();
}
