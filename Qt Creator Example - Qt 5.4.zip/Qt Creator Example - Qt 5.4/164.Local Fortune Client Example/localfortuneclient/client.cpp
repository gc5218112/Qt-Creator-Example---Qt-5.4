#include <QtWidgets>
#include <QtNetwork>
#include "client.h"

Client::Client(QWidget *parent)
    : QDialog(parent)
{
    hostLabel = new QLabel(tr("连接名称："));
    hostLineEdit = new QLineEdit("Fortune");

    hostLabel->setBuddy(hostLineEdit);

    statusLabel = new QLabel(tr("您需要运行服务端"));
    statusLabel->setWordWrap(true);

    getFortuneButton = new QPushButton(tr("获取服务端消息"));
    getFortuneButton->setDefault(true);

    quitButton = new QPushButton(tr("退出"));

    buttonBox = new QDialogButtonBox;
    buttonBox->addButton(getFortuneButton, QDialogButtonBox::ActionRole);
    buttonBox->addButton(quitButton, QDialogButtonBox::RejectRole);

    socket = new QLocalSocket(this);//用于本地网络通信的套接字

    connect(hostLineEdit, SIGNAL(textChanged(QString)), this, SLOT(enableGetFortuneButton()));
    connect(getFortuneButton, SIGNAL(clicked()), this, SLOT(requestNewFortune()));
    connect(quitButton, SIGNAL(clicked()), this, SLOT(close()));
    //读取通信对象发过来的消息
    connect(socket, SIGNAL(readyRead()), this, SLOT(readFortune()));
    connect(socket, SIGNAL(error(QLocalSocket::LocalSocketError)), this, SLOT(displayError(QLocalSocket::LocalSocketError)));

    QGridLayout *mainLayout = new QGridLayout;
    mainLayout->addWidget(hostLabel, 0, 0);
    mainLayout->addWidget(hostLineEdit, 0, 1);
    mainLayout->addWidget(statusLabel, 2, 0, 1, 2);
    mainLayout->addWidget(buttonBox, 3, 0, 1, 2);
    setLayout(mainLayout);

    setWindowTitle(tr("本地客户端"));
    hostLineEdit->setFocus();
}

//获取服务端消息
void Client::requestNewFortune()
{
    getFortuneButton->setEnabled(false);
    blockSize = 0;
    socket->abort();//断开当前的连接并重设套接字
    socket->connectToServer(hostLineEdit->text());//连接服务端（按输入的连接名称）
}

//读取服务端发过来的消息
void Client::readFortune()
{
    QDataStream in(socket);
    in.setVersion(QDataStream::Qt_5_4);

    if (blockSize == 0)
    {
        if (socket->bytesAvailable() < (int)sizeof(quint16))
        {
            return;
        }
        in >> blockSize;
    }

    if (in.atEnd())
    {
        return;
    }

    QString nextFortune;
    in >> nextFortune;

    if (nextFortune == currentFortune)//本次接收到的内容和上一次相同
    {
        //只执行一次的定时器 再获取一次服务器消息
        QTimer::singleShot(0, this, SLOT(requestNewFortune()));
        return;
    }

    currentFortune = nextFortune;
    statusLabel->setText(currentFortune);
    getFortuneButton->setEnabled(true);
}

void Client::displayError(QLocalSocket::LocalSocketError socketError)
{
    switch (socketError)
    {
        case QLocalSocket::ServerNotFoundError:
            QMessageBox::information(this, tr("本地客户端"), tr("连接错误，请检查连接名称"));
            break;
        case QLocalSocket::ConnectionRefusedError:
            QMessageBox::information(this, tr("本地客户端"), tr("连接被拒绝，确保服务端正在运行"));
            break;
        case QLocalSocket::PeerClosedError:
            break;
        default:
            QMessageBox::information(this, tr("本地客户端"),tr("发生以下错误: %1.").arg(socket->errorString()));
    }

    getFortuneButton->setEnabled(true);
}

void Client::enableGetFortuneButton()
{
    getFortuneButton->setEnabled(!hostLineEdit->text().isEmpty());
}
