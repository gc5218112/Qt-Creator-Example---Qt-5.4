#include <QtWidgets>
#ifndef QT_NO_PRINTER
#include <QPrinter>
#include <QPrintDialog>
#endif

#include "detailsdialog.h"
#include "mainwindow.h"

MainWindow::MainWindow()
{
    QMenu *fileMenu = new QMenu(tr("文件"), this);

    QAction *newAction = fileMenu->addAction(tr("新建"));
    newAction->setShortcuts(QKeySequence::New);

    printAction = fileMenu->addAction(tr("打印"), this, SLOT(printFile()));
    printAction->setShortcuts(QKeySequence::Print);
    printAction->setEnabled(false);

    QAction *quitAction = fileMenu->addAction(tr("退出"));
    quitAction->setShortcuts(QKeySequence::Quit);
    menuBar()->addMenu(fileMenu);

    letters = new QTabWidget;

    connect(newAction, SIGNAL(triggered()), this, SLOT(openDialog()));
    connect(quitAction, SIGNAL(triggered()), this, SLOT(close()));

    setCentralWidget(letters);
    setWindowTitle(tr("订单样式"));
}

//从新建对话框输入的消息创建订单
void MainWindow::createLetter(const QString &name, //名字
                              const QString &address,//地址
                              QList<QPair<QString,int> > orderItems,//键值对：产品名称,数量
                              bool sendOffers)//是否选中了"发送有关产品和特殊优惠的信息"
{
    QTextEdit *editor = new QTextEdit;//纯文本编辑框
    int tabIndex = letters->addTab(editor, name);//创建一页新的标签页
    letters->setCurrentIndex(tabIndex);//当前页为新创建的该页

    QTextCursor cursor(editor->textCursor());//编辑框的光标
    cursor.movePosition(QTextCursor::Start);//移到编辑框的开始位置

    QTextFrame *topFrame = cursor.currentFrame();//光标处的文本框架
    QTextFrameFormat topFrameFormat = topFrame->frameFormat();//文本框架格式
    topFrameFormat.setPadding(16);//框架内部的内容相对边缘的边距
    topFrame->setFrameFormat(topFrameFormat);

    QTextCharFormat textFormat;//文本格式
    QTextCharFormat boldFormat;
    boldFormat.setFontWeight(QFont::Bold);//设置加粗

    QTextFrameFormat referenceFrameFormat;//文本框架格式
    referenceFrameFormat.setBorder(1);//文本框架宽度
    referenceFrameFormat.setPadding(8);//框架内部的内容相对边缘的边距
    referenceFrameFormat.setPosition(QTextFrameFormat::FloatRight);//靠右
    referenceFrameFormat.setWidth(QTextLength(QTextLength::PercentageLength, 40));//宽度
    cursor.insertFrame(referenceFrameFormat);//在光标处创建一个文本框架，里面的内容是文本

    cursor.insertText("本公司地址：", boldFormat);
    cursor.insertBlock();
    cursor.insertText("  阿里巴巴公司");
    cursor.insertBlock();
    cursor.insertText("  321 城市大街");
    cursor.insertBlock();
    cursor.insertText("  中央公园");
    cursor.insertBlock();
    cursor.insertText("  斐济共和国");

    cursor.setPosition(topFrame->lastPosition());//光标跳出框架，回到之前的位置

    cursor.insertText("姓名：" + name, textFormat);
    cursor.insertBlock();//换行
    cursor.insertText("地址：", textFormat);

    QString line;
    foreach (line, address.split("\n"))
    {
        cursor.insertBlock();
        cursor.insertText(line);
    }
    cursor.insertBlock();
    cursor.insertBlock();

    QDate date = QDate::currentDate();
    cursor.insertText(tr("日期：%1").arg(date.toString("d MMMM yyyy")), textFormat);
    cursor.insertBlock();

    QTextFrameFormat bodyFrameFormat;//文本框架格式
    bodyFrameFormat.setWidth(QTextLength(QTextLength::PercentageLength, 100));
    cursor.insertFrame(bodyFrameFormat);

    cursor.insertText(tr("我想订购下列商品："), textFormat);
    cursor.insertBlock();
    cursor.insertBlock();

    QTextTableFormat orderTableFormat;//表格格式
    orderTableFormat.setAlignment(Qt::AlignHCenter | Qt::AlignVCenter);//居中
    QTextTable *orderTable = cursor.insertTable(1, 2, orderTableFormat);//1行2列

    QTextFrameFormat orderFrameFormat = cursor.currentFrame()->frameFormat();//文本框架格式
    orderFrameFormat.setBorder(1);
    cursor.currentFrame()->setFrameFormat(orderFrameFormat);

    cursor = orderTable->cellAt(0, 0).firstCursorPosition();
    cursor.insertText(tr("产品"), boldFormat);
    cursor = orderTable->cellAt(0, 1).firstCursorPosition();
    cursor.insertText(tr("数量"), boldFormat);

    for (int i = 0; i < orderItems.count(); ++i)
    {
        QPair<QString,int> item = orderItems[i];
        int row = orderTable->rows();

        orderTable->insertRows(row, 1);
        cursor = orderTable->cellAt(row, 0).firstCursorPosition();
        cursor.insertText(item.first, textFormat);
        cursor = orderTable->cellAt(row, 1).firstCursorPosition();
        cursor.insertText(QString("%1").arg(item.second), textFormat);
    }

    cursor.setPosition(topFrame->lastPosition());

    cursor.insertBlock();
    cursor.insertText(tr("请更新我的记录，考虑以下隐私信息:"));
    cursor.insertBlock();

    QTextTable *offersTable = cursor.insertTable(2, 2);

    cursor = offersTable->cellAt(0, 1).firstCursorPosition();
    cursor.insertText(tr("我想得到更多关于贵公司产品和特价的信息"), textFormat);
    cursor = offersTable->cellAt(1, 1).firstCursorPosition();
    cursor.insertText(tr("我不想收到贵公司的任何促销信息"), textFormat);

    if (sendOffers)
    {
        cursor = offersTable->cellAt(0, 0).firstCursorPosition();
    }
    else
    {
        cursor = offersTable->cellAt(1, 0).firstCursorPosition();
    }

    cursor.insertText("X", boldFormat);

    cursor.setPosition(topFrame->lastPosition());
    cursor.insertBlock();
    cursor.insertText(tr("致以诚挚的问候"), textFormat);
    cursor.insertBlock();
    cursor.insertBlock();
    cursor.insertBlock();
    cursor.insertText(name);

    printAction->setEnabled(true);
}

void MainWindow::createSample()
{
    DetailsDialog dialog("默认值对话框", this);
    createLetter("Mr. Smith", "12 High Street\nSmall Town\nThis country",
                 dialog.orderItems(), true);
}

void MainWindow::openDialog()
{
    DetailsDialog dialog(tr("输入客户详细信息"), this);

    if (dialog.exec() == QDialog::Accepted)//如果按下了确定按钮
    {
        createLetter(dialog.senderName(), dialog.senderAddress(),
                     dialog.orderItems(), dialog.sendOffers());
    }
}

void MainWindow::printFile()
{
#if !defined(QT_NO_PRINTER) && !defined(QT_NO_PRINTDIALOG)
    QTextEdit *editor = static_cast<QTextEdit*>(letters->currentWidget());//打印当前页面
    QPrinter printer;

    QPrintDialog dialog(&printer, this);
    dialog.setWindowTitle(tr("打印文档"));
    if (editor->textCursor().hasSelection())
    {
        dialog.addEnabledOption(QAbstractPrintDialog::PrintSelection);
    }
    if (dialog.exec() != QDialog::Accepted)
    {
        return;
    }

    editor->print(&printer);
#endif
}
