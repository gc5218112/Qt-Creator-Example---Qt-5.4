#ifndef ANIMATION_H
#define ANIMATION_H

#include <QtWidgets>
#include <QtCore/qpropertyanimation.h>

//自定义动画类
class Animation : public QPropertyAnimation
{
public:
    enum PathType //动画路径类型
    {
        LinearPath, //直线
        CirclePath, //圆
        NPathTypes //无
    };
    Animation(QObject *target, const QByteArray &prop)
        : QPropertyAnimation(target, prop)
    {
        setPathType(LinearPath);//默认是直线
    }

    void setPathType(PathType pathType)
    {
        if (pathType >= NPathTypes)
        {
            qWarning("未知的路径类型 %d", pathType);
        }

        m_pathType = pathType;
        m_path = QPainterPath();
    }

    void updateCurrentTime(int currentTime) Q_DECL_OVERRIDE
    {
        if (m_pathType == CirclePath)//圆
        {
            if (m_path.isEmpty())
            {
                QPointF to = endValue().toPointF();//动画结束位置
                QPointF from = startValue().toPointF();//动画开始位置
                m_path.moveTo(from);
                m_path.addEllipse(QRectF(from, to));//在两个位置之间画椭圆
            }
            int dura = duration();//动画持续时间

            const qreal progress = ((dura == 0) ? 1 : ((((currentTime - 1) % dura) + 1) / qreal(dura)));

            qreal easedProgress = easingCurve().valueForProgress(progress);
            if (easedProgress > 1.0)
            {
                easedProgress -= 1.0;
            }
            else if (easedProgress < 0)
            {
                easedProgress += 1.0;
            }
            QPointF pt = m_path.pointAtPercent(easedProgress);
            updateCurrentValue(pt);
            emit valueChanged(pt);
        }
        else
        {
            QPropertyAnimation::updateCurrentTime(currentTime);
        }
    }

    QPainterPath m_path;//绘制复杂路径的对象
    PathType m_pathType;
};

#endif // ANIMATION_H
