#include <QImage>
#include <QList>
#include <QThread>
#include <QDebug>
#include <QGuiApplication>
#include <qtconcurrentmap.h>

QImage scale(const QImage &image)
{
    qDebug() <<QThread::currentThread();
    return image.scaled(QSize(100, 100), Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
}

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    const int imageCount = 20;

    QList<QImage> images;
    for (int i = 0; i < imageCount; ++i)
    {
        images.append(QImage(1600, 1200, QImage::Format_ARGB32_Premultiplied));
    }

    QList<QImage> thumbnails = QtConcurrent::blockingMapped<QList<QImage> >(images, scale);

    return 0;
}
