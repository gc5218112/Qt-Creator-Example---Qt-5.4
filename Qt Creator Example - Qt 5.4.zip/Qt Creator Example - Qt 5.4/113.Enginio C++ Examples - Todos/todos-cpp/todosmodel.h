#ifndef TODOSMODEL_H
#define TODOSMODEL_H

#include <Enginio/enginiomodel.h>

class TodosModel : public EnginioModel
{
    Q_OBJECT

public:
    enum Role
    {
        TitleRole = Enginio::CustomPropertyRole,
        CompletedRole
    };

    explicit TodosModel(QObject *parent = 0);
    virtual QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const Q_DECL_OVERRIDE;
    virtual QVariant headerData(int section, Qt::Orientation orientation, int role) const Q_DECL_OVERRIDE;

    virtual QHash<int, QByteArray> roleNames() const Q_DECL_OVERRIDE;
};

#endif // TODOSMODEL_H
