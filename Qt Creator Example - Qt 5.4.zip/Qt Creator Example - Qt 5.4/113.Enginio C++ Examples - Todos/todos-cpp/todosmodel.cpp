#include "todosmodel.h"
#include <QtCore/qjsonvalue.h>
#include <QtCore/qjsonobject.h>
#include <QtGui/qcolor.h>
#include <QtGui/qfont.h>
#include <Enginio/enginioreply.h>

TodosModel::TodosModel(QObject *parent)
    : EnginioModel(parent)
{}

QVariant TodosModel::headerData(int section, Qt::Orientation orientation, int role) const
{
    if (orientation == Qt::Horizontal && section == 0 && role == Qt::DisplayRole)
        return QStringLiteral("Todo List");
    return EnginioModel::headerData(section, orientation, role);
}

QVariant TodosModel::data(const QModelIndex &index, int role) const
{
    if (role == Qt::FontRole)
    {
        bool completed = EnginioModel::data(index, CompletedRole).value<QJsonValue>().toBool();
        QFont font;
        font.setPointSize(20);
        font.setStrikeOut(completed);
        return font;
    }

    if (role == Qt::TextColorRole)
    {
        bool completed = EnginioModel::data(index, CompletedRole).value<QJsonValue>().toBool();
        return completed ? QColor("#999") : QColor("#333");
    }

    if (role == CompletedRole)
        return EnginioModel::data(index, CompletedRole).value<QJsonValue>().toBool();

    // fallback to base class
    return EnginioModel::data(index, role);
}

QHash<int, QByteArray> TodosModel::roleNames() const
{
    QHash<int, QByteArray> roles = EnginioModel::roleNames();
    roles.insert(TitleRole, "title");
    roles.insert(Qt::DisplayRole, "title");
    roles.insert(Qt::EditRole, "title");
    roles.insert(CompletedRole, "completed");
    return roles;
}
