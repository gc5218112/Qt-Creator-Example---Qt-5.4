#include <QtWidgets>
#include <QPrinter>
#include <QPrintDialog>
#include "licensewizard.h"

LicenseWizard::LicenseWizard(QWidget *parent)
    : QWizard(parent)
{
    //       向导页的ID      向导页
    setPage(Page_Intro, new IntroPage);
    setPage(Page_Evaluate, new EvaluatePage);
    setPage(Page_Register, new RegisterPage);
    setPage(Page_Details, new DetailsPage);
    setPage(Page_Conclusion, new ConclusionPage);

    setStartId(Page_Intro);//向导从此向导页开始

#ifndef Q_OS_MAC

    setWizardStyle(ModernStyle);
#endif

    setOption(HaveHelpButton, true);//为此向导添加帮助按钮

    //设置图标 每个向导页都会显示的
    setPixmap(QWizard::LogoPixmap, QPixmap(":/images/logo.png"));

    //每页点击帮助按钮时候弹出的帮助信息不同
    connect(this, SIGNAL(helpRequested()), this, SLOT(showHelp()));

    setWindowTitle(tr("许可向导"));
}

void LicenseWizard::showHelp()
{
    static QString lastHelpMessage;

    QString message;

    switch (currentId())//当前向导页的ID
    {
        case Page_Intro:
            message = tr("您在此处做出的决定将影响您接下来要查看的页面");
            break;
        case Page_Evaluate:
            message = tr("请务必提供有效的电子邮件地址，例如toni.buddenbrook@example.de");
            break;
        case Page_Register:
            message = tr("如果您未提供升级密钥，系统会要求您填写详细信息");
            break;
        case Page_Details:
            message = tr("请务必提供有效的电子邮件地址，例如thomas.gradgrind@example.co.uk");
            break;
        case Page_Conclusion:
            message = tr("您必须接受许可的条款和条件才能继续");
            break;
        default:
            message = tr("这种帮助可能没有任何帮助");
    }

    if (lastHelpMessage == message)//同一頁面點帮助按钮偶数次
    {
        message = tr("对不起，我已经给了我一些帮助，也许你应该尝试请求其他人？");
    }

    QMessageBox::information(this, tr("许可向导帮助"), message);

    lastHelpMessage = message;
}

IntroPage::IntroPage(QWidget *parent)
    : QWizardPage(parent)
{
    setTitle(tr("介绍"));
    setPixmap(QWizard::WatermarkPixmap, QPixmap(":/images/watermark.png"));

    topLabel = new QLabel(tr("本向导将引导您注册Super Product Onetrade产品。您可以选择注册副本，或者开始试用产品。"));
    topLabel->setWordWrap(true);

    registerRadioButton = new QRadioButton(tr("注册您的副本"));
    evaluateRadioButton = new QRadioButton(tr("试用产品30天"));
    registerRadioButton->setChecked(true);

    QVBoxLayout *layout = new QVBoxLayout;
    layout->addWidget(topLabel);
    layout->addWidget(registerRadioButton);
    layout->addWidget(evaluateRadioButton);
    setLayout(layout);
}

//设置下一页
int IntroPage::nextId() const
{
    if (evaluateRadioButton->isChecked())//如果选择的是：试用产品30天
    {
        return LicenseWizard::Page_Evaluate;//跳到这一页
    }
    else
    {
        return LicenseWizard::Page_Register;
    }
}

EvaluatePage::EvaluatePage(QWidget *parent)
    : QWizardPage(parent)
{
    setTitle(tr("试用Super Product One"));
    setSubTitle(tr("请填写这两个字段，请务必提供有效的电子邮件地址（例如john.smith@example.com）"));

    nameLabel = new QLabel(tr("用户名："));
    nameLineEdit = new QLineEdit;
    nameLabel->setBuddy(nameLineEdit);

    emailLabel = new QLabel(tr("电子邮箱："));
    emailLineEdit = new QLineEdit;
    emailLineEdit->setValidator(new QRegExpValidator(QRegExp(".*@.*"), this));
    emailLabel->setBuddy(emailLineEdit);

    registerField("evaluate.name*", nameLineEdit);//注册域 本页面的注册域选了（或填了）才能进入下一页
    registerField("evaluate.email*", emailLineEdit);

    QGridLayout *layout = new QGridLayout;
    layout->addWidget(nameLabel, 0, 0);
    layout->addWidget(nameLineEdit, 0, 1);
    layout->addWidget(emailLabel, 1, 0);
    layout->addWidget(emailLineEdit, 1, 1);
    setLayout(layout);
}

int EvaluatePage::nextId() const
{
    return LicenseWizard::Page_Conclusion;
}

RegisterPage::RegisterPage(QWidget *parent)
    : QWizardPage(parent)
{
    setTitle(tr("注册Super Product One副本"));
    setSubTitle(tr("如果您有升级密钥，请填写相应的字段"));

    nameLabel = new QLabel(tr("用户名"));
    nameLineEdit = new QLineEdit;
    nameLabel->setBuddy(nameLineEdit);

    upgradeKeyLabel = new QLabel(tr("升级密钥"));
    upgradeKeyLineEdit = new QLineEdit;
    upgradeKeyLabel->setBuddy(upgradeKeyLineEdit);

    registerField("register.name*", nameLineEdit);
    registerField("register.upgradeKey", upgradeKeyLineEdit);

    QGridLayout *layout = new QGridLayout;
    layout->addWidget(nameLabel, 0, 0);
    layout->addWidget(nameLineEdit, 0, 1);
    layout->addWidget(upgradeKeyLabel, 1, 0);
    layout->addWidget(upgradeKeyLineEdit, 1, 1);
    setLayout(layout);
}

int RegisterPage::nextId() const
{
    if (upgradeKeyLineEdit->text().isEmpty())
    {
        return LicenseWizard::Page_Details;
    }
    else
    {
        return LicenseWizard::Page_Conclusion;
    }
}

DetailsPage::DetailsPage(QWidget *parent)
    : QWizardPage(parent)
{
    setTitle(tr("填写您的详细信息"));
    setSubTitle(tr("请填写所有三个字段，请务必提供有效的电子邮件地址（例如，tanaka.aya@example.com）"));

    companyLabel = new QLabel(tr("公司名："));
    companyLineEdit = new QLineEdit;
    companyLabel->setBuddy(companyLineEdit);

    emailLabel = new QLabel(tr("电子邮箱："));
    emailLineEdit = new QLineEdit;
    emailLineEdit->setValidator(new QRegExpValidator(QRegExp(".*@.*"), this));
    emailLabel->setBuddy(emailLineEdit);

    postalLabel = new QLabel(tr("邮寄地址："));
    postalLineEdit = new QLineEdit;
    postalLabel->setBuddy(postalLineEdit);

    registerField("details.company*", companyLineEdit);
    registerField("details.email*", emailLineEdit);
    registerField("details.postal*", postalLineEdit);

    QGridLayout *layout = new QGridLayout;
    layout->addWidget(companyLabel, 0, 0);
    layout->addWidget(companyLineEdit, 0, 1);
    layout->addWidget(emailLabel, 1, 0);
    layout->addWidget(emailLineEdit, 1, 1);
    layout->addWidget(postalLabel, 2, 0);
    layout->addWidget(postalLineEdit, 2, 1);
    setLayout(layout);
}

int DetailsPage::nextId() const
{
    return LicenseWizard::Page_Conclusion;
}

ConclusionPage::ConclusionPage(QWidget *parent)
    : QWizardPage(parent)
{
    setTitle(tr("完成注册"));
    setPixmap(QWizard::WatermarkPixmap, QPixmap(":/images/watermark.png"));

    bottomLabel = new QLabel;
    bottomLabel->setWordWrap(true);

    agreeCheckBox = new QCheckBox(tr("我同意许可条款"));

    registerField("conclusion.agree*", agreeCheckBox);

    QVBoxLayout *layout = new QVBoxLayout;
    layout->addWidget(bottomLabel);
    layout->addWidget(agreeCheckBox);
    setLayout(layout);
}

int ConclusionPage::nextId() const
{
    return -1;//下一页没有了
}

void ConclusionPage::initializePage()
{
    QString licenseText;

    //wizard()返回与本页相关的向导
    //hasVisitedPage（id）是否访问过id页
    if (wizard()->hasVisitedPage(LicenseWizard::Page_Evaluate))
    {
        licenseText = tr("评估许可协议：您可以使用此软件30天并进行一次备份，但不允许分发");
    }
    else if (wizard()->hasVisitedPage(LicenseWizard::Page_Details))
    {
        licenseText = tr("首次许可协议：您可以根据您将通过电子邮件收到的许可使用此软件");
    }
    else
    {
        licenseText = tr("升级许可协议：本软件根据您当前的许可条款获得许可");
    }
    bottomLabel->setText(licenseText);
}

//打印按钮设置
void ConclusionPage::setVisible(bool visible)
{
    QWizardPage::setVisible(visible);

    if (visible)//可见就创建打印按钮
    {
        wizard()->setButtonText(QWizard::CustomButton1, tr("&Print"));
        wizard()->setOption(QWizard::HaveCustomButton1, true);//设置第1个自定义按钮 每个页面有3个自定义按钮（推测）
        connect(wizard(), SIGNAL(customButtonClicked(int)),
                this, SLOT(printButtonClicked()));
    }
    else
    {
        wizard()->setOption(QWizard::HaveCustomButton1, false);
        disconnect(wizard(), SIGNAL(customButtonClicked(int)),//断开信号槽连接
                   this, SLOT(printButtonClicked()));
    }
}

//此页面的打印按钮
void ConclusionPage::printButtonClicked()
{
#if !defined(QT_NO_PRINTER) && !defined(QT_NO_PRINTDIALOG)
    QPrinter printer;
    QPrintDialog dialog(&printer, this);
    if (dialog.exec())
    {
        QMessageBox::warning(this, tr("打印许可证"), tr("作为一种环保措施，实际上不会打印许可证文本"));
    }
#endif
}
