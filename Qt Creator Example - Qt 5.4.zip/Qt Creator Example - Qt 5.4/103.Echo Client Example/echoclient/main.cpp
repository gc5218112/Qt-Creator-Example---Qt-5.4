#include <QtCore/QCoreApplication>
#include "echoclient.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    EchoClient client(QUrl(QObject::tr("ws://localhost:1234")));
    QObject::connect(&client, &EchoClient::closed, &a, &QCoreApplication::quit);

    return a.exec();
}
