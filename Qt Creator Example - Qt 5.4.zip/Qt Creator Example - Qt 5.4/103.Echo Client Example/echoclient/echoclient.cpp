#include "echoclient.h"
#include <QtCore/QDebug>

QT_USE_NAMESPACE

EchoClient::EchoClient(const QUrl &url, QObject *parent) :
    QObject(parent),
    m_url(url)
{
    //当本客户端连接到服务端之后
    connect(&m_webSocket, &QWebSocket::connected, this, &EchoClient::onConnected);
    connect(&m_webSocket, &QWebSocket::disconnected, this, &EchoClient::closed);
    m_webSocket.open(QUrl(url));
}

//向服务端发送消息
void EchoClient::onConnected()
{
    qDebug()<<"已连接到服务端";
    //当本客户端接收到服务端发过来的文本消息时
    connect(&m_webSocket, &QWebSocket::textMessageReceived,
            this, &EchoClient::onTextMessageReceived);
    //发送文本消息
    m_webSocket.sendTextMessage(QObject::tr("服务端，这是客户端发给你的消息"));
}

void EchoClient::onTextMessageReceived(QString message)
{
    qDebug()<<"接收到服务端发过来的文本消息："<<message;
    m_webSocket.close();
}
