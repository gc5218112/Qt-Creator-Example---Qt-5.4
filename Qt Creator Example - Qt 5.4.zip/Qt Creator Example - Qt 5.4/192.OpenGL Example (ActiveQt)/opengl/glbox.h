#ifndef GLBOX_H
#define GLBOX_H

#include <QtOpenGL>
#include <QAxBindable>

class GLBox : public QGLWidget,
              public QAxBindable
{
    Q_OBJECT

public:

    GLBox( QWidget* parent, const char* name = 0 );
    ~GLBox();

    QAxAggregated *createAggregate();

public slots:

    void                setXRotation( int degrees );
    void                setYRotation( int degrees );
    void                setZRotation( int degrees );

protected:

    void                initializeGL();
    void                paintGL();
    void                resizeGL( int w, int h );

    virtual GLuint      makeObject();

private:

    GLuint object;
    GLfloat xRot, yRot, zRot, scale;

};

#endif // GLBOX_H
