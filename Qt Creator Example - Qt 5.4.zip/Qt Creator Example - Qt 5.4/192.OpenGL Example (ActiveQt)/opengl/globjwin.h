#ifndef GLOBJWIN_H
#define GLOBJWIN_H

#include <qwidget.h>

class GLObjectWindow : public QWidget
{
    Q_OBJECT

public:
    GLObjectWindow(QWidget *parent = 0);
};

#endif
