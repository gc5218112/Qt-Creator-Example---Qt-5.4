#include "mainwindow.h"
#include "piecesmodel.h"
#include "puzzlewidget.h"
#include <QtWidgets>
#include <stdlib.h>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    setupMenus();
    setupWidgets();
    model = new PiecesModel(puzzleWidget->pieceSize(), this);
    piecesList->setModel(model);

    setSizePolicy(QSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed));
    setWindowTitle(tr("拼图"));
}

void MainWindow::openImage(const QString &path)
{
    QString fileName = path;

    if (fileName.isNull())
    {
        fileName = QFileDialog::getOpenFileName(this, tr("打开图片"), "", tr("Image Files (*.png *.jpg *.bmp)"));
    }

    if (!fileName.isEmpty())
    {
        QPixmap newImage;
        if (!newImage.load(fileName))
        {
            QMessageBox::warning(this, tr("打开图片"), tr("图片载入失败"), QMessageBox::Cancel);
            return;
        }
        puzzleImage = newImage;
        setupPuzzle();
    }
}

void MainWindow::setCompleted()
{
    QMessageBox::information(this, tr("拼图完成"), tr("祝贺你！你已经完成了谜题！单击“确定”再次启动"), QMessageBox::Ok);
    setupPuzzle();
}

void MainWindow::setupPuzzle()
{
    int size = qMin(puzzleImage.width(), puzzleImage.height());
    puzzleImage = puzzleImage.copy((puzzleImage.width() - size) / 2,
                                   (puzzleImage.height() - size) / 2, size, size).scaled(puzzleWidget->imageSize(),
                                    puzzleWidget->imageSize(),
                                    Qt::IgnoreAspectRatio, Qt::SmoothTransformation);

    qsrand(QCursor::pos().x() ^ QCursor::pos().y());

    model->addPieces(puzzleImage);
    puzzleWidget->clear();
}

void MainWindow::setupMenus()
{
    QMenu *fileMenu = menuBar()->addMenu(tr("文件"));

    QAction *openAction = fileMenu->addAction(tr("打开"));
    openAction->setShortcuts(QKeySequence::Open);

    QAction *exitAction = fileMenu->addAction(tr("退出"));
    exitAction->setShortcuts(QKeySequence::Quit);

    QMenu *gameMenu = menuBar()->addMenu(tr("游戏"));

    QAction *restartAction = gameMenu->addAction(tr("重新开始"));

    connect(openAction, SIGNAL(triggered()), this, SLOT(openImage()));
    connect(exitAction, SIGNAL(triggered()), qApp, SLOT(quit()));
    connect(restartAction, SIGNAL(triggered()), this, SLOT(setupPuzzle()));
}

void MainWindow::setupWidgets()
{
    QFrame *frame = new QFrame;
    QHBoxLayout *frameLayout = new QHBoxLayout(frame);

    //创建右窗口
    puzzleWidget = new PuzzleWidget(400);

    //创建左窗口
    piecesList = new QListView;
    piecesList->setDragEnabled(true);//视图中的项可拖拽
    piecesList->setViewMode(QListView::IconMode);//视图显示模型，显示图标
    //图标尺寸 图片尺寸/5-20像素
    piecesList->setIconSize(QSize(puzzleWidget->pieceSize() - 20, puzzleWidget->pieceSize() - 20));
    piecesList->setGridSize(QSize(puzzleWidget->pieceSize(), puzzleWidget->pieceSize()));//网格尺寸
    piecesList->setSpacing(10);
    piecesList->setMovement(QListView::Snap);//设置项移动模式：移动放置时放到网格里，不能随意放置在视图上
    piecesList->setAcceptDrops(true);//可放下
    piecesList->setDropIndicatorShown(true);

    connect(puzzleWidget, SIGNAL(puzzleCompleted()), this, SLOT(setCompleted()), Qt::QueuedConnection);

    frameLayout->addWidget(piecesList);
    frameLayout->addWidget(puzzleWidget);
    setCentralWidget(frame);
}
