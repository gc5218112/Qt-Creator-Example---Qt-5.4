#include "elidedlabel.h"
#include <QPainter>
#include <QTextLayout>
#include <QDebug>

ElidedLabel::ElidedLabel(const QString &text, QWidget *parent)
    : QFrame(parent)
    , elided(false)
    , content(text)
{
    //设置窗体大小策略
    setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);
}

//设置标签显示内容
void ElidedLabel::setText(const QString &newText)
{
    content = newText;
    update();
}

//标签重绘事件
void ElidedLabel::paintEvent(QPaintEvent *event)
{
    QFrame::paintEvent(event);

    QPainter painter(this);

    //QFontMetrics字体度量 封装的是字体各种尺度信息
    QFontMetrics fontMetrics = painter.fontMetrics();

    bool didElide = false;
    int lineSpacing = fontMetrics.lineSpacing();//线间距 = 字体尺寸的线间距
    qDebug()<<"lineSpacing:"<<lineSpacing;//14
    int y = 0;

    //QTextLayout呈现文字的布局
    QTextLayout textLayout(content, painter.font());//（文本，字体）
    textLayout.beginLayout();
    forever //for (;;)
    {
        QTextLine line = textLayout.createLine();//文字布局中的一行文本

        if (!line.isValid())
        {
            break;
        }

        line.setLineWidth(width()*2);

        int nextLineY = y + lineSpacing;

        if (height() >= nextLineY + lineSpacing)
        {
            painter.setPen(Qt::red);
            line.draw(&painter, QPoint(20, y));
            y = nextLineY;
        }
        else
        {
            QString lastLine = content.mid(line.textStart());
            QString elidedLastLine = fontMetrics.elidedText(lastLine, Qt::ElideRight, width());

            painter.drawText(QPoint(0, y + fontMetrics.ascent()), elidedLastLine);
            line = textLayout.createLine();
            didElide = line.isValid();
            break;
        }
    }
    textLayout.endLayout();

    if (didElide != elided)
    {
        elided = didElide;
        emit elisionChanged(didElide);
    }
}
