#include "testwidget.h"
#include "elidedlabel.h"
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSizePolicy>
#include <QtWidgets/QGridLayout>

TestWidget::TestWidget(QWidget *parent):
    QWidget(parent)
{
    textSamples << tr("这是一句话A") << tr("这是一句话B") << tr("这是一句话C");

    sampleIndex = 0;
    elidedText = new ElidedLabel(textSamples[sampleIndex], this);
    elidedText->setFrameStyle(QFrame::Box);

    QPushButton *switchButton = new QPushButton(tr("更换文字"));
    connect(switchButton, SIGNAL(clicked(bool)), this, SLOT(switchText()));

    QPushButton *exitButton = new QPushButton(tr("退出"));
    connect(exitButton, SIGNAL(clicked(bool)), this, SLOT(close()));

    QLabel *label = new QLabel(tr("忽略"));
    label->setVisible(elidedText->isElided());//默认不可见
    connect(elidedText, SIGNAL(elisionChanged(bool)), label, SLOT(setVisible(bool)));

    widthSlider = new QSlider(Qt::Horizontal);//水平滑动条
    widthSlider->setMinimum(0);
    connect(widthSlider, SIGNAL(valueChanged(int)), this, SLOT(onWidthChanged(int)));

    heightSlider = new QSlider(Qt::Vertical);//垂直滑动条
    heightSlider->setInvertedAppearance(true);
    heightSlider->setMinimum(0);
    connect(heightSlider, SIGNAL(valueChanged(int)), this, SLOT(onHeightChanged(int)));

    QGridLayout *layout = new QGridLayout();
    layout->addWidget(label, 0, 1, Qt::AlignCenter);
    layout->addWidget(switchButton, 0, 2);
    layout->addWidget(exitButton, 0, 3);
    layout->addWidget(widthSlider, 1, 1, 1, 3);
    layout->addWidget(heightSlider, 2, 0);
    layout->addWidget(elidedText, 2, 1, 1, 3, Qt::AlignTop | Qt::AlignLeft);

    setLayout(layout);
}

void TestWidget::resizeEvent(QResizeEvent *event)
{
    Q_UNUSED(event)

    //窗口大小改变时，滑动条的最值变成窗口的大小
    int maxWidth = widthSlider->width();
    widthSlider->setMaximum(maxWidth);
    widthSlider->setValue(maxWidth / 2);

    int maxHeight = heightSlider->height();
    heightSlider->setMaximum(maxHeight);
    heightSlider->setValue(maxHeight / 2);

    //标签的宽高值变化为滑动条此时的值
    elidedText->setFixedSize(widthSlider->value(), heightSlider->value());
}

void TestWidget::switchText()
{
    sampleIndex = (sampleIndex + 1) % textSamples.size();
    elidedText->setText(textSamples.at(sampleIndex));
}

void TestWidget::onWidthChanged(int width)
{
    elidedText->setFixedWidth(width);//部件的最小和最大宽度设置为width，而不更改高度
}

void TestWidget::onHeightChanged(int height)
{
    elidedText->setFixedHeight(height);//部件的最小和最大高度设置为height，而不更改宽度
}
