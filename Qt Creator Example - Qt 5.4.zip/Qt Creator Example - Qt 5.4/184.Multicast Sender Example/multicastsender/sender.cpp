#include <QtWidgets>
#include <QtNetwork>
#include "sender.h"

Sender::Sender(QWidget *parent)
    : QDialog(parent)
{
    groupAddress = QHostAddress("239.255.43.21");//此IP是保留地址 向此地址发消息是向内部网络发消息

    statusLabel = new QLabel(tr("准备多播数据报组，发往：\n地址： %1 \n端口： 45454").arg(groupAddress.toString()));

    ttlLabel = new QLabel(tr("多播数据报的TTL："));
    ttlSpinBox = new QSpinBox;
    ttlSpinBox->setRange(0, 255);

    QHBoxLayout *ttlLayout = new QHBoxLayout;
    ttlLayout->addWidget(ttlLabel);
    ttlLayout->addWidget(ttlSpinBox);

    startButton = new QPushButton(tr("开始"));
    quitButton = new QPushButton(tr("退出"));

    buttonBox = new QDialogButtonBox;
    buttonBox->addButton(startButton, QDialogButtonBox::ActionRole);
    buttonBox->addButton(quitButton, QDialogButtonBox::RejectRole);

    timer = new QTimer(this);
    udpSocket = new QUdpSocket(this);
    messageNo = 1;

    connect(ttlSpinBox, SIGNAL(valueChanged(int)), this, SLOT(ttlChanged(int)));
    connect(startButton, SIGNAL(clicked()), this, SLOT(startSending()));
    connect(quitButton, SIGNAL(clicked()), this, SLOT(close()));
    connect(timer, SIGNAL(timeout()), this, SLOT(sendDatagram()));

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout->addWidget(statusLabel);
    mainLayout->addLayout(ttlLayout);
    mainLayout->addWidget(buttonBox);
    setLayout(mainLayout);

    setWindowTitle(tr("多播消息发送器"));
    ttlSpinBox->setValue(1);
}

void Sender::ttlChanged(int newTtl)
{
    udpSocket->setSocketOption(QAbstractSocket::MulticastTtlOption, newTtl);
}

void Sender::startSending()
{
    startButton->setEnabled(false);
    timer->start(1000);
}

//定时器
void Sender::sendDatagram()
{
    statusLabel->setText(tr("现在发送数据报：%1").arg(messageNo));
    QByteArray datagram = "多播消息：" + QByteArray::number(messageNo);
    udpSocket->writeDatagram(datagram.data(), datagram.size(), groupAddress, 45454);
    ++messageNo;
}
